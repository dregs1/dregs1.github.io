# DWIGHT FARROKH LISTA (plugin.video.Dwight_Farrokh_Lista) 2.9

Addon Kodi para **Xtream Codes** (player_api.php): TV ao vivo, filmes e séries, com a
**interface estilo IBO (skin launcher) agora na paleta
**azul-marinho + roxo + âmbar** da logo do DWIGHT FARROKH LISTA.

Kodi 19 a 22 (Python 3). Sem dependências externas (só stdlib + API Python do Kodi).
**Requisito para a TV ao vivo**: plugin **f4mTester** (`plugin.video.f4mTester`),
usado para abrir os canais como no addon VIKING TV original.

## Novidades da 2.9
- Novo id/nome (`plugin.video.Dwight_Farrokh_Lista`, DWIGHT FARROKH LISTA em maiúsculas), ícone e fanart do lobo; layout (home, ao vivo, grade e episódios) na paleta da logo; fundo novo de montanhas e lobo em todas as páginas; logo ao lado do nome em todas as páginas; nome do f4mTester atualizado.

## Novidades da 2.1.0
- **Credenciais fora das configurações**: o link remoto agora é **fixo no
  `default.py` do addon** (constante `CRED_URL`), como no VIKING TV original
  (mesmo funcionamento do `login_api`). Formatos aceitos: XML do VIKING TV
  (URLs `get.php?username=...&password=...`) ou JSON (categorias com
  `servidores`). Se o link estiver fora do ar, o addon usa a última lista
  baixada (cache local). Removidos dos Ajustes: link de credenciais, servidor
  ativo, DNS/Usuário/Senha, formato TS/HLS e opções do ffmpegdirect.
- **Canais ao vivo abrem com o plugin f4mTester**, como no addon VIKING TV
  original: a URL `.ts` do canal é convertida para `.m3u8` e aberta como
  `streamtype=HLSRETRY` (`TSDOWNLOADER` para URLs ao vivo sem extensão), via
  `RunPlugin` — tanto na interface IBO quanto no modo lista (os itens apontam
  direto para o f4mTester).
- **Filmes e séries (VOD) reproduzem sempre pelo `vodproxy.py`** (proxy local
  com User-Agent/Origin/Referer tratados internamente), mantendo a retomada de
  onde parou e o autoplay do próximo episódio.
- Botão **Servidor** mantido (testa todos os servidores ON/OFF e aplica o
  escolhido — a escolha fica salva no banco local do addon). Botão **Formato**
  removido da home (canais sempre via f4mTester).


## Credenciais (default.py)
O link remoto com servidor/usuário/senha é definido **no `default.py` do addon**:

```python
CRED_URL = 'https://paste.kodi.tv/raw/hoximavuti'
```

## Configuração (Ajustes)
- **Conta**: testar conexão, User-Agent, verificar SSL, headers Origin/Referer, DoH.
- **Reprodução**: perguntar se retoma de onde parou (filmes/séries).
- **Interface**: abrir a interface IBO ao iniciar, ocultar categorias adultas,
  limpar nomes, EPG no nome do canal (modo lista).
- **Guia (EPG)**: ativar, intervalo, dias, fuso, URLs XMLTV extras.
- **Metadados**: chave TMDB (já vem preenchida), idioma, TVmaze.
- **Avançado**: atualizar catálogo, limpar cache, limpar histórico, log detalhado.
