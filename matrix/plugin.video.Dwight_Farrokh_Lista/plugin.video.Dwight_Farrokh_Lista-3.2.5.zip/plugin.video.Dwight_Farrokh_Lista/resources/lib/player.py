# -*- coding: utf-8 -*-
"""Monta URL + ListItem reproduzível para canais, filmes e episódios.

Roteamento de reprodução:
  * Canais ao vivo -> plugin f4mTester, exatamente como no addon VIKING TV
    original: a URL .ts é convertida para .m3u8 e aberta como
    streamtype=HLSRETRY (TSDOWNLOADER p/ URLs ao vivo sem extensão),
    lançada com RunPlugin. O id do f4mTester é detectado no Kodi por
    três caminhos (condições System.*, probe xbmcaddon.Addon e varredura
    da pasta de addons), cobrindo qualquer grafia/variante e o caso de
    addon instalado mas desabilitado. Nada é resolvido pelo Kodi neste
    addon.
  * Filmes e episódios (VOD) -> sempre pelo vodproxy.py (resources/lib), que
    trata User-Agent/Origin/Referer internamente; por isso a URL passada a
    ele é a URL "limpa" da origem (sem o sufixo |Header=... do Kodi).
"""
import json
import re
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui

from . import listing, store
from .common import ADDON_ID, ADDON_PATH, SB, busy, log, notify, to_int
from .i18n import _
from urllib.parse import quote_plus

# --- importação dos proxies (hlsproxy.py, tsproxy.py, vodproxy.py em resources/lib)
#
# Os proxies dependem de pacotes de terceiros (requests, urllib3, certifi,
# charset_normalizer, idna) que NÃO vêm no Python embutido do Kodi. Por isso
# esses pacotes vêm empacotados em <addon>/vendor/ (apenas Python puro, em
# versões compatíveis com Python 3.8+ — Kodi 19 ao 22). Colocamos vendor/ no
# sys.path ANTES de importar os proxies (que agora vivem em resources/lib,
# no mesmo pacote deste módulo).
#
# Marca de versão do player (para confirmar no log que esta versão está ativa):
#   "DWIGHT FARROKH LISTA player.py v8 (f4mTester tripla-detecção + vodproxy VOD + episódios duplicados)"
log('DWIGHT FARROKH LISTA player.py v8 (f4mTester tripla-detecção + vodproxy VOD + episódios duplicados) carregando')

import os as _os
import traceback as _tb

_VENDOR = _os.path.join(ADDON_PATH, 'vendor')
log('player.py diag: ADDON_PATH=%s' % ADDON_PATH)
log('player.py diag: vendor=%s existe=%s' % (_VENDOR, _os.path.isdir(_VENDOR)))
log('player.py diag: python=%s' % '.'.join(str(v) for v in sys.version_info[:3]))

if _os.path.isdir(_VENDOR):
    if _VENDOR not in sys.path:
        sys.path.insert(0, _VENDOR)
    # verifica se cada dependência consegue importar (com a vendor no path)
    for _dep in ('certifi', 'idna', 'charset_normalizer', 'urllib3', 'requests'):
        try:
            _m = __import__(_dep)
            _ver = getattr(_m, '__version__', '?')
            _file = getattr(_m, '__file__', '?')
            log('player.py diag: dep %s OK ver=%s file=%s' % (_dep, _ver, _file))
        except Exception as _e:
            log('player.py diag: dep %s FALHOU: %s' % (_dep, _e), xbmc.LOGERROR)
            log(_tb.format_exc(), xbmc.LOGERROR)
else:
    log('player.py diag: vendor/ NAO EXISTE — os proxies nao vao funcionar!', xbmc.LOGERROR)

if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

# Agora sim, importa os proxies (com traceback completo se falhar)
try:
    from . import hlsproxy   # mantido apenas p/ encerramento defensivo (stop_all_proxies)
    log('player.py diag: hlsproxy OK ver=%s' % getattr(hlsproxy, '__version__', '?'))
except Exception as _e:
    hlsproxy = None
    log('player.py diag: hlsproxy FALHOU: %s' % _e, xbmc.LOGERROR)
    log(_tb.format_exc(), xbmc.LOGERROR)

try:
    from . import tsproxy    # mantido apenas p/ encerramento defensivo (stop_all_proxies)
    log('player.py diag: tsproxy OK')
except Exception as _e:
    tsproxy = None
    log('player.py diag: tsproxy FALHOU: %s' % _e, xbmc.LOGERROR)
    log(_tb.format_exc(), xbmc.LOGERROR)

try:
    from . import vodproxy   # VOD para filmes e episódios (sempre)
    log('player.py diag: vodproxy OK')
except Exception as _e:
    vodproxy = None
    log('player.py diag: vodproxy FALHOU: %s' % _e, xbmc.LOGERROR)
    log(_tb.format_exc(), xbmc.LOGERROR)

MIME = {
    'ts': 'video/mp2t', 'm3u8': 'application/vnd.apple.mpegurl', 'mp4': 'video/mp4',
    'mkv': 'video/x-matroska', 'avi': 'video/x-msvideo', 'mov': 'video/quicktime',
    'webm': 'video/webm', 'flv': 'video/x-flv', 'mpg': 'video/mpeg', 'mpeg': 'video/mpeg',
}
NOW_PROP = 'xtreamplayer.now'          # histórico (filmes/episódios) lido pelo service
CUR_PROP = 'xtreamplayer.current'      # qualquer item iniciado pelo addon (inclui canais)
# Player dos canais ao vivo (como no addon VIKING TV original). O f4mTester
# existe em várias grafias/variantes de id em circulação:
#   * 'plugin.video.f4mtester'  (minúsculas — versões atuais)
#   * 'plugin.video.f4mTester'  (T maiúsculo — builds antigos de repositórios)
#   * forks com outros sufixos
# O id é sensível a maiúsculas no Kodi, e além disso um addon instalado pode
# estar DESABILITADO (ex.: builds antigos marcados incompatíveis em Kodi 22),
# o que faz System.AddonIsEnabled devolver False mesmo com ele instalado.
# Por isso a detecção é tripla: (1) condições do Kodi, (2) probe via
# xbmcaddon.Addon, (3) varredura direta da pasta de addons do Kodi — e o
# canal é SEMPRE lançado (RunPlugin) com o id detectado.
F4M_ADDON = 'plugin.video.f4mtester'      # grafia moderna (padrão)
F4M_ADDON_ALT = 'plugin.video.f4mTester'  # grafia antiga
F4M_TAG = '[COLOR FFF2F0E3]DWIGHT[/COLOR] [COLOR FFB197E8]FARROKH[/COLOR] [COLOR FFF8B651]LISTA[/COLOR]+[COLOR FFF8B651]by_black_eagle[/COLOR]'
_F4M_STATE = None                          # cache: (id, estado)


def _addon_enabled(aid):
    """True se o addon com este id está instalado E habilitado no Kodi."""
    try:
        if xbmc.getCondVisibility('System.AddonIsEnabled(%s)' % aid):
            return True
    except Exception:
        pass
    try:
        if xbmc.getCondVisibility('System.HasAddon(%s)' % aid):
            return True
    except Exception:
        pass
    try:
        xbmcaddon.Addon(aid)          # só abre quando instalado+habilitado
        return True
    except Exception:
        pass
    return False


def _scan_f4m_dirs():
    """Varre as pastas de addons do Kodi procurando o f4mTester por qualquer
    grafia/fork (a pasta do addon tem sempre o nome do id). É o fallback
    definitivo: funciona mesmo quando as condições System.* não reportam o
    addon (instalado mas desabilitado, por exemplo).
    """
    try:
        import xbmcvfs
        cands = []
        for base in ('special://home/addons/', 'special://masterprofile/addons/',
                     'special://xbmc/addons/'):
            try:
                dirs, _files = xbmcvfs.listdir(base)
            except Exception:
                continue
            for d in dirs or []:
                d = (d or '').rstrip('/\\')
                dl = d.lower()
                if dl.startswith('plugin.video.f4m') and 'test' in dl:
                    cands.append(d)
        for pref in (F4M_ADDON, F4M_ADDON_ALT):   # grafias oficiais primeiro
            if pref in cands:
                return pref
        return sorted(cands)[0] if cands else None
    except Exception as e:
        log('Erro ao varrer as pastas de addons do Kodi: %s' % e)
        return None


def _f4m_state():
    """(id, estado) do f4mTester — estado: 'on' (pronto), 'off' (instalado
    mas desabilitado) ou 'none' (não encontrado)."""
    global _F4M_STATE
    if _F4M_STATE:
        return _F4M_STATE
    for aid in (F4M_ADDON, F4M_ADDON_ALT):
        if _addon_enabled(aid):
            _F4M_STATE = (aid, 'on')
            log('f4mTester pronto no Kodi: %s' % aid)
            return _F4M_STATE
    scanned = _scan_f4m_dirs()
    if scanned:
        _F4M_STATE = (scanned, 'off')
        log('f4mTester encontrado na pasta de addons, mas não habilitado: %s' % scanned)
        return _F4M_STATE
    _F4M_STATE = (F4M_ADDON, 'none')
    log('f4mTester não encontrado no Kodi; usando o id padrão %s' % F4M_ADDON)
    return _F4M_STATE


def f4m_addon_id():
    """Id do f4mTester a usar na URL plugin:// (detectado, com fallback)."""
    return _f4m_state()[0]


def f4m_installed():
    """True se alguma grafia/variante do f4mTester está instalada."""
    return _f4m_state()[1] != 'none'


def f4m_url_for_live(xt, rid, name='', icon=''):
    """URL do canal para abrir com o plugin f4mTester (como no VIKING TV original).

    A URL Xtream do canal (.ts) é convertida para .m3u8 e devolvida como
    plugin://<f4mTester instalado>/?streamtype=HLSRETRY&...; URLs ao vivo sem
    extensão (.m3u8/.mp4/...) usam streamtype=TSDOWNLOADER.
    """
    base = xt.stream_url('live', rid)
    if base.endswith('.ts'):
        base = base[:-3] + '.m3u8'                    # .ts -> .m3u8 (como no original)
    if '.m3u8' in base:
        streamtype = 'HLSRETRY'
    elif not any(e in base for e in ('.mp4', '.mkv', '.avi', '.mov', '.wmv',
                                     '.mp3', '.wma', '.ac3', '.rmvb')):
        streamtype = 'TSDOWNLOADER'
    else:
        return base                                  # arquivo baixável: direto
    # id do f4mTester detectado no Kodi (grafia/variante instalada) — usar o
    # errado faz o Kodi pedir para instalar o plugin mesmo com ele instalado.
    return ('plugin://%s/?streamtype=%s&name=%s&iconImage=%s&thumbnailImage=%s&url=%s'
            % (f4m_addon_id(), streamtype, quote_plus(F4M_TAG),
               quote_plus(str(icon or '')), quote_plus(str(icon or '')), quote_plus(base)))


def play_live_f4m(xt, rid, name='', icon=''):
    """Abre o canal ao vivo com o f4mTester via RunPlugin (addon VIKING original).

    Devolve a URL plugin:// do f4mTester lançada. O chamador NÃO deve resolver
    nem dar Player().play — o f4mTester inicia a reprodução ele mesmo.
    O canal é SEMPRE lançado; se o f4mTester estiver desabilitado ou ausente,
    um aviso específico acompanha o lançamento (sem bloquear a reprodução).
    """
    aid, state = _f4m_state()
    if state == 'off':
        notify(_('O f4mTester está instalado, mas DESABILITADO no Kodi. '
                 'Ative-o em Add-ons, Meus add-ons, para assistir à TV ao vivo.'))
    elif state == 'none':
        notify(_('Instale o plugin f4mTester para assistir aos canais ao vivo.'))
    f4m = f4m_url_for_live(xt, rid, name, icon)
    if not f4m.startswith('plugin://'):
        log('Canal ao vivo sem URL f4mTester (arquivo direto?): %s' % f4m)
        return ''
    xbmc.executebuiltin('RunPlugin(%s)' % f4m)
    log('Canal ao vivo aberto com o f4mTester [%s/%s]: %s' % (aid, state, f4m))
    return f4m


def fmt_clock(sec):
    sec = int(sec)
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return '%d:%02d:%02d' % (h, m, s) if h else '%d:%02d' % (m, s)


def video_playing():
    try:
        return bool(xbmc.getCondVisibility('Player.HasVideo'))
    except Exception:
        return False


def playing_base():
    """URL (sem headers) do vídeo em reprodução agora, ou ''."""
    try:
        pl = xbmc.Player()
        return pl.getPlayingFile().split('|')[0] if pl.isPlayingVideo() else ''
    except Exception:
        return ''


def is_current(kind, rid):
    """True se este item já está tocando (selecioná-lo de novo só volta à tela cheia)."""
    try:
        raw = xbmcgui.Window(10000).getProperty(CUR_PROP)
        cur = json.loads(raw) if raw else None
    except Exception:
        return False
    return bool(cur) and cur.get('addon') == ADDON_ID \
        and cur.get('kind') == kind and cur.get('id') == str(rid) \
        and video_playing() and cur.get('base') == playing_base()


def fullscreen():
    """Volta ao vídeo em tela cheia (ex.: depois de sair dele com Voltar). False se não há vídeo."""
    if not video_playing():
        return False
    xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    return True


def ffd_enabled():
    """Obsoleto: canais ao vivo abrem sempre com o f4mTester (como no VIKING TV
    original). Mantida por compatibilidade de assinatura; devolve sempre False."""
    return False


def _proxy_url_for(xt, kind, base, ext):
    """Devolve a URL local do vodproxy.py para a URL da origem, ou None se não aplicável.

    Roteamento (apenas VOD):
      * movie / episode  -> vodproxy (resolve_vod_stream)
    O vodproxy recebe a URL "limpa" da origem (sem sufixo |Header=... do Kodi)
    e constrói os próprios User-Agent/Origin/Referer internamente.
    """
    if kind in ('movie', 'episode'):
        if vodproxy is None:
            log('vodproxy indisponível; tentando URL direta para %s' % base)
            return None
        try:
            proxy_url, _mgr = vodproxy.resolve_vod_stream(base)
            return proxy_url
        except Exception as e:
            log('Falha ao iniciar o proxy VOD para %s: %s' % (base, e))
            return None

    return None


# --- episódio duplicado no painel (meta.parse_seasons junta os ids repetidos em 'alts') --------
MIN_VOD_BYTES = 256 * 1024      # arquivo menor que isso não é um episódio de verdade
PROBE_WAIT = 15.0               # teto (s) para testar UM link; passou disso = não responde


def _media_ok(resp):
    """A resposta do upstream parece mídia reproduzível? (200/206, não é página/JSON, tamanho plausível)"""
    if resp is None or resp.status_code not in (200, 206):
        return False
    ctype = (resp.headers.get('Content-Type') or '').lower()
    if ctype.startswith('text/') or 'json' in ctype or 'xml' in ctype:
        return False
    total = 0
    m = re.search(r'/(\d+)\s*$', resp.headers.get('Content-Range') or '')
    if m:
        total = int(m.group(1))
    elif resp.status_code == 200:
        total = to_int(resp.headers.get('Content-Length'))
    if total and total < MIN_VOD_BYTES:
        return False
    head = b''
    for chunk in resp.iter_content(chunk_size=16):
        head = chunk or b''
        break
    return bool(head) and head.lstrip()[:1] not in (b'<', b'{')


def _vod_ok(url):
    """True/False: o proxy VOD consegue / não consegue abrir este link (mesmo caminho da reprodução:
    headers, DoH, redirects e a URL da API). None: não deu para testar."""
    if vodproxy is None or getattr(vodproxy, 'requests', None) is None:
        return None
    box = []

    def _run():
        resp = None
        try:
            resp = vodproxy.STREAM_MANAGER.fetch(url, 'bytes=0-15')
            box.append(_media_ok(resp))
        except (AttributeError, NameError, TypeError, ImportError) as e:     # falha nossa, não do link
            log('teste de episódio indisponível: %s' % e)
            box.append(None)
        except Exception as e:                                               # sem conexão/timeout/DNS
            log('teste de episódio: link não abriu (%s)' % type(e).__name__)
            box.append(False)
        finally:
            if resp is not None:
                try:
                    resp.close()
                except Exception:
                    pass
    t = threading.Thread(target=_run)
    t.daemon = True
    t.start()
    t.join(PROBE_WAIT)
    return box[0] if box else False


def pick_episode(xt, rid, ext, alts):
    """Episódio duplicado no painel: devolve (id, ext) do primeiro candidato que o proxy VOD consegue
    abrir. O último não é testado (não há outra opção); sem como testar, vale o primeiro."""
    cands = [(str(rid), ext or 'mp4')]
    for a in alts or []:
        if isinstance(a, dict) and a.get('id') not in (None, ''):
            cands.append((str(a['id']), a.get('ext') or 'mp4'))
    if len(cands) < 2:
        return cands[0]
    busy(True)
    try:
        for cid, cext in cands[:-1]:
            ok = _vod_ok(xt.stream_url('episode', cid, cext))
            log('episódio duplicado: id %s (%s) -> %s' % (cid, cext, {True: 'toca', False: 'não toca'}.get(ok, 'sem teste')))
            if ok is not False:
                return cid, cext
    finally:
        busy(False)
    return cands[-1]


def build_playable(xt, kind, rid, ext='', title='', art=None, info=None, ident=None, resume=True, alts=None):
    """Devolve (url, ListItem) — exceto canais ao vivo, veja abaixo.

    kind: 'live' | 'movie' | 'episode'. ident: dados p/ o histórico (name, icon, ext...).

    CANAIS AO VIVO ('live'): abrem com o plugin f4mTester via RunPlugin (como no
    addon VIKING TV original). A reprodução já é lançada dentro desta função e o
    retorno é (url_f4m, None) — res[1] is None significa "nada a resolver/tocar".

    FILMES E EPISÓDIOS ('movie'/'episode'): reprodução sempre pelo vodproxy.py;
    se o proxy falhar ou não estiver disponível, cai na URL direta com
    header_suffix. Devolve None se o usuário cancelar o diálogo de retomada.
    alts: só episódios — outros ids/ext do MESMO episódio (duplicatas do painel); toca o que responder.
    """
    if kind == 'live':
        f4m = play_live_f4m(xt, rid, title or '',
                            (art or {}).get('thumb') or (art or {}).get('icon') or '')
        if not f4m:
            return None
        try:
            xbmcgui.Window(10000).setProperty(CUR_PROP, json.dumps(
                {'addon': ADDON_ID, 'kind': 'live', 'id': str(rid), 'base': f4m},
                ensure_ascii=False))
        except Exception as e:
            log('Não foi possível registrar o item atual: %s' % e)
        return f4m, None

    if kind == 'episode' and alts:
        rid, ext = pick_episode(xt, rid, ext, alts)
        if ident:
            ident = dict(ident, ext=ext)

    base = xt.stream_url(kind, rid, ext or None)

    # Roteamento por proxy (sem sufixo de headers — o proxy trata os seus).
    proxy_url = _proxy_url_for(xt, kind, base, ext)
    if proxy_url:
        url = proxy_url
    else:
        url = base + xt.header_suffix(base)   # fallback: URL direta com headers

    li = xbmcgui.ListItem(title or '', path=url)
    li.setProperty('IsPlayable', 'true')
    mime = MIME.get(base.rsplit('.', 1)[-1].lower())
    if mime:
        li.setMimeType(mime)
        li.setContentLookup(False)      # evita HEAD/GET extra (painéis com 1 conexão)
    d = dict(info or {})
    if title:
        d['title'] = title
    listing.apply_video_info(li, d, {'movie': 'movie', 'episode': 'episode'}.get(kind, 'video'))
    if art:
        li.setArt(art)
    offset = 0
    if resume and kind in ('movie', 'episode') and SB('resume_ask', True):
        pos = store.resume_point(kind, rid)
        if pos:
            choice = xbmcgui.Dialog().select(title or _('Reproduzir'),
                                             [_('Retomar de %s') % fmt_clock(pos), _('Começar do início')])
            if choice < 0:
                return None
            if choice == 0:
                li.setProperty('StartOffset', str(pos))
                offset = pos
    # Guardamos como 'base' a URL que o Kodi realmente reproduz (a do proxy quando
    # ele está ativo), para que is_current() e o Tracker do service.py continuem
    # casando com getPlayingFile().
    try:
        xbmcgui.Window(10000).setProperty(CUR_PROP, json.dumps(
            {'addon': ADDON_ID, 'kind': kind, 'id': str(rid), 'base': url}, ensure_ascii=False))
    except Exception as e:
        log('Não foi possível registrar o item atual: %s' % e)
    if kind in ('movie', 'episode'):
        try:
            xbmcgui.Window(10000).setProperty(NOW_PROP, json.dumps(
                {'addon': ADDON_ID, 'kind': kind, 'id': str(rid), 'base': url, 'offset': offset,
                 'info': ident or {'name': title}},
                ensure_ascii=False))
        except Exception as e:
            log('Não foi possível sinalizar o histórico: %s' % e)
    return url, li


def stop_all_proxies():
    """Encerra TODOS os proxies locais ativos (HLS, TS e VOD) imediatamente.

    Deve ser chamado quando o player para (onPlayBackStopped) para liberar
    sockets, threads e conexões upstream que ficariam pendurados.

    Idempotente e seguro chamar de threads distintas — cada proxy tem seu
    próprio lock. Erros em um proxy não impedem o encerramento dos outros.
    """
    log('Encerrando todos os proxies locais (HLS/TS/VOD)...')

    # HLS — canais ao vivo no formato m3u8
    try:
        if hlsproxy is not None and hasattr(hlsproxy, 'stop_server'):
            hlsproxy.stop_server()
            log('Proxy HLS encerrado.')
    except Exception as e:
        log('Erro ao encerrar proxy HLS: %s' % e, xbmc.LOGERROR)

    # TS — canais ao vivo no formato .ts (MPEG-TS)
    try:
        if tsproxy is not None and hasattr(tsproxy, 'shutdown_proxy'):
            tsproxy.shutdown_proxy()
            log('Proxy TS encerrado.')
    except Exception as e:
        log('Erro ao encerrar proxy TS: %s' % e, xbmc.LOGERROR)

    # VOD — filmes e episódios (pode haver vários managers ativos)
    try:
        if vodproxy is not None and hasattr(vodproxy, 'stop_all_managers'):
            vodproxy.stop_all_managers()
            log('Proxies VOD encerrados.')
    except Exception as e:
        log('Erro ao encerrar proxies VOD: %s' % e, xbmc.LOGERROR)

    # Limpa a propriedade que indica o item em reprodução — o player parou.
    try:
        xbmcgui.Window(10000).clearProperty(CUR_PROP)
    except Exception:
        pass

    log('Todos os proxies locais encerrados.')
