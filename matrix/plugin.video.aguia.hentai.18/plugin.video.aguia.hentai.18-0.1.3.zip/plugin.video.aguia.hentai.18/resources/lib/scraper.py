# -*- coding: utf-8 -*-
import six
import requests
from bs4 import BeautifulSoup
import re
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import random
import time

    
class SC:
    def __init__(self):
        self.sitehentai = 'https://hentailegendado.com/'       
        self.IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
        self.FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
        self.OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36 OPR/67.0.3575.97'
        self.IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
        self.IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
        self.ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36'
        self.EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363'
        self.CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'        
        self.SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
        self._USER_AGENTS = [self.FF_USER_AGENT, self.OPERA_USER_AGENT, self.EDGE_USER_AGENT, self.CHROME_USER_AGENT, self.SAFARI_USER_AGENT]        
        self.headers = {'User-Agent': self.CHROME_USER_AGENT,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,es;q=0.6',
                    'sec-ch-ua': '"Chromium";v="115", "Not A(Brand";v="99", "Google Chrome";v="115"',
                    'sec-ch-ua-mobile': '?1',
                    'sec-ch-ua-platform': '"Android"',
                    'Sec-Fetch-Dest': 'document',
                    'Sec-Fetch-Mode': 'navigate',
                    'Sec-Fetch-Site': 'none',
                    'Sec-Fetch-User': '?1',
                    'Upgrade-Insecure-Requests': '1'   
                        }
        self.itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
    '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
    '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
    '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
    '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
    '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
    '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
    '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
    '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
    '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}
        
    def pick_source(self,sources):
        return sources[0][1]

    def __key(self, item):
        try:
            return int(re.search(r'(\d+)', item[0]).group(1))
        except:
            return 0 

    def _parse_gdocs(self, html):
        urls = []
        if 'error' in html:
            reason = unquote_plus(re.findall('reason=([^&]+)', html)[0])
            raise ValueError(reason)
        value = unquote(re.findall('fmt_stream_map=([^&]+)', html)[0])
        items = value.split(',')
        for item in items:
            _source_itag, source_url = item.split('|')
            if isinstance(source_url, six.text_type) and six.PY2:  # @big change
                source_url = source_url.decode('unicode_escape').encode('utf-8')
            quality = self.itag_map.get(_source_itag, 'Unknown Quality [%s]' % _source_itag)
            source_url = unquote(source_url)
            urls.append((quality, source_url))
        return urls

    def resolve_url(self,link):
        sources = []
        cookies = None
        referer = ''
        if 'drive.google.com' in link:
            referer = 'https://youtube.googleapis.com/'
            link = re.findall('/file/.*?/([^/]+)', link)[0]
            link = 'https://drive.google.com/get_video_info?docid=' + link
            #response = requests.get(link,headers=cls.headers)
            response = requests.get(link,headers=self.headers)
            cookies = response.cookies
            sources = self._parse_gdocs(response.text)
        elif 'blogger.com/video.g?token=' in link:
            referer =  'https://www.youtube.com/'
            #response = requests.get(link,headers=cls.headers)
            response = requests.get(link,headers=self.headers)
            cookie = response.cookies
            source = re.findall(r'play_url.+?"(.+?)","format_id":(.+?)}', response.text)
            if source:
                sources = [(self.itag_map.get(quality, 'Unknown Quality [%s]' % quality), stream.decode('unicode-escape') if six.PY2 else stream) for stream, quality in source]
        return sources, cookies, referer

    def select_video(self,sources):
        if sources:
            sources.sort(key=self.__key, reverse=True)
            video = self.pick_source(sources)
        else:
            video = ''
        return video

    def find_video(self,link):
        try:
            sources, cookies, referer = self.resolve_url(link)
            video = self.select_video(sources)
        except:
            cookies = None
            referer = None
            video = ''
        if video:
            if cookies:
                cookies_str = ";".join(["%s=%s"%(key,value) for key, value in cookies.items()])
                if referer:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Cookie=' + quote(cookies_str) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Cookie=' + quote(cookies_str)
            else:
                if referer:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(self.CHROME_USER_AGENT)
        return video 

    def soup(self,html):
        soup = BeautifulSoup(html,'html.parser')
        return soup                                     
    
    def rand_ua(self):
        RAND_UA = random.choice(self._USER_AGENTS)
        return RAND_UA
    
    def hentai_sem_censura(self,url=False):
        if not url:
            url = self.sitehentai + 'genero/hentai-sem-censura/' 
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            articles = soup.find('div', {'class': 'items full'}).find_all('article')
            for article in articles:
                tipo = article.get('class', '')[-1] # movies ou tvshows
                img = article.find('img').get('data-lazy-src', '')
                nome = article.find('div', {'class': 'data'}).find('h3').text
                href = article.find('div', {'class': 'data'}).find('h3').find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens.append((tipo,nome,img,href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        ### outro
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except:
            pass
        return itens, next, page


    def hentai_com_censura(self,url=False):
        if not url:
            url = self.sitehentai + 'genero/com-censura/' 
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            articles = soup.find('div', {'class': 'items full'}).find_all('article')
            for article in articles:
                tipo = article.get('class', '')[-1] # movies ou tvshows
                img = article.find('img').get('data-lazy-src', '')
                nome = article.find('div', {'class': 'data'}).find('h3').text
                href = article.find('div', {'class': 'data'}).find('h3').find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens.append((tipo,nome,img,href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        ### outro
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except:
            pass
        return itens, next, page        

    
    def temporadas(self,url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        list_seasons = []
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                name = '[B]TEMPORADA %s[/B]'%str(n)
                season = str(n)
                list_seasons.append((name,season,url))               
        except:
            pass
        return list_seasons

    def episodios(self,url,season):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        list_episodes = []
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                if n == int(season):
                    episodes = i.find('div', {'class': 'se-a'}).find('ul', {'class': 'episodios'}).find_all('li', class_=re.compile(r'^mark'))
                    for n2, i2 in enumerate(episodes):
                        n2 += 1
                        name = str(n2)
                        img = i2.find('div', {'class':'imagen'}).find('img').get('data-lazy-src', '')
                        href = i2.find('div', {'class': 'episodiotitle'}).find('a').get('href', '')
                        list_episodes.append((name,img,href))
                    break
        except:
            pass
        return list_episodes        

    def resolver_movies(self,url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        stream = ''
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            button = soup.find('div', {'class': 'su-button-center'}).find('a').get('href', '')
            headers.update({'Referer': url})
            r2 = requests.get(button, headers=headers)
            src2 = r2.text
            soup2 = self.soup(src2)
            video_id = soup2.find('li', {'id': 'player-option-1'}).get('data-post', '')
            url = 'https://hentailegendado.com/wp-json/dooplayer/v2/{}/tv/1'.format(str(video_id))
            r3 = requests.get(url,headers=headers)
            if r3.status_code == 200:
                data = r3.json()
                iframe = data.get('embed_url', '')
                if iframe:
                    stream = self.find_video(iframe)            
            # players = soup2.find('div', {'id': 'dooplay_player_content'}).find_all('div', class_=re.compile(r'^source-box'))
            # page_stream = ''
            # for player in players:
            #     id_ = player.get('id', '')
            #     if not 'trailer' in id_:
            #         iframe = player.find('div', {'class': 'pframe'}).find('iframe').get('src', '')
            #         if 'blogger' in iframe:
            #             page_stream += iframe
            #             break
            # if page_stream:
            #     stream += self.find_video(page_stream)            
        except:
            pass
        return stream

    def pesquisa_hentai(self,url,pesquisa):
        itens_pesquisa = []
        next = False
        page = ''
        if pesquisa:
            url = '%s?s=%s'%(self.sitehentai,quote_plus(pesquisa))
        try:
            headers = self.headers
            headers.update({'Referer': self.sitehentai})
            r = requests.get(url,headers=headers)
            src = r.text
            soup = self.soup(src)
            itens = soup.find('div', {'class': 'search-page'}).find_all('div', {'class': 'result-item'})
            for i in itens:
                thumb = i.find('article').find('div', {"class": 'image'}).find("div", class_=re.compile(r'^thumbnail'))
                img = thumb.find('a').find('img').get('src', '')
                try:
                    tipo = thumb.find('a').find('span').get('class', '')[-1]
                except:
                    tipo = thumb.find('a').find('span').get('class', '')
                nome = i.find('article').find('div', {"class": 'details'}).find('div', {'class': 'title'}).find('a').text
                href = i.find('article').find('div', {"class": 'details'}).find('div', {'class': 'title'}).find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens_pesquisa.append((tipo,nome,img,href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        ### outro
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except:
            pass
        return itens_pesquisa, next, page 

    def resolver_tvshows(self,url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        stream = ''
        try:
            r2 = requests.get(url,headers=headers)
            if r2.status_code == 200:
                src2 = r2.text
                soup2 = self.soup(src2)
                video_id = soup2.find('li', {'id': 'player-option-1'}).get('data-post', '')
                url = 'https://hentailegendado.com/wp-json/dooplayer/v2/{}/tv/1'.format(str(video_id))
                r = requests.get(url,headers=headers)
                if r.status_code == 200:
                    data = r.json()
                    iframe = data.get('embed_url', '')
                    if iframe:
                        stream = self.find_video(iframe)
        except:
            pass
        # try:
        #     r2 = requests.get(url, headers=headers)
        #     src2 = r2.text
        #     soup2 = self.soup(src2)
        #     players = soup2.find('div', {'id': 'dooplay_player_content'}).find_all('div', class_=re.compile(r'^source-box'))
        #     page_stream = ''
        #     for player in players:
        #         id_ = player.get('id', '')
        #         if not 'trailer' in id_:
        #             iframe = player.find('div', {'class': 'pframe'}).find('iframe').get('src', '')
        #             if 'blogger' in iframe:
        #                 page_stream += iframe
        #                 break
        #     if page_stream:
        #         stream += self.find_video(page_stream)            
        # except:
        #     pass
        return stream



