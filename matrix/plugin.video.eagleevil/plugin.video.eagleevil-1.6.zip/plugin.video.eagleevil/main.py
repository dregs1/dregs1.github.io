# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import html
import calendar
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime
from proxy_http_scraper import ProxyScraper
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
import proxy_http_scraper

from dns import customdns
customdns(cache_ttl=14400) 

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_HANDLE = int(sys.argv[1])

CONFIG_URL_PRINCIPAL_LISTA = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x74\x6c\x61\x62\x2e\x63\x6f\x6d\x2f\x61\x64\x64\x6f\x6e\x74\x6f\x70\x2f\x61\x70\x6b\x2f\x2d\x2f\x72\x61\x77\x2f\x6d\x61\x69\x6e\x2f\x78\x6d\x6c\x2f\x65\x76\x69\x6c\x2e\x78\x6d\x6c'
LAST_ACTIVE_SERVER_KEY = 'last_active_server_name' 

BASE_URL = '' 
USERNAME = ''
PASSWORD = ''

SERVER_LIST = []
ACTIVE_CONFIG = {} 

RETRY = ADDON.getSetting('retry') or 'false'
PROXY_HTTP = ADDON.getSetting('proxy_http') or 'false'
ENABLE_EPG = ADDON.getSetting('enable_epg') or 'false'

USE_F4MTESTER = ADDON.getSetting('use_f4mtester') or 'false'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}
HOME = ADDON.getAddonInfo('path')
addonIcon = xbmcvfs.translatePath(os.path.join(HOME, 'icon.png'))

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_XML_PATH = os.path.join(PROFILE_DIR, 'epg.xml')
EPG_META_PATH = os.path.join(PROFILE_DIR, 'epg_meta.json')
EPG_TTL = 24 * 3600

_EPG_PARSED = None

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

def show_dialog(title, message):
    xbmcgui.Dialog().ok(title, message)

def build_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdir(PROFILE_DIR)

def get_param_map():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        parsed = urllib.parse.urlparse(sys.argv[2])
        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        for k, v in q.items():
            params[k] = v[0] if isinstance(v, list) else v
    return params

def get_param(name, default=""):
    return PARAMS.get(name, default)

def fingerprint():
    return f"{BASE_URL}|{USERNAME}|{PASSWORD}"

def safe_requests_get(url, **kw):
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 15) # Timeout global reduzido para não travar o Kodi

    if PROXY_HTTP == 'true':
        try:
            # Proteção contra travamento do Scraper
            scraper = proxy_http_scraper.ProxyScraper()
            proxy = scraper.get_proxy()
            if proxy and isinstance(proxy, str):
                log(f"Proxy Ativado: {proxy}")
                kw['proxies'] = {"http": proxy, "https": proxy}
        except Exception as e:
            log(f"Erro no Scraper de Proxy: {e}. Ignorando proxy para evitar erro.")

    try:
        r = requests.get(url, **kw)
        r.raise_for_status()
        return r
    except Exception as e:
        log(f"Erro na requisição safe_get: {e}")
        # Se falhou COM proxy, tentamos uma última vez SEM proxy para garantir
        if 'proxies' in kw:
            log("Tentando novamente sem proxy...")
            kw.pop('proxies', None)
            return requests.get(url, **kw)
        raise

def load_server_list():
    """Tenta carregar a lista de servidores do JSON central."""
    global SERVER_LIST
    url = CONFIG_URL_PRINCIPAL_LISTA
    
    try:
        log(f"Tentando carregar lista de servidores de: {url}")
        r = requests.get(url, headers=HEADERS, timeout=10)
        r.raise_for_status()
        
        config_data = r.json()

        if isinstance(config_data, dict) and 'servidores' in config_data and isinstance(config_data['servidores'], list):
            SERVER_LIST = config_data['servidores']
            log(f"Sucesso ao carregar {len(SERVER_LIST)} servidores.", xbmc.LOGINFO)
            return SERVER_LIST
        
        log(f"JSON da URL {url} tem formato inválido. Deve conter a chave 'servidores'.", xbmc.LOGERROR)
        
    except Exception as e:
        log(f"Falha ao carregar a lista de servidores de {url}. {e}", xbmc.LOGERROR)
        
    SERVER_LIST = []
    return []

def apply_config(config_data):
    """Aplica uma configuração de servidor específica (host/usuário/senha)."""
    global BASE_URL, USERNAME, PASSWORD, _EPG_PARSED, ACTIVE_CONFIG

    if not config_data or not all(k in config_data for k in ['host', 'username', 'password']):
        log("Dados de configuração incompletos.", xbmc.LOGERROR)
        return False
        
    globals()['BASE_URL'] = config_data['host'].rstrip('/') if config_data['host'] else ''
    globals()['USERNAME'] = config_data['username'] or ''
    globals()['PASSWORD'] = config_data['password'] or ''
    globals()['_EPG_PARSED'] = None 
    globals()['ACTIVE_CONFIG'] = config_data 
    
    ADDON.setSetting(LAST_ACTIVE_SERVER_KEY, config_data.get('nome', ''))
    
    log(f"Configuração aplicada. Servidor ativo: {config_data.get('nome', 'Desconhecido')}")
    return True

def get_initial_credentials():
    """Tenta carregar as credenciais remotas (último ativo ou primeiro) ou usa as locais como fallback."""
    global SERVER_LIST

    SERVER_LIST = load_server_list()
    LAST_ACTIVE_SERVER_NAME = ADDON.getSetting(LAST_ACTIVE_SERVER_KEY)
    
    if SERVER_LIST:
        log("Lista de servidores remota carregada com sucesso.")
        
        initial_config = None
        for server in SERVER_LIST:
            if server.get('nome') == LAST_ACTIVE_SERVER_NAME:
                initial_config = server
                break

        if initial_config is None:
            initial_config = SERVER_LIST[0]

        if initial_config and apply_config(initial_config):
            return True

    log("Falha ao carregar config remota. Tentando credenciais locais nas configurações do Kodi.", xbmc.LOGWARNING)
    local_host = ADDON.getSetting('host') or ''
    local_username = ADDON.getSetting('username') or ''
    local_password = ADDON.getSetting('password') or ''
    
    if all([local_host, local_username, local_password]):
        log("Configurações locais encontradas. Aplicando como fallback.", xbmc.LOGINFO)
       
        temp_config = {
            'nome': 'Local (Fallback)',
            'host': local_host,
            'username': local_username,
            'password': local_password
        }
        apply_config(temp_config)
        
        return True

    log("Nenhuma credencial válida encontrada, remota ou local.", xbmc.LOGERROR)
    return False

def get_json(endpoint):

 
    if not all([BASE_URL, USERNAME, PASSWORD]):
        log("Credenciais incompletas (Locais ou Remotas).", xbmc.LOGERROR)
        show_dialog("Erro", "Configure o URL Remoto ou o Host/Usuário/Senha nas configurações.")
        return None

    url = f"{BASE_URL.rstrip('/')}/player_api.php?username={USERNAME}&password={PASSWORD}&{endpoint}"
    log(f"API: {url}")
    try:
        r = safe_requests_get(url)
        return r.json()
    except requests.RequestException as e:
        log(f"Erro na requisição: {e}", xbmc.LOGERROR)
        show_dialog("Erro", f"Falha na API: {e}")
    except ValueError:
        log(f"Resposta inválida (não-JSON) da API: {url}", xbmc.LOGERROR)
        show_dialog("Erro", "Resposta da API não é JSON válido.")
    return None

def epg_meta_load():
    if os.path.exists(EPG_META_PATH):
        try:
            with open(EPG_META_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def epg_meta_save(meta):
    try:
        with open(EPG_META_PATH, 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar meta EPG: {e}", xbmc.LOGERROR)

def epg_should_refresh():
    meta = epg_meta_load()
    fp = fingerprint()
    meta_fp = meta.get('fingerprint')
    fetched_at = meta.get('fetched_at', 0)
    if meta_fp != fp:
        log("Fingerprint mudou (host/usuário/senha). Renovando EPG.")
        return True
    if not os.path.exists(EPG_XML_PATH):
        log("EPG não existe. Baixando.")
        return True
    if (time.time() - fetched_at) >= EPG_TTL:
        log("EPG expirado. Renovando.")
        return True
    return False

def epg_download():
    ensure_profile_dir()
    url = f"{BASE_URL.rstrip('/')}/xmltv.php?username={USERNAME}&password={PASSWORD}"
    log(f"Baixando EPG: {url}")
    r = safe_requests_get(url)
    with open(EPG_XML_PATH, 'w', encoding='utf-8') as f:
        f.write(r.text)
    epg_meta_save({'fingerprint': fingerprint(), 'fetched_at': time.time()})

def parse_xmltv_time(ts):
    """Converte timestamp XMLTV para UNIX timestamp. Retorna agora() se inválido."""
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        log(f"Timestamp XMLTV inválido: {ts}")
        return int(time.time())
    
    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())
    
    offset_secs = 0
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = 0

    epoch = calendar.timegm(dt.timetuple()) - offset_secs
    return epoch if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    return cid.strip().lower().replace('&amp;', '&')

def epg_load_parsed():
    global _EPG_PARSED

    if epg_should_refresh():
        try:
            epg_download()
        except Exception as e:
            log(f"Falha ao baixar EPG: {e}", xbmc.LOGERROR)
            _EPG_PARSED = {'channels': {}, 'progs': {}}
            return _EPG_PARSED

    if not os.path.exists(EPG_XML_PATH):
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        return _EPG_PARSED

    try:
        tree = ET.parse(EPG_XML_PATH)
        root = tree.getroot()

        channels = {}
        progs = {}

        for c in root.findall(".//channel"):
            cid = normalize_epg_channel_id(c.get('id'))
            dn = (c.findtext('display-name') or '').strip()
            channels[cid] = dn

        for p in root.findall(".//programme"):
            cid = normalize_epg_channel_id(p.get('channel'))

            try:
                start = int(p.get('start_timestamp'))
            except (TypeError, ValueError):
                start = parse_xmltv_time(p.get('start'))

            try:
                stop = int(p.get('stop_timestamp') or p.get('end_timestamp'))
            except (TypeError, ValueError):
                stop = parse_xmltv_time(p.get('stop') or p.get('end'))

            if stop <= start:
                stop = start + 3600

            title = (p.findtext('title') or '').strip()
            desc = (p.findtext('desc') or '').strip()

            if cid not in progs:
                progs[cid] = []

            progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})

        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])

        _EPG_PARSED = {'channels': channels, 'progs': progs}
        log(f"EPG carregado: canais={len(channels)}, programas={sum(len(v) for v in progs.values())}")
    except Exception as e:
        log(f"Erro parseando EPG: {e}", xbmc.LOGERROR)
        _EPG_PARSED = {'channels': {}, 'progs': {}}

    return _EPG_PARSED

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    
    plist = epg['progs'].get(cid, [])
    current, nextp = None, None
    
    for i, pr in enumerate(plist):
        start = pr.get('start') or now
        end = pr.get('end') or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end
        
        if start <= now < end:
            current = pr
            if i + 1 < len(plist):
                nextp = plist[i + 1]
            break
        if start > now:
            nextp = pr
            if i - 1 >= 0 and plist[i-1]['end'] > now:
                current = plist[i-1]
            break

    return current, nextp

def build_menu(items, mode=None, is_playable=False):
    if not items:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for item in items:
        label = item.get('title', '')
        li = xbmcgui.ListItem(label=label)
        icon = item.get('icon', addonIcon)
        if icon:
            li.setArt({'icon': icon, 'thumb': icon})
        else:
            li.setArt({'icon': addonIcon, 'thumb': addonIcon})

        plot = item.get('plot', '') or ''
        if plot:
            li.setInfo('video', {'title': label, 'plot': plot})
        else:
            li.setInfo('video', {'title': label})

        if 'url' in item and is_playable:
            play = item['url'] + '|User-Agent=' + USER_AGENT
            if 'filme:' in label.lower() or 'live' in label.lower():
                params = {'mode': 'play', 'url': play, 'title': label, 'icon': icon, 'normalplayer': 'true'}
                url = build_url(**params)
            else:
                li.setProperty('IsPlayable', 'true')                
                url = build_url(mode='play', url=play)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': mode} if mode else {'mode': item.get('mode')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, item.get('folder', True))

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def get_categories(endpoint):
    data = get_json(endpoint)
    if not data:
        return []

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    items = []
    for cat in cats:
        name = html.unescape(cat.get('category_name', 'Sem nome'))
        if 'adult' in name.lower():
            continue
        items.append({
            'title': name,
            'params': f"category_id={cat.get('category_id', '')}"
        })
    return items

def ensure_epg_loaded():
    global _EPG_PARSED
    if _EPG_PARSED is None:
        _EPG_PARSED = epg_load_parsed()
    return _EPG_PARSED

def annotate_live_with_epg(items_from_api):
    epg = ensure_epg_loaded()
    out = []
    for s in items_from_api:
        name = s.get('title') or s.get('name') or 'Sem nome'
        epg_id = s.get('epg_channel_id')
        current, nextp = epg_lookup_current_next(epg_id, epg) if epg_id else (None, None)

        label = name
        plot = ''
        if current:
            label = f"{name} - {current.get('title', '').strip()}"
            plot += f"Agora: {current.get('title', '').strip()}\n{current.get('desc', '').strip()}\n\n"
        if nextp:
            plot += f"Próximo: {nextp.get('title', '').strip()}\n{nextp.get('desc', '').strip()}"

        s2 = dict(s)
        s2['title'] = label
        if plot.strip():
            s2['plot'] = plot.strip()
        out.append(s2)
    return out

def get_items(endpoint, category_id=None):
    params = f"&category_id={category_id}" if category_id else ""
    data = get_json(f"action={endpoint}{params}")
    if not data:
        return []

    items = []

    if endpoint in ['get_live_streams', 'get_vod_streams']:
        for s in data:
            url = s.get('stream_url', '')
            sid = s.get('stream_id')
            stype = s.get('stream_type', '')
            name = html.unescape(s.get('name', 'Sem nome'))
            icon = s.get('stream_icon', '')
            epg_channel_id = s.get('epg_channel_id') or None

            if sid:
                if endpoint == 'get_live_streams':
                    url = f'{BASE_URL.rstrip("/")}/live/{USERNAME}/{PASSWORD}/{sid}.m3u8'
                else:
                    ext = 'mp4'
                    url = f'{BASE_URL.rstrip("/")}/{stype}/{USERNAME}/{PASSWORD}/{sid}.{ext}'

            item = {'title': name, 'url': url, 'icon': icon}
            if epg_channel_id:
                item['epg_channel_id'] = epg_channel_id
            items.append(item)

        if endpoint == 'get_live_streams':
            if ENABLE_EPG.lower() == 'true':
                items = annotate_live_with_epg(items)

    elif endpoint == 'get_series':
        for s in data:
            icon = (s.get('info', {}) or {}).get('cover_big') or (s.get('info', {}) or {}).get('movie_image', '')
            if not icon:
                icon = s.get('cover') if s.get('cover') else s.get('backdrop_path', [''])[0]
            items.append({
                'title': html.unescape(s.get('name', 'Sem nome')),
                'params': f"series_id={s.get('series_id', '')}",
                'icon': icon
            })

    return items


def get_seasons(series_id):
    data = get_json(f"action=get_series_info&series_id={series_id}")
    if not data:
        return []

    seasons = data.get('episodes', {})
    items = []
    for season_name, episodes in seasons.items():
        ep_list = []
        for index, ep in enumerate(episodes):
            index += 1
            title = html.unescape(ep.get('title', 'Sem título'))
            eid = ep.get('id') or ep.get('episode_id') or ep.get('stream_id')
            ext = (ep.get('info', {}) or {}).get('container_extension') or 'mp4'
            icon = (ep.get('info', {}) or {}).get('cover_big') or (ep.get('info', {}) or {}).get('movie_image', '')
            url = f"{BASE_URL.rstrip('/')}/series/{USERNAME}/{PASSWORD}/{eid}.{ext}" if eid else ep.get('direct_source', '')
            ep_list.append({'title': str(index) + ' - ' + title, 'url': url, 'icon': icon})

        payload = urllib.parse.quote(json.dumps(ep_list, ensure_ascii=False), safe='')
        items.append({
            'title': f"Temporada {season_name}",
            'params': f"episodes={payload}&series_id={series_id}"
        })
    return items

def search_global(query):
    results = []
    for endpoint, prefix, playable in [
        ('get_live_streams', 'Live: ', True),
        ('get_vod_streams', 'Filme: ', True),
        ('get_series', 'Série: ', False)
    ]:
        items = get_items(endpoint)
        for i in items:
            if query.lower() in i['title'].lower():
                entry = {'title': prefix + i['title'], 'icon': i.get('icon', '')}
                if playable:
                    entry['url'] = i['url']
                    entry['plot'] = i.get('plot', '')
                else:
                    entry['mode'] = 'seasons'
                    entry['params'] = i.get('params', '')
                results.append(entry)
    if not results:
        show_dialog("Aviso", "Nenhum resultado encontrado.")
    return results

def get_account_info():
    data = get_json("")
    if not data:
        return None

    user_info = data.get('user_info', {})
    if not user_info:
        log("Nenhuma informação de usuário retornada pela API.", xbmc.LOGERROR)
        show_dialog("Erro", "Não foi possível obter informações da conta.")
        return None

    username = user_info.get('username', 'Não informado')
    status = user_info.get('status', 'Não informado')
    max_connections = user_info.get('max_connections', 'Não informado')
    active_connections = user_info.get('active_cons', 'Não informado')

    created_at = user_info.get('created_at', 0)
    exp_date = user_info.get('exp_date', 0)

    try:
        created_at_str = datetime.fromtimestamp(int(created_at)).strftime('%d/%m/%Y') if created_at and str(created_at).isdigit() else 'Não informado'
    except Exception:
        created_at_str = 'Não informado'

    try:
        exp_date_str = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y') if exp_date and str(exp_date).isdigit() else 'Não informado'
    except Exception:
        exp_date_str = 'Não informado'

    info_text = (
        f"Nome de Usuário: {username}\n"
        f"Status: {status}\n"
        f"Data de Criação: {created_at_str}\n"
        f"Data de Vencimento: {exp_date_str}\n"
        f"Conexões Máximas: {max_connections}\n"
        f"Conexões Ativas: {active_connections}"
    )

    return info_text

def play_item(url, title, icon, normalplayer):
    """
    Controla a reprodução do item, permitindo a escolha entre Player Interno (com Proxy) ou f4mTester.
    """

    if USE_F4MTESTER == 'true':
        try:
            
            clean_url = url.split('|')[0]
        except:
            clean_url = url
            
        
        f4m_url = f"plugin://plugin.video.f4mTester/?url={urllib.parse.quote_plus(clean_url)}&name={urllib.parse.quote_plus(title)}"
        
        li = xbmcgui.ListItem(path=f4m_url)
        li.setArt({'icon': icon, 'thumb': icon})
        li.setInfo('video', {'title': title})
        
        log(f"Reproduzindo com f4mTester: {f4m_url}", xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
        return  
    
    import proxy
    PORT = proxy.PORT
    if RETRY == 'true':
        try:
            url = url.split('|')[0]
        except:
            pass          
        if '.m3u8' in url:        
            url_proxy = "http://127.0.0.1:{}/hlsretry?url=".format(PORT)
        else:
            url_proxy = "http://127.0.0.1:{}/mp4proxy?url=".format(PORT)
        url = url_proxy + url
    else:
        try:
            url = url.split('|')[0]
        except:
            pass          
        if '.m3u8' in url:
            url = url.replace('live/', '').replace('.m3u8', '')
            url_proxy = "http://127.0.0.1:{}/tsdownloader?url=".format(PORT)
        else:
            url_proxy = "http://127.0.0.1:{}/mp4proxy?url=".format(PORT)
        url = url_proxy + url
    proxy.kodiproxy()
    if normalplayer == 'false': 
        li = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
    else:
        li = xbmcgui.ListItem(label=title, path=url)
        li.setArt({'icon': icon, 'thumb': icon})
        li.setInfo('video', {'title': title})
        player = xbmc.Player()
        player.play(item=url, listitem=li)

PARAMS = get_param_map()
mode = get_param('mode', 'main')
log(f"Modo: {mode}")

get_initial_credentials()

if mode == 'main':

    if not BASE_URL or not USERNAME or not PASSWORD:
        log("Credenciais faltando. Abrindo configurações.", xbmc.LOGWARNING)
        show_dialog("Configuração Necessária", "Preencha o Host/Usuário/Senha nas configurações ou garanta que a lista de servidores remota está acessível.")
        ADDON.openSettings()

    items = [
      
        {'title': '[COLORred]Eag[COLORgrey]le [COLORgold]Evil[/COLOR] [COLOR orange]Mudar Servidor[/COLOR]', 'mode': 'select_config'},
        {'title': '[COLORred]Eag[COLORgrey]le [COLORgold]Evil[/COLOR] [COLOR orange]TV Canais Ao Vivo[/COLOR]', 'mode': 'tv'},
        {'title': '[COLORred]Eag[COLORgrey]le [COLORgold]Evil[/COLOR] [COLOR orange]Filmes[/COLOR]', 'mode': 'movies'},
        {'title': '[COLORred]Eag[COLORgrey]le [COLORgold]Evil[/COLOR] [COLOR orange]Séries[/COLOR]', 'mode': 'series'},
        {'title': '[COLORred]Eag[COLORgrey]le [COLORgold]Evil[/COLOR] [COLOR orange]Configurações[/COLOR]', 'mode': 'settings'}
    ]
    
    if not SERVER_LIST or len(SERVER_LIST) <= 1:
        items = [i for i in items if i['mode'] != 'select_config']
        
    build_menu(items)

elif mode == 'enter':

    pass

elif mode == 'account_info':
    info_text = get_account_info()
    if info_text:
        
        server_name = ACTIVE_CONFIG.get('nome', 'N/A')
        info_text = f"Servidor Ativo: {server_name}\n\n{info_text}"
        xbmcgui.Dialog().textviewer("Informações da Conta", info_text)
    else:
        show_dialog("Erro", "Não foi possível obter informações da conta.")

elif mode == 'select_config':
    items = []
    current_server_name = ACTIVE_CONFIG.get('nome')
    for index, server in enumerate(SERVER_LIST):
        name = server.get('nome', f"Servidor {index + 1}")
        
        display_name = f"[ATIVO] {name}" if name == current_server_name else name
        
        items.append({
            'title': display_name,
            'mode': 'apply_config_by_index',
            'params': f"server_index={index}" 
        })
    build_menu(items, mode='apply_config_by_index')

elif mode == 'apply_config_by_index':
    try:
        index = int(get_param('server_index'))
    except ValueError:
        index = -1
        
    if 0 <= index < len(SERVER_LIST):
        new_config = SERVER_LIST[index]
        if apply_config(new_config):
            show_dialog("Sucesso", f"Configuração de servidor atualizada. Servidor: {new_config.get('nome', 'Desconhecido')}")
        else:
            show_dialog("Erro", f"Falha ao aplicar configuração do servidor: {new_config.get('nome', 'Desconhecido')}.")
    else:
        show_dialog("Erro", "Índice de servidor inválido.")

    xbmc.executebuiltin('Container.Refresh()')


elif mode == 'settings':
    ADDON.openSettings()

elif mode == 'tv':
    build_menu(get_categories('action=get_live_categories'), 'live_items')

elif mode == 'live_items':
    cid = get_param('category_id')
    build_menu(get_items('get_live_streams', cid), is_playable=True)

elif mode == 'movies':
    build_menu(get_categories('action=get_vod_categories'), 'movie_items')

elif mode == 'movie_items':
    cid = get_param('category_id')
    build_menu(get_items('get_vod_streams', cid), is_playable=True)

elif mode == 'series':
    build_menu(get_categories('action=get_series_categories'), 'series_items')

elif mode == 'series_items':
    cid = get_param('category_id')
    build_menu(get_items('get_series', cid), 'seasons')

elif mode == 'seasons':
    sid = get_param('series_id')
    build_menu(get_seasons(sid), 'episodes')

elif mode == 'episodes':
    eps_json = urllib.parse.unquote(get_param('episodes', '[]'))
    eps = json.loads(eps_json)
    build_menu(eps, is_playable=True)

elif mode == 'search':
    kb = xbmc.Keyboard('', 'Digite o que deseja buscar')
    kb.doModal()
    if kb.isConfirmed():
        query = kb.getText()
        build_menu(search_global(query), is_playable=True)

elif mode == 'play':
    url = get_param('url')
    normalplayer = get_param('normalplayer', 'false')
    title = get_param('title', 'Reproduzindo')
    icon = get_param('icon', addonIcon)
    play_item(url, title, icon, normalplayer)

else:
    show_dialog("Erro", f"Modo desconhecido: {mode}")
