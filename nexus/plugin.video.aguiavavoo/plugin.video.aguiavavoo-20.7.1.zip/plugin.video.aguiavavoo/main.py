# -*- coding: utf-8 -*-
"""
Aguia Vavoo - Kodi 19/20/21 Compatible Entry Point
"""

import sys
import json
import xbmc
import xbmcgui
import xbmcaddon

from resources.lib import utils
from resources.lib import vjlive
from resources.lib import vjackson


def run():

    params = {}

    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(utils.parse_qsl(sys.argv[2][1:]))

    channel_name = params.get("name")
    action = params.pop("action", None)

    if channel_name and action == "addTvFavorit":
        vjlive.change_favorit(channel_name, group=params.get("group", ""))

    elif channel_name and action == "delTvFavorit":
        vjlive.change_favorit(channel_name, delete=True)

    elif channel_name and action == "renameTvFavorit":
        vjlive.rename_favorit_dialog(channel_name)

    elif channel_name and action == "moveTvFavoritUp":
        vjlive.move_favorit_logic(channel_name, "up")

    elif channel_name and action == "moveTvFavoritDown":
        vjlive.move_favorit_logic(channel_name, "down")

    elif channel_name:
        urls = None
        urls_param = params.get("urls")

        if urls_param:
            try:
                urls = json.loads(urls_param)
            except:
                urls = None

        vjlive.livePlay(channel_name, urls, group=params.get("group"))

    elif action is None:
        vjackson._index(params)

    elif action == "show_countries":
        vjackson._show_countries(params)

    elif action == "channels":
        vjlive.channels()

    elif action == "channelsbycategory":
        vjlive.channels_by_group(params.get("group", "Portugal"))

    elif action == "settings":
        xbmcaddon.Addon().openSettings()

    elif action == "livecategories":
        vjackson._livecategories(params)

    elif action == "favchannels":
        vjlive.favchannels()

    elif action == "makem3u":
        vjlive.makem3u(params.get("group"))

    elif action == "delallTvFavorit":
        utils.clear_all_favorites()
        utils.notify("All TV Favorites removed")
        xbmc.executebuiltin("Container.Refresh")

    else:
        handler = getattr(vjackson, f"_{action}", None)

        if handler:
            handler(params)
        else:
            utils.log(f"Unknown action: {action}", "main")


if __name__ == "__main__":
    run()
