import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

sys.path.insert(0, os.path.join(ADDON_PATH, "resources", "lib"))
from scraper import GENRES, get_genre_movies, search_movies, get_movie_details
from tmdb import get_movie_info
from disclaimer import DisclaimerDialog

try:
    from urllib.parse import parse_qs, urlencode, quote_plus, unquote_plus
except ImportError:
    from urlparse import parse_qs
    from urllib import urlencode, quote_plus, unquote_plus


def build_url(params):
    return BASE_URL + "?" + urlencode({k: v for k, v in params.items() if v is not None})


def get_params():
    return {k: v[0] for k, v in parse_qs(sys.argv[2][1:]).items()}


def show_disclaimer():
    """
    Always shows the full-screen disclaimer when the addon root is opened.
    Never skipped, never cached — must press LET ME IN!! every time.
    """
    dialog = DisclaimerDialog("Disclaimer.xml", ADDON_PATH)
    dialog.doModal()
    result = getattr(dialog, "accepted", False)
    del dialog
    if not result:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        sys.exit()


def get_genre_icon(slug):
    icon_path = os.path.join(ADDON_PATH, "resources", "media", "genre_icons", slug + ".png")
    if os.path.exists(icon_path):
        return icon_path
    return os.path.join(ADDON_PATH, "icon.png")


def list_genres():
    xbmcplugin.setPluginCategory(HANDLE, "Effed Up Movies")
    xbmcplugin.setContent(HANDLE, "movies")

    fanart = os.path.join(ADDON_PATH, "fanart.jpg")

    for genre in GENRES:
        slug = genre["slug"]
        name = genre["name"]
        icon = get_genre_icon(slug)

        li = xbmcgui.ListItem(label=name)
        li.setArt({"thumb": icon, "icon": icon, "fanart": fanart, "poster": icon})
        li.setInfo("video", {"title": name, "mediatype": "video"})

        if slug == "__search__":
            url = build_url({"action": "search"})
        else:
            url = build_url({"action": "genre", "slug": slug, "page": "1"})

        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)


def list_movies(slug, page=1):
    xbmcplugin.setContent(HANDLE, "movies")

    genre_name = next((g["name"] for g in GENRES if g["slug"] == slug), slug)
    xbmcplugin.setPluginCategory(HANDLE, genre_name)

    api_key = ADDON.getSetting("tmdb_api_key").strip()
    fanart = os.path.join(ADDON_PATH, "fanart.jpg")
    default_thumb = os.path.join(ADDON_PATH, "icon.png")

    movies = get_genre_movies(slug, page=page)

    if not movies and page == 1:
        xbmcgui.Dialog().notification(ADDON_NAME, "No movies found", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for movie in movies:
        title = movie.get("title", "Unknown")
        year = movie.get("year", "")
        thumb = movie.get("thumb") or default_thumb
        movie_url = movie.get("url", "")

        info = get_movie_info(api_key, title, year=year, fallback_poster=thumb)

        poster = info.get("poster") or thumb
        fanart_art = info.get("fanart") or fanart
        plot = info.get("plot", "")
        rating = info.get("rating", "")
        display_year = info.get("year") or year

        li = xbmcgui.ListItem(label=title)
        li.setArt({
            "thumb": poster,
            "poster": poster,
            "fanart": fanart_art,
            "icon": poster,
        })
        li.setInfo("video", {
            "title": title,
            "year": int(display_year) if display_year.isdigit() else 0,
            "plot": plot,
            "rating": float(rating) if rating else 0.0,
            "mediatype": "movie",
        })
        li.setProperty("IsPlayable", "true")

        url = build_url({
            "action": "play",
            "movie_url": quote_plus(movie_url),
            "title": title,
            "thumb": poster,
        })
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    if movies:
        next_icon = get_genre_icon("__latest__")
        next_li = xbmcgui.ListItem(label="[COLOR red]>> Load More[/COLOR]")
        next_li.setArt({"thumb": next_icon, "icon": next_icon, "fanart": fanart})
        next_li.setInfo("video", {"title": "Load More", "mediatype": "video"})
        next_url = build_url({"action": "genre", "slug": slug, "page": str(page + 1)})
        xbmcplugin.addDirectoryItem(HANDLE, next_url, next_li, isFolder=True)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, updateListing=False, cacheToDisc=False)


def do_search():
    keyboard = xbmc.Keyboard("", "Search Effed Up Movies")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    api_key = ADDON.getSetting("tmdb_api_key").strip()
    fanart = os.path.join(ADDON_PATH, "fanart.jpg")
    default_thumb = os.path.join(ADDON_PATH, "icon.png")

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.setPluginCategory(HANDLE, 'Search: "{}"'.format(query))

    movies = search_movies(query)
    if not movies:
        xbmcgui.Dialog().notification(ADDON_NAME, "No results found", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for movie in movies:
        title = movie.get("title", "Unknown")
        year = movie.get("year", "")
        thumb = movie.get("thumb") or default_thumb
        movie_url = movie.get("url", "")

        info = get_movie_info(api_key, title, year=year, fallback_poster=thumb)
        poster = info.get("poster") or thumb
        fanart_art = info.get("fanart") or fanart
        plot = info.get("plot", "")
        rating = info.get("rating", "")
        display_year = info.get("year") or year

        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": poster, "poster": poster, "fanart": fanart_art, "icon": poster})
        li.setInfo("video", {
            "title": title,
            "year": int(display_year) if display_year.isdigit() else 0,
            "plot": plot,
            "rating": float(rating) if rating else 0.0,
            "mediatype": "movie",
        })
        li.setProperty("IsPlayable", "true")

        url = build_url({
            "action": "play",
            "movie_url": quote_plus(movie_url),
            "title": title,
            "thumb": poster,
        })
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def play_movie(movie_url, title="", thumb=""):
    decoded_url = unquote_plus(movie_url)
    xbmc.log("[EUM] Fetching: {}".format(decoded_url), xbmc.LOGINFO)

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Finding stream...")
    progress.update(30, "Scanning page for HLS stream...")

    hls_url, plot, site_poster = get_movie_details(decoded_url)

    progress.update(80, "Preparing playback...")

    if not hls_url:
        progress.close()
        xbmcgui.Dialog().notification(ADDON_NAME, "Stream not found on this page", xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    xbmc.log("[EUM] HLS found: {}".format(hls_url), xbmc.LOGINFO)
    progress.update(100, "Starting...")
    progress.close()

    li = xbmcgui.ListItem(path=hls_url)
    li.setMimeType("application/x-mpegURL")
    li.setContentLookup(False)
    li.setArt({"thumb": thumb or site_poster, "icon": thumb or site_poster})
    li.setInfo("video", {"title": title, "plot": plot or "", "mediatype": "movie"})
    li.setProperty("inputstream", "inputstream.adaptive")
    li.setProperty("inputstream.adaptive.manifest_type", "hls")

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def main():
    params = get_params()
    action = params.get("action", "")

    if action == "":
        # Root menu — show disclaimer EVERY time before showing genres
        show_disclaimer()
        list_genres()
    elif action == "genre":
        slug = params.get("slug", "")
        page = int(params.get("page", 1))
        list_movies(slug, page=page)
    elif action == "search":
        do_search()
    elif action == "play":
        play_movie(
            params.get("movie_url", ""),
            title=params.get("title", ""),
            thumb=params.get("thumb", ""),
        )


if __name__ == "__main__":
    main()
