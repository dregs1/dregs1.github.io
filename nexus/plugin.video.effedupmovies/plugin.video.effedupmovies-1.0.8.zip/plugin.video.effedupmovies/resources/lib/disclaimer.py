import xbmcgui
import xbmcaddon
import os


class DisclaimerDialog(xbmcgui.WindowXMLDialog):
    """
    Full-screen disclaimer — blocks the addon until "LET ME IN!!" is clicked.
    Shows EVERY time the addon root is opened (no "already seen" persistence).
    Back/Escape keys are swallowed so the user MUST press the button.
    """

    def __init__(self, *args, **kwargs):
        self.accepted = False
        super(DisclaimerDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        # Belt-and-suspenders: also set via Python in case special:// in XML fails
        try:
            addon = xbmcaddon.Addon()
            addon_path = addon.getAddonInfo("path")
            warning_img = os.path.join(addon_path, "resources", "media", "warning.jpg")
            # Normalise separators for Windows
            warning_img = warning_img.replace("\\", "/")
            img_ctrl = self.getControl(1)
            img_ctrl.setImage(warning_img)
        except Exception:
            pass

    def onAction(self, action):
        # Swallow ALL back/escape/close actions — user MUST press the button
        # Action IDs: 92=Back, 10=PrevMenu, 13=NAV_BACK, 9=Parent
        blocked = (92, 10, 13, 9, 107, 117)
        if action.getId() in blocked:
            return  # do nothing — dialog stays open
        # Do NOT call super() for any nav action to prevent accidental close

    def onClick(self, control_id):
        if control_id == 100:
            self.accepted = True
            self.close()
