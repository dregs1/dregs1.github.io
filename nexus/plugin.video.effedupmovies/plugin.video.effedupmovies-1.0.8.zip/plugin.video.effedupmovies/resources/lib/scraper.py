"""
EUM scraper — zero external dependencies.
Uses urllib (always available in Kodi Python 3) and regex only.
No BeautifulSoup, no requests.
"""

import re
import json
import ssl
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, quote_plus
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError
    from urllib import urlencode, quote_plus

# Windows Kodi Python often fails SSL cert verification.
# Build a permissive context once and reuse it everywhere.
try:
    _SSL_CTX = ssl.create_default_context()
    _SSL_CTX.check_hostname = False
    _SSL_CTX.verify_mode = ssl.CERT_NONE
except Exception:
    _SSL_CTX = None

BASE_URL = "https://www.effedupmovies.com"
WP_API   = BASE_URL + "/wp-json/wp/v2"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
      "AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/120.0.0.0 Safari/537.36")

# ---------------------------------------------------------------------------
# Genre list — real WordPress category slugs and IDs from the live site
# ---------------------------------------------------------------------------
GENRES = [
    {"name": "Latest",                         "slug": "__latest__",                    "cat_id": None},
    {"name": "Search",                         "slug": "__search__",                    "cat_id": None},
    {"name": "Gore / Gruesome / Splatter",     "slug": "gore-gruesome-splatter",        "cat_id": 8},
    {"name": "Sexual Violence Against Women",  "slug": "rape-sexual-violence-against-women", "cat_id": 7},
    {"name": "Sexual Violence Against Men",    "slug": "rape-sexual-violence-against-men",   "cat_id": 6},
    {"name": "Torture",                        "slug": "torture",                       "cat_id": 9},
    {"name": "Self Harm / Suicide",            "slug": "self-mutilation",               "cat_id": 95},
    {"name": "Snuff",                          "slug": "snuff-film",                    "cat_id": 40},
    {"name": "Serial Killers",                 "slug": "serial-killers",                "cat_id": 10},
    {"name": "Captivity / Kidnapping",         "slug": "abduction",                     "cat_id": 33},
    {"name": "Cannibalism",                    "slug": "cannibalism",                   "cat_id": 49},
    {"name": "Scat",                           "slug": "coprophilia",                   "cat_id": 39},
    {"name": "Pissing",                        "slug": "pee-golden-showers",            "cat_id": 77},
    {"name": "Puking",                         "slug": "vomit",                         "cat_id": 76},
    {"name": "BDSM / Roleplay",                "slug": "bdsm",                          "cat_id": 12},
    {"name": "Detective / Mystery",            "slug": "mystery",                       "cat_id": 20},
    {"name": "Revenge",                        "slug": "revenge",                       "cat_id": 23},
    {"name": "Cult / Commune",                 "slug": "cult",                          "cat_id": 147},
    {"name": "Shockumentary / Documentary",    "slug": "documentary",                   "cat_id": 159},
    {"name": "Insects / Small Animals",        "slug": "formicophilia",                 "cat_id": 79},
    {"name": "Obesity / Eating",               "slug": "food-play",                     "cat_id": 88},
    {"name": "Drugs",                          "slug": "junkie",                        "cat_id": 121},
    {"name": "Medical",                        "slug": "medical",                       "cat_id": 246},
    {"name": "Scars / Body Modification",      "slug": "scars-body-modification",       "cat_id": 86},
    {"name": "Bizarre / Surreal",              "slug": "bizarre-surreal",               "cat_id": 47},
    {"name": "Necrophilia",                    "slug": "necrophilia",                   "cat_id": 48},
    {"name": "Mass Killings",                  "slug": "mass-killings",                 "cat_id": 160},
    {"name": "Based on a True Story",          "slug": "movies-based-on-a-true-story",  "cat_id": 60},
    {"name": "Older / Younger",                "slug": "old-young-relationships",       "cat_id": 17},
    {"name": "Teen / Childhood",               "slug": "teensploitation",               "cat_id": 59},
    {"name": "Incest",                         "slug": "incest",                        "cat_id": 36},
    {"name": "Domestic Abuse",                 "slug": "domestic-violence",             "cat_id": 37},
    {"name": "Trafficking / Prostitution",     "slug": "human-trafficking",             "cat_id": 32},
    {"name": "Satanism / Occult",              "slug": "satanism",                      "cat_id": 75},
    {"name": "Nazism / Fascism",               "slug": "nazism",                        "cat_id": 19},
    {"name": "Racism",                         "slug": "racist",                        "cat_id": 98},
    {"name": "Voyeur / Stalking",              "slug": "voyeur",                        "cat_id": 29},
    {"name": "Misery / Depression",            "slug": "depressing",                    "cat_id": 30},
    {"name": "Religion",                       "slug": "religion",                      "cat_id": 18},
    {"name": "Siblings / Family",              "slug": "brothers-sisters-family",       "cat_id": 87},
    {"name": "Horror",                         "slug": "horror",                        "cat_id": 26},
]


# ---------------------------------------------------------------------------
# HTTP helpers — urllib only, no requests
# ---------------------------------------------------------------------------

def _http_get(url, params=None):
    if params:
        url = url + "?" + urlencode(params)
    xbmc.log("[EUM] GET " + url, xbmc.LOGINFO)
    req = Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    try:
        # Pass SSL context so Windows Kodi Python doesn't fail cert verification
        kwargs = {"timeout": 20}
        if _SSL_CTX:
            kwargs["context"] = _SSL_CTX
        resp = urlopen(req, **kwargs)
        raw = resp.read()
        return raw.decode("utf-8", errors="replace")
    except Exception as e:
        xbmc.log("[EUM] HTTP error: " + str(e), xbmc.LOGWARNING)
        return None


def _get_json(url, params=None):
    body = _http_get(url, params)
    if not body:
        return None
    try:
        return json.loads(body)
    except Exception as e:
        xbmc.log("[EUM] JSON parse error: " + str(e), xbmc.LOGWARNING)
        return None


def _get_html(url):
    return _http_get(url)


# ---------------------------------------------------------------------------
# Regex-based HTML/text helpers (no BeautifulSoup)
# ---------------------------------------------------------------------------

def _html_text(html_fragment):
    """Strip HTML tags from a fragment."""
    return re.sub(r"<[^>]+>", "", html_fragment or "").strip()


def _clean_title(raw):
    title = _html_text(raw)
    title = re.sub(r"\s*[\(\[]\d{4}[\)\]]\s*$", "", title).strip()
    title = re.sub(
        r"\s+(?:uncut\s+)?full\s+movie.*$"
        r"|\s+watch\s+online.*$"
        r"|\s+\bHD\b.*$"
        r"|\s+eng(?:lish)?\s+subs?.*$",
        "", title, flags=re.I).strip()
    return title


def _year_from(text):
    m = re.search(r"\b(19|20)\d{2}\b", text or "")
    return m.group(0) if m else ""


# ---------------------------------------------------------------------------
# Convert WP REST post objects → movie dicts
# ---------------------------------------------------------------------------

def _posts_to_movies(posts):
    movies = []
    if not isinstance(posts, list):
        return movies
    for post in posts:
        try:
            title_html = (post.get("title") or {}).get("rendered") or ""
            title = _clean_title(title_html)
            url   = post.get("link", "")
            date  = post.get("date", "") or ""
            year  = date[:4] if date else _year_from(title + " " + url)

            # Thumbnail from embedded featured media
            thumb = ""
            embedded = post.get("_embedded") or {}
            fm_list  = embedded.get("wp:featuredmedia") or []
            if fm_list and isinstance(fm_list, list) and fm_list[0]:
                fm    = fm_list[0]
                sizes = (fm.get("media_details") or {}).get("sizes") or {}
                for sz in ("large", "medium_large", "medium", "full"):
                    s = sizes.get(sz) or {}
                    if s.get("source_url"):
                        thumb = s["source_url"]
                        break
                if not thumb:
                    thumb = fm.get("source_url", "")

            if url and title:
                movies.append({"title": title, "year": year, "url": url, "thumb": thumb})
        except Exception as e:
            xbmc.log("[EUM] post parse error: " + str(e), xbmc.LOGWARNING)
    return movies


# ---------------------------------------------------------------------------
# HTML category-page scraper (fallback path)
# ---------------------------------------------------------------------------

def _scrape_category_page(slug, page=1):
    if not slug:
        url = BASE_URL + ("/page/{}/".format(page) if page > 1 else "/")
    else:
        url = "{}/category/{}/".format(BASE_URL, slug)
        if page > 1:
            url += "page/{}/".format(page)

    html = _get_html(url)
    if not html:
        return []

    movies = []
    # Find all <article ...> blocks
    articles = re.findall(r"<article[^>]*>(.*?)</article>", html, re.S | re.I)
    for art in articles:
        item = _parse_article_html(art)
        if item and item.get("url") and item.get("title"):
            movies.append(item)
    return movies


def _parse_article_html(art_html):
    try:
        # Title + URL from <h1> or <h2> with an <a href>
        m = re.search(
            r'<h[12][^>]*>.*?<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
            art_html, re.S | re.I)
        if not m:
            m = re.search(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>',
                          art_html, re.S | re.I)
        if not m:
            return None
        url   = m.group(1).strip()
        title = _clean_title(m.group(2))

        # Thumbnail — data-src first (lazy load), then src
        img = re.search(r'<img[^>]+>', art_html, re.I)
        thumb = ""
        if img:
            tag = img.group(0)
            ds = re.search(r'data-src=["\']([^"\']+)["\']', tag, re.I)
            src = re.search(r'\bsrc=["\']([^"\']+)["\']', tag, re.I)
            thumb = (ds.group(1) if ds else "") or (src.group(1) if src else "")

        year = _year_from(title + " " + url)
        return {"title": title, "year": year, "url": url, "thumb": thumb}
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_genre_movies(slug, page=1):
    if slug == "__latest__":
        return get_latest_movies(page=page)

    genre  = next((g for g in GENRES if g["slug"] == slug), None)
    cat_id = genre["cat_id"] if genre else None

    # PATH A — WP REST API by category ID (fastest, cleanest)
    if cat_id:
        posts = _get_json(WP_API + "/posts", {
            "categories": cat_id,
            "page":       page,
            "per_page":   20,
            "_embed":     1,
            "status":     "publish",
            "orderby":    "date",
            "order":      "desc",
        })
        if isinstance(posts, list) and posts:
            return _posts_to_movies(posts)
        xbmc.log("[EUM] REST returned empty for cat_id={}, trying HTML".format(cat_id), xbmc.LOGINFO)

    # PATH B — HTML scrape of /category/<slug>/
    movies = _scrape_category_page(slug, page=page)
    return movies


def get_latest_movies(page=1):
    posts = _get_json(WP_API + "/posts", {
        "page":    page,
        "per_page": 20,
        "_embed":  1,
        "status":  "publish",
        "orderby": "date",
        "order":   "desc",
    })
    if isinstance(posts, list) and posts:
        movies = _posts_to_movies(posts)
        filtered = [m for m in movies if m.get("year") in {"2025", "2026", "2027"}]
        return filtered if filtered else movies

    return _scrape_category_page("", page=page)


def search_movies(query, page=1):
    posts = _get_json(WP_API + "/posts", {
        "search":  query,
        "page":    page,
        "per_page": 20,
        "_embed":  1,
        "status":  "publish",
    })
    if isinstance(posts, list) and posts:
        return _posts_to_movies(posts)

    url  = "{}/?s={}".format(BASE_URL, quote_plus(query))
    html = _get_html(url)
    if not html:
        return []
    movies = []
    for art in re.findall(r"<article[^>]*>(.*?)</article>", html, re.S | re.I):
        item = _parse_article_html(art)
        if item and item.get("url"):
            movies.append(item)
    return movies


# ---------------------------------------------------------------------------
# Individual movie page — extract HLS stream
# ---------------------------------------------------------------------------

def get_movie_details(movie_url):
    html = _get_html(movie_url)
    if not html:
        return None, None, None
    return _extract_hls(html), _extract_plot(html), _extract_poster(html)


def _extract_hls(html):
    # Direct .m3u8 URL anywhere in the page
    m = re.search(r'(https?://[^\s\'"<>]+\.m3u8(?:\?[^\s\'"<>]*)?)', html, re.I)
    if m:
        return m.group(1)

    # file: / src: / source: patterns
    m = re.search(
        r'(?:file|src|source)\s*[=:]\s*["\']?(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)',
        html, re.I)
    if m:
        return m.group(1)

    # JSON key patterns
    m = re.search(r'"(?:file|src|url|source)"\s*:\s*"(https?://[^"]+\.m3u8[^"]*)"', html)
    if m:
        return m.group(1)

    # Dig into iframes
    for iframe_src in re.findall(
            r'<iframe[^>]+(?:src|data-src)=["\']([^"\']+)["\']', html, re.I):
        if iframe_src.startswith("http"):
            sub_html = _get_html(iframe_src)
            if sub_html:
                result = _extract_hls(sub_html)
                if result:
                    return result
    return None


def _extract_plot(html):
    # entry-content div paragraphs
    m = re.search(
        r'<div[^>]+class=["\'][^"\']*(?:entry-content|post-content)[^"\']*["\'][^>]*>'
        r'(.*?)</div>',
        html, re.S | re.I)
    if m:
        paras = re.findall(r'<p[^>]*>(.*?)</p>', m.group(1), re.S | re.I)
        if paras:
            return _html_text(" ".join(paras[:3]))[:600]
    # meta description fallback
    m2 = re.search(r'<meta[^>]+(?:name=["\']description["\']|property=["\']og:description["\'])'
                   r'[^>]+content=["\']([^"\']*)["\']', html, re.I)
    return m2.group(1)[:600] if m2 else ""


def _extract_poster(html):
    m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', html, re.I)
    if m:
        return m.group(1)
    m2 = re.search(r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\']', html, re.I)
    if m2:
        return m2.group(1)
    # First img src
    m3 = re.search(r'<img[^>]+(?:data-src|src)=["\']([^"\']+)["\']', html, re.I)
    return m3.group(1) if m3 else ""
