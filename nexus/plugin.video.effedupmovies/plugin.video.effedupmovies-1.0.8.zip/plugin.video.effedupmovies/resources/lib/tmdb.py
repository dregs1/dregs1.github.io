"""TMDB metadata — urllib only, no external dependencies."""

import json
import ssl
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import urlencode

try:
    _SSL_CTX = ssl.create_default_context()
    _SSL_CTX.check_hostname = False
    _SSL_CTX.verify_mode = ssl.CERT_NONE
except Exception:
    _SSL_CTX = None

TMDB_BASE  = "https://api.themoviedb.org/3"
TMDB_IMG   = "https://image.tmdb.org/t/p/w500"
TMDB_ORIG  = "https://image.tmdb.org/t/p/original"
UA = "EUM-Kodi-Addon/1.0"


def _get(url, params):
    full = url + "?" + urlencode(params)
    xbmc.log("[EUM-TMDB] GET " + full, xbmc.LOGDEBUG)
    req = Request(full, headers={"User-Agent": UA, "Accept": "application/json"})
    try:
        kwargs = {"timeout": 10}
        if _SSL_CTX:
            kwargs["context"] = _SSL_CTX
        resp = urlopen(req, **kwargs)
        return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception as e:
        xbmc.log("[EUM-TMDB] error: " + str(e), xbmc.LOGWARNING)
        return None


def get_movie_info(api_key, title, year=None, fallback_poster=None):
    empty = {
        "title": title, "year": year or "",
        "plot": "", "rating": "",
        "poster": fallback_poster or "", "fanart": fallback_poster or "",
        "tmdb_id": None,
    }
    if not api_key or not title:
        return empty

    params = {"api_key": api_key, "query": title, "language": "en-US", "include_adult": "true"}
    if year:
        params["year"] = year

    data = _get(TMDB_BASE + "/search/movie", params)
    results = (data or {}).get("results", [])

    # Retry without year if no hits
    if not results and year:
        p2 = dict(params)
        del p2["year"]
        data2 = _get(TMDB_BASE + "/search/movie", p2)
        results = (data2 or {}).get("results", [])

    if not results:
        return empty

    r = results[0]
    poster_path   = r.get("poster_path")
    backdrop_path = r.get("backdrop_path")
    poster  = (TMDB_IMG  + poster_path)  if poster_path   else (fallback_poster or "")
    fanart  = (TMDB_ORIG + backdrop_path) if backdrop_path else poster
    release = r.get("release_date", "") or ""
    yr      = release[:4] if release else (year or "")
    rating  = r.get("vote_average", 0)

    return {
        "title":    r.get("title") or title,
        "year":     yr,
        "plot":     r.get("overview", "") or "",
        "rating":   str(round(float(rating), 1)) if rating else "",
        "poster":   poster,
        "fanart":   fanart,
        "tmdb_id":  r.get("id"),
    }
