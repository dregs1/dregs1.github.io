KODI PLAYER HELPER 4.0
======================

Esta versão faz as alterações diretamente dentro do Kodi, sem abrir definições
externas, sem editar advancedsettings.xml e sem exigir reinício.

Como usar:
1. Instalar o ZIP em Kodi > Definições > Add-ons > Instalar a partir de ficheiro ZIP.
2. Abrir Add-ons > Add-ons de Programas > Kodi Player Helper.
3. Escolher "OTIMIZAR TUDO AGORA".

O addon tenta aplicar em tempo real:
- videoplayer.adjustrefreshrate = false
- videoplayer.synctype = 0

A disponibilidade depende da versão/build do Kodi. O addon verifica cada opção
antes de tentar alterá-la, guarda os valores anteriores e apresenta o resultado.
Inclui reposição.

Limitações:
- Não existe um conjunto universal de opções que impeça o PVR de perder um canal.
- Esta versão não altera cache de streaming, porque o Kodi não disponibiliza
  uma alteração universal e segura dessa cache em tempo real via JSON-RPC.
- Se o PVR regressa à lista, a origem pode ser o portal/servidor, autenticação,
  limite de sessões, rede ou URL expirada. O addon não consegue corrigir isso.


NOVO NA VERSÃO 1.0.5
--------------------
- Serviço em segundo plano que observa automaticamente o início e o fim da reprodução.
- Regista interrupções e erros comunicados pelo Kodi em player_helper.log, na pasta
  de dados do addon.
- Nova opção "Ver diagnóstico automático" no menu do addon.
- Não reinicia canais automaticamente: uma paragem pode ser manual, e tentar
  reabrir continuamente um stream pode criar ciclos ou interferir com o utilizador.
- O registo remove credenciais e parâmetros de consulta das origens de rede.

CORREÇÃO NA VERSÃO 1.0.6
------------------------
- Corrigido o erro de compatibilidade: xbmcgui.Dialog não tem o método text()
  em algumas versões do Kodi. O diagnóstico usa agora Dialog.ok().
- O estado booleano da taxa de atualização é apresentado como Ativado/Desativado.
- A opção de sincronização A/V continua a indicar quando a definição não existe
  ou não está acessível na versão do Kodi; não é forçada.
