import six
import requests
from bs4 import BeautifulSoup
import re
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import random
import time

class SC:
    def __init__(self):
        self.sitehentai = 'https://hentailegendado.com/'       
        self.IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
        self.FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
        self.OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36 OPR/67.0.3575.97'
        self.IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
        self.IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
        self.ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36'
        self.EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363'
        self.CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'        
        self.SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
        self._USER_AGENTS = [self.FF_USER_AGENT, self.OPERA_USER_AGENT, self.EDGE_USER_AGENT, self.CHROME_USER_AGENT, self.SAFARI_USER_AGENT]        
        self.headers = {'User-Agent': self.CHROME_USER_AGENT,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,es;q=0.6',
                    'sec-ch-ua': '"Chromium";v="115", "Not A(Brand";v="99", "Google Chrome";v="115"',
                    'sec-ch-ua-mobile': '?1',
                    'sec-ch-ua-platform': '"Android"',
                    'Sec-Fetch-Dest': 'document',
                    'Sec-Fetch-Mode': 'navigate',
                    'Sec-Fetch-Site': 'none',
                    'Sec-Fetch-User': '?1',
                    'Upgrade-Insecure-Requests': '1'   
                        }
        self.itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
    '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
    '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
    '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
    '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
    '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
    '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
    '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
    '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
    '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}
        
    def pick_source(self, sources):
        return sources[0][1]

    def __key(self, item):
        try:
            return int(re.search(r'(\d+)', item[0]).group(1))
        except:
            return 0 

    _url_matches = ['redirector.', 'googleusercontent', '.bp.blogspot.com']

    def _parse_redirect(self, url):
        """Follow a single redirect and return the final Location URL.
        Uses allow_redirects=False so we grab exactly the first hop."""
        try:
            r = requests.get(url, headers=self.headers, allow_redirects=False)
            if r.cookies:
                cookies_str = '; '.join(['%s=%s' % (k, v) for k, v in r.cookies.items()])
                self.headers['Cookie'] = cookies_str
            if r.status_code in (301, 302, 303, 307, 308):
                location = r.headers.get('Location', '')
                return location
            return url
        except Exception as e:
            return ''

    def _parse_gdocs(self, html):
        urls = []
        if 'error' in html:
            reason = unquote_plus(re.findall('reason=([^&]+)', html)[0])
            raise ValueError(reason)
        value = unquote(re.findall('fmt_stream_map=([^&]+)', html)[0])
        items = value.split(',')
        for item in items:
            _source_itag, source_url = item.split('|')
            if isinstance(source_url, six.text_type) and six.PY2:
                source_url = source_url.decode('unicode_escape').encode('utf-8')
            quality = self.itag_map.get(_source_itag, 'Unknown Quality [%s]' % _source_itag)
            source_url = unquote(source_url)
            urls.append((quality, source_url))
        return urls

    def __parse_gplus(self, html):
        """Parse a Google Plus embedded video page."""
        sources = []
        match = re.search(r'<c-wiz.+?track:impression,click".*?jsdata\s*=\s*".*?(http[^"]+)"', html, re.DOTALL)
        if match:
            source = match.group(1).replace('&amp;', '&').split(';')[0]
            sources.append(('Unknown Quality', source))
        else:
            pass
        return sources

    def __extract_video(self, item):
        """Recursively extract (quality, url) pairs from a nested gget structure."""
        sources = []
        for e in item:
            if isinstance(e, dict):
                for key in e:
                    for item2 in e[key]:
                        if isinstance(item2, list):
                            for item3 in item2:
                                if isinstance(item3, list):
                                    for item4 in item3:
                                        if isinstance(item4, six.text_type) and six.PY2:
                                            item4 = item4.encode('utf-8')
                                        if isinstance(item4, six.string_types):
                                            item4 = unquote(item4)
                                            for match in re.finditer(r'url=(?P<link>[^&]+).*?&itag=(?P<itag>[^&]+)', item4):
                                                link = match.group('link')
                                                itag = match.group('itag')
                                                quality = self.itag_map.get(itag, 'Unknown Quality [%s]' % itag)
                                                sources.append((quality, link))
                                            if sources:
                                                return sources
        return sources

    def __parse_gget(self, vid_id, html):
        """Parse a get.google.com response."""
        sources = []
        match = re.search(r'.+return\s+(\[\[.*?)\s*}}', html, re.DOTALL)
        if match:
            try:
                import json
                js = json.loads(match.group(1))
                for top_item in js:
                    if isinstance(top_item, list):
                        for item in top_item:
                            if isinstance(item, list):
                                for item2 in item:
                                    if isinstance(item2, list):
                                        for item3 in item2:
                                            if vid_id in str(item3):
                                                sources = self.__extract_video(item2)
                                                if sources:
                                                    return sources
            except Exception as e:
                pass
        return sources

    def _parse_google(self, link):
        """Main dispatcher for all Google URL types.
        Returns (cookies, sources) where sources is a list of (quality, url)."""
        sources = []
        cookies = None

        if re.match(r'https?://get\.', link):
            if link.endswith('/'):
                link = link[:-1]
            vid_id = link.split('/')[-1]
            r = requests.get(link, headers=self.headers)
            cookies = r.cookies
            sources = self.__parse_gget(vid_id, r.text)

        elif re.match(r'https?://plus\.', link):
            r = requests.get(link, headers=self.headers)
            cookies = r.cookies
            sources = self.__parse_gplus(r.text)

        elif 'drive.google' in link or 'docs.google' in link:
            doc_id = re.findall(r'/file/.*?/([^/]+)', link)
            if doc_id:
                link = 'https://drive.google.com/get_video_info?docid=' + doc_id[0]
            r = requests.get(link, headers=self.headers)
            cookies = r.cookies
            sources = self._parse_gdocs(r.text)

        elif 'youtube.googleapis.com' in link:
            cid = re.search(r'cid=([\w]+)', link)
            if cid:
                link = 'https://drive.google.com/file/d/%s/edit' % cid.group(1)
                r = requests.get(link, headers=self.headers)
                cookies = r.cookies
                sources = self._parse_gdocs(r.text)
            else:
                pass

        elif 'blogger.com/video.g?token=' in link:
            r = requests.get(link, headers=self.headers)
            cookies = r.cookies
            source = re.search(r'''['"]play_url["']\s*:\s*["']([^"']+)''', r.text)
            if source:
                stream = source.group(1)
                if six.PY2:
                    stream = stream.decode('unicode-escape')
                sources = [('Unknown Quality', stream)]
            else:
                source_list = re.findall(r'play_url.+?"(.+?)","format_id":(.+?)}', r.text)
                if source_list:
                    sources = [(self.itag_map.get(q, 'Unknown Quality [%s]' % q),
                                s.decode('unicode-escape') if six.PY2 else s)
                               for s, q in source_list]

        return cookies, sources

    def select_video(self, sources):
        if sources:
            sources.sort(key=self.__key, reverse=True)
            video = self.pick_source(sources)
        else:
            video = ''
        return video

    def _resolve_burstcloud(self, link):
        """burstcloud.co — a URL do embed já é o .mp4 direto, só precisa de headers."""
        referer = 'https://www.burstcloud.co/'
        hdrs = ('User-Agent=' + quote(self.CHROME_USER_AGENT)
                + '&Referer=' + quote(referer))
        video = link + '|' + hdrs
        return video

    def _resolve_sendvid(self, link):
        """sendvid.com — busca a página e extrai <source src="...">."""
        page_url = link.replace('/embed/', '/')
        headers = dict(self.headers)
        headers['Referer'] = 'https://sendvid.com/'
        try:
            r = requests.get(page_url, headers=headers)
            match = re.search(r'source\s+src=["\']([^"\']+\.mp4[^"\']*)["\']', r.text)
            if not match:
                match = re.search(r'["\']([^"\']+\.mp4[^"\']*)["\']', r.text)
            if match:
                video_url = match.group(1)
                hdrs = ('User-Agent=' + quote(self.CHROME_USER_AGENT)
                        + '&Referer=' + quote(page_url))
                return video_url + '|' + hdrs
        except Exception as e:
            pass
        return ''

    def _resolve_voe(self, link):
        """voe.sx — extrai o HLS ou MP4 do JS da página."""
        headers = dict(self.headers)
        headers['Referer'] = 'https://voe.sx/'
        try:
            r = requests.get(link, headers=headers)
            html = r.text
            match = re.search(r"'hls'\s*:\s*'([^']+)'", html)
            if not match:
                match = re.search(r'"hls"\s*:\s*"([^"]+)"', html)
            if match:
                video_url = match.group(1)
                hdrs = ('User-Agent=' + quote(self.CHROME_USER_AGENT)
                        + '&Referer=' + quote(link))
                return video_url + '|' + hdrs
            match = re.search(r"'mp4'\s*:\s*'([^']+)'", html)
            if not match:
                match = re.search(r'"mp4"\s*:\s*"([^"]+)"', html)
            if match:
                video_url = match.group(1)
                hdrs = ('User-Agent=' + quote(self.CHROME_USER_AGENT)
                        + '&Referer=' + quote(link))
                return video_url + '|' + hdrs
        except Exception as e:
            pass
        return ''

    def find_video(self, link):
        """Roteia o link para o resolver correto pelo domínio."""
        video = ''
        try:
            if 'burstcloud.co' in link:
                return self._resolve_burstcloud(link)

            if 'sendvid.com' in link:
                return self._resolve_sendvid(link)

            if 'voe.sx' in link:
                return self._resolve_voe(link)

            cookies, sources = self._parse_google(link)

            if sources:
                video = self.select_video(sources)
            else:
                if any(m in link for m in self._url_matches):
                    video = self._parse_redirect(link)
                elif 'googlevideo.' in link:
                    video = link

            if video and any(m in video for m in self._url_matches):
                video = self._parse_redirect(video)

            if video:
                hdrs = 'User-Agent=' + quote(self.CHROME_USER_AGENT)
                if cookies:
                    cookies_str = '; '.join(['%s=%s' % (k, v) for k, v in cookies.items()])
                    hdrs += '&Cookie=' + quote(cookies_str)
                elif 'Cookie' in self.headers:
                    hdrs += '&Cookie=' + quote(self.headers['Cookie'])
                video = video + '|' + hdrs
            else:
                pass

        except Exception as e:
            video = ''

        return video

    def _get_player_name(self, embed_url, index):
        """Gera nome de exibição para um player baseado no domínio da URL."""
        try:
            domain = urlparse(embed_url).netloc.replace('www.', '')
        except Exception:
            domain = 'Player'
        return 'Player %d (%s)' % (index + 1, domain)

    def get_movie_players(self, url):
        """Retorna lista de (name, embed_url) dos players de um filme, sem resolver."""
        players = []
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        try:
            r = requests.get(url, headers=headers)
            soup = self.soup(r.text)
            button = soup.find('div', {'class': 'su-button-center'}).find('a').get('href', '')
            headers.update({'Referer': url})
            r2 = requests.get(button, headers=headers)
            soup2 = self.soup(r2.text)
            options = self._get_player_options(soup2)
            embed_urls = self._fetch_embed_urls(options, headers)
            for i, (nume, embed_url) in enumerate(embed_urls):
                name = self._get_player_name(embed_url, i)
                players.append((name, embed_url))
        except Exception as e:
            pass
        return players

    def get_tvshow_players(self, url):
        """Retorna lista de (name, embed_url) dos players de um episódio, sem resolver."""
        players = []
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        try:
            r = requests.get(url, headers=headers)
            if r.status_code == 200:
                soup = self.soup(r.text)
                options = self._get_player_options(soup)
                embed_urls = self._fetch_embed_urls(options, headers)
                for i, (nume, embed_url) in enumerate(embed_urls):
                    name = self._get_player_name(embed_url, i)
                    players.append((name, embed_url))
        except Exception as e:
            pass
        return players

    def resolve_player(self, embed_url):
        """Resolve um único embed_url para stream verificado.
        Retorna (stream, None) em caso de sucesso, (None, None) se falhar —
        mesmo formato de sources.resolve_tvshows / sources.resolve_movies."""
        stream = self.find_video(embed_url)
        if stream and self._verify_stream(stream):
            return stream, None
        return None, None

    def _verify_stream(self, stream, timeout=8):
        """Verifica se o stream resolvido é acessível.
        O stream pode ter o formato 'url|User-Agent=...&Referer=...'
        Retorna True se o servidor responder 200/206, False caso contrário."""
        if not stream:
            return False
        try:
            url = stream.split('|')[0].strip()
            hdrs = {}
            if '|' in stream:
                raw = stream.split('|', 1)[1]
                for part in raw.split('&'):
                    if '=' in part:
                        key, val = part.split('=', 1)
                        hdrs[unquote(key)] = unquote(val)
            r = requests.head(url, headers=hdrs, timeout=timeout, allow_redirects=True)
            if r.status_code in (200, 206):
                return True
            hdrs['Range'] = 'bytes=0-1023'
            r2 = requests.get(url, headers=hdrs, timeout=timeout, stream=True)
            r2.close()
            return r2.status_code in (200, 206)
        except Exception as e:
            return False

    def soup(self, html):
        soup = BeautifulSoup(html, 'html.parser')
        return soup                                     
    
    def rand_ua(self):
        RAND_UA = random.choice(self._USER_AGENTS)
        return RAND_UA
    
    def hentai_sem_censura(self, url=False):
        if not url:
            url = self.sitehentai + 'genero/hentai-sem-censura/' 
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            articles = soup.find('div', {'class': 'items full'}).find_all('article')
            for article in articles:
                tipo = article.get('class', '')[-1] # movies ou tvshows
                img = article.find('img').get('data-lazy-src', '')
                nome = article.find('div', {'class': 'data'}).find('h3').text
                href = article.find('div', {'class': 'data'}).find('h3').find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens.append((tipo, nome, img, href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except Exception as e:
            pass
        return itens, next, page

    def hentai_com_censura(self, url=False):
        if not url:
            url = self.sitehentai + 'genero/com-censura/' 
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        itens = []
        next = False
        page = ''
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            articles = soup.find('div', {'class': 'items full'}).find_all('article')
            for article in articles:
                tipo = article.get('class', '')[-1] # movies ou tvshows
                img = article.find('img').get('data-lazy-src', '')
                nome = article.find('div', {'class': 'data'}).find('h3').text
                href = article.find('div', {'class': 'data'}).find('h3').find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens.append((tipo, nome, img, href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except Exception as e:
            pass
        return itens, next, page        

    def temporadas(self, url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        list_seasons = []
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                name = '[B]TEMPORADA %s[/B]' % str(n)
                season = str(n)
                list_seasons.append((name, season, url))               
        except Exception as e:
            pass
        return list_seasons

    def episodios(self, url, season):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        list_episodes = []
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            s = soup.find('div', {'id': 'serie_contenido'}).find('div', {'id': 'seasons'}).find_all('div', {'class': 'se-c'})
            for n, i in enumerate(s):
                n += 1
                if n == int(season):
                    episodes = i.find('div', {'class': 'se-a'}).find('ul', {'class': 'episodios'}).find_all('li', class_=re.compile(r'^mark'))
                    for n2, i2 in enumerate(episodes):
                        n2 += 1
                        name = str(n2)
                        img = i2.find('div', {'class': 'imagen'}).find('img').get('data-lazy-src', '')
                        href = i2.find('div', {'class': 'episodiotitle'}).find('a').get('href', '')
                        list_episodes.append((name, img, href))
                    break
        except Exception as e:
            pass
        return list_episodes        

    def _get_player_options(self, soup):
        """Extrai todos os li.dooplay_player_option da página e retorna lista de dicts."""
        options = []
        items = soup.find_all('li', {'class': 'dooplay_player_option'})
        for li in items:
            post = li.get('data-post', '')
            tipo = li.get('data-type', 'tv')
            nume = li.get('data-nume', '1')
            if post:
                options.append({'post': post, 'type': tipo, 'nume': nume})
        return options

    def _fetch_embed_urls(self, options, headers):
        """Para cada opção de player, chama a API e coleta os embed_url."""
        embed_urls = []
        api_base = 'https://hentailegendado.com/wp-json/dooplayer/v2/'
        for opt in options:
            api_url = '%s%s/%s/%s' % (api_base, opt['post'], opt['type'], opt['nume'])
            try:
                r = requests.get(api_url, headers=headers)
                if r.status_code == 200:
                    data = r.json()
                    iframe = data.get('embed_url', '')
                    if iframe:
                        embed_urls.append((opt['nume'], iframe))
            except Exception as e:
                pass
        return embed_urls

    def resolver_movies(self, url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        stream = ''
        try:
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            button = soup.find('div', {'class': 'su-button-center'}).find('a').get('href', '')
            headers.update({'Referer': url})
            r2 = requests.get(button, headers=headers)
            soup2 = self.soup(r2.text)
            options = self._get_player_options(soup2)
            embed_urls = self._fetch_embed_urls(options, headers)
            for nume, iframe in embed_urls:
                stream = self.find_video(iframe)
                if stream:
                    if self._verify_stream(stream):
                        break
                    else:
                        stream = ''
        except Exception as e:
            pass
        return stream

    def pesquisa_hentai(self, url, pesquisa):
        itens_pesquisa = []
        next = False
        page = ''
        if pesquisa:
            url = '%s?s=%s' % (self.sitehentai, quote_plus(pesquisa))
        try:
            headers = self.headers
            headers.update({'Referer': self.sitehentai})
            r = requests.get(url, headers=headers)
            src = r.text
            soup = self.soup(src)
            itens = soup.find('div', {'class': 'search-page'}).find_all('div', {'class': 'result-item'})
            for i in itens:
                thumb = i.find('article').find('div', {"class": 'image'}).find("div", class_=re.compile(r'^thumbnail'))
                img = thumb.find('a').find('img').get('src', '')
                try:
                    tipo = thumb.find('a').find('span').get('class', '')[-1]
                except:
                    tipo = thumb.find('a').find('span').get('class', '')
                nome = i.find('article').find('div', {"class": 'details'}).find('div', {'class': 'title'}).find('a').text
                href = i.find('article').find('div', {"class": 'details'}).find('div', {'class': 'title'}).find('a').get('href', '')
                try:
                    nome = nome.decode('utf-8')
                except:
                    pass
                nome = '[B]' + nome + '[/B]'
                itens_pesquisa.append((tipo, nome, img, href))
            try:
                p = soup.find('div', {'class': 'pagination'})
                current = int(p.find('span', {'class': 'current'}).text.strip())
                try:
                    a = p.find_all('a', {'class': 'arrow_pag'})[-1].get('href', '')
                    try:
                        page = int(a.split('/page/')[1].split('/')[0])
                        if page > current:
                            page = str(page)
                            next = a
                    except:
                        pass
                except:
                    try:
                        a = p.find_all('a')[-1].get('href', '')
                        try:
                            page = int(a.split('/page/')[1].split('/')[0])
                            if page > current:
                                page = str(page)
                                next = a
                        except:
                            pass
                    except:
                        pass
            except:
                pass
        except Exception as e:
            pass
        return itens_pesquisa, next, page 

    def resolver_tvshows(self, url):
        headers = self.headers
        headers.update({'Referer': self.sitehentai})
        stream = ''
        try:
            r = requests.get(url, headers=headers)
            if r.status_code == 200:
                soup = self.soup(r.text)
                options = self._get_player_options(soup)
                embed_urls = self._fetch_embed_urls(options, headers)
                for nume, iframe in embed_urls:
                    stream = self.find_video(iframe)
                    if stream:
                        if self._verify_stream(stream):
                            break
                        else:
                            stream = ''
        except Exception as e:
            pass
        return stream