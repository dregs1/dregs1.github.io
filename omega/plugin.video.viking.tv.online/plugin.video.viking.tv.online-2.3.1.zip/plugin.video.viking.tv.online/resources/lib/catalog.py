# -*- coding: utf-8 -*-
"""Consultas ao catálogo local (SQLite): categorias, itens paginados, busca."""
import json
import re

from .common import SB, SI, norm_text
from .db import db

ADULT_RE = re.compile(r'(?i)(\bxxx\b|adult|\+\s?18|18\s?\+|porn|hentai|er[o\u00f3]tic|sexo|\bsex\b)')

SORTS = {
    'provider': 'i.num ASC, i.norm ASC',
    'az': 'i.norm ASC',
    'recent': 'i.added DESC, i.num ASC',
}


def sort_for(kind):
    if kind == 'live':
        return 'provider'
    return {0: 'provider', 1: 'az', 2: 'recent'}.get(SI('sort_vod', 2), 'recent')


def _adult_cats(kind):
    if not SB('hide_adult', False):
        return []
    return [r['id'] for r in db().q('SELECT id, name FROM cat WHERE kind=?', (kind,))
            if ADULT_RE.search(r['name'] or '')]


def categories(kind):
    counts = {r['cat']: r['n'] for r in
              db().q('SELECT cat, COUNT(*) AS n FROM item WHERE kind=? GROUP BY cat', (kind,))}
    hide = SB('hide_adult', False)
    out = []
    for r in db().q('SELECT id, name FROM cat WHERE kind=? ORDER BY ord', (kind,)):
        name = r['name'] or ''
        if hide and ADULT_RE.search(name):
            continue
        n = counts.get(r['id'], 0)
        if n:
            out.append({'id': r['id'], 'name': name, 'count': n})
    return out


def count(kind):
    r = db().q1('SELECT COUNT(*) AS n FROM item WHERE kind=?', (kind,))
    return r['n'] if r else 0


_SELECT = ('SELECT i.*, c.name AS cat_name FROM item i '
           'LEFT JOIN cat c ON c.kind=i.kind AND c.id=i.cat ')


def items(kind, cat=None, sort='provider', limit=None, offset=0, search=None):
    where, args = ['i.kind=?'], [kind]
    if cat not in (None, ''):
        where.append('i.cat=?')
        args.append(str(cat))
    else:
        adult = _adult_cats(kind)
        if adult:
            where.append('i.cat NOT IN (%s)' % ','.join('?' * len(adult)))
            args += adult
    if search:
        for tok in norm_text(search).split():
            where.append('i.norm LIKE ?')
            args.append('%' + tok + '%')
    sql = _SELECT + 'WHERE ' + ' AND '.join(where) + ' ORDER BY ' + SORTS.get(sort, SORTS['provider'])
    if limit:
        sql += ' LIMIT %d OFFSET %d' % (int(limit), int(offset))
    return [dict(r) for r in db().q(sql, args)]


def total(kind, cat=None):
    where, args = ['kind=?'], [kind]
    if cat not in (None, ''):
        where.append('cat=?')
        args.append(str(cat))
    r = db().q1('SELECT COUNT(*) AS n FROM item WHERE ' + ' AND '.join(where), args)
    return r['n'] if r else 0


def get(kind, rid):
    r = db().q1(_SELECT + 'WHERE i.kind=? AND i.id=?', (kind, str(rid)))
    return dict(r) if r else None


def by_ids(kind, ids):
    """Itens na ordem dos ids informados (favoritos)."""
    out = {}
    ids = [str(i) for i in ids]
    for i in range(0, len(ids), 400):
        chunk = ids[i:i + 400]
        rows = db().q(_SELECT + 'WHERE i.kind=? AND i.id IN (%s)' % ','.join('?' * len(chunk)),
                      [kind] + chunk)
        for r in rows:
            out[r['id']] = dict(r)
    return [out[i] for i in ids if i in out]


def extra(row):
    try:
        return json.loads(row.get('extra') or '{}')
    except ValueError:
        return {}
