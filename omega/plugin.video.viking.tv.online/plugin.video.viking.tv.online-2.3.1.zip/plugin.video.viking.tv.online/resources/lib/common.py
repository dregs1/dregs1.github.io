# -*- coding: utf-8 -*-
"""Constantes, settings (com cache), log e helpers de texto/tempo.

Somente API Python 3 do Kodi (19+). Nenhuma chamada deprecated:
xbmcvfs.translatePath, xbmc.LOGINFO, InfoTagVideo (com fallback p/ setInfo).
"""
import base64
import os
import re
import time
import traceback
import unicodedata

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = 'plugin.video.viking.tv.online'  # se renomear: altere aqui, no addon.xml e no settings.xml
_ADDON = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = _ADDON.getAddonInfo('name')
ADDON_VERSION = _ADDON.getAddonInfo('version')
ADDON_PATH = xbmcvfs.translatePath(_ADDON.getAddonInfo('path'))
PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
MEDIA = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media')
ICON = os.path.join(ADDON_PATH, 'icon.png')
FANART = os.path.join(ADDON_PATH, 'fanart.jpg')

try:
    os.makedirs(PROFILE, exist_ok=True)
except OSError:
    pass


class Cancelled(Exception):
    """Operação cancelada pelo usuário."""


# ------------------------------------------------------------------ settings
_CFG = {}


def cfg_reload():
    """Descarta o cache; a próxima leitura busca o valor atual."""
    _CFG.clear()


def _raw(key):
    if key not in _CFG:
        try:
            _CFG[key] = xbmcaddon.Addon(ADDON_ID).getSetting(key)
        except Exception:
            _CFG[key] = ''
    return _CFG[key]


def S(key, default=''):
    v = _raw(key)
    return v if v not in (None, '') else default


def SB(key, default=False):
    v = _raw(key)
    if v in (None, ''):
        return default
    return str(v).lower() == 'true'


def SI(key, default=0):
    try:
        return int(float(_raw(key)))
    except (TypeError, ValueError):
        return default


def set_setting(key, value):
    if isinstance(value, bool):
        value = 'true' if value else 'false'
    xbmcaddon.Addon(ADDON_ID).setSetting(key, str(value))
    _CFG.pop(key, None)


# ----------------------------------------------------------------------- log
# LOG TOTALMENTE DESATIVADO — blindagem anti-vazamento de credenciais.
# As funções abaixo são NO-OP: nenhuma mensagem, URL, usuário ou senha deste
# addon chega ao kodi.log. Rede de segurança adicional em resources/lib/logshield.py
# (xbmc.log é substituído por função muda em todo o processo do addon).
def log(msg, level=xbmc.LOGINFO):
    """No-op: log desativado (proteção de credenciais/links)."""
    return None


def log_exc(where=''):
    """No-op: tracebacks podem conter URLs e credenciais — nunca são logados."""
    return None


def dbg(msg):
    """No-op: log de debug desativado (proteção de credenciais/links)."""
    return None


def kodi_major():
    try:
        m = re.match(r'\s*(\d+)', xbmc.getInfoLabel('System.BuildVersion'))
        return int(m.group(1)) if m else 19
    except Exception:
        return 19


# ------------------------------------------------------------------- dialogs
def notify(msg, heading=None, ms=4000):
    try:
        xbmcgui.Dialog().notification(heading or ADDON_NAME, msg, ICON, ms, False)
    except Exception:
        pass


def busy(on=True):
    try:
        xbmc.executebuiltin('ActivateWindow(busydialognocancel)' if on
                            else 'Dialog.Close(busydialognocancel)')
    except Exception:
        pass


# ------------------------------------------------------------ texto / números
def to_int(v, default=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


def to_float(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def norm_text(s):
    """minúsculo, sem acentos, só letras/números separados por espaço."""
    s = unicodedata.normalize('NFKD', s or '')
    s = ''.join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r'[\W_]+', ' ', s).strip()


def b64dec(s):
    """EPG do Xtream vem em base64; alguns painéis mandam texto puro."""
    if not s:
        return ''
    try:
        t = str(s).strip()
        raw = base64.b64decode(t + '=' * (-len(t) % 4), validate=True)
        txt = raw.decode('utf-8')
        if txt and all(ch.isprintable() or ch in '\n\r\t' for ch in txt):
            return txt
    except Exception:
        pass
    return str(s)


_LANG_PREFIX = re.compile(
    r'^\s*(?:[\[\(\{]\s*|\|\s*)?(?:BR|BRA|PT|PTBR|PT-BR|POR|PRT|ES|EN|US|UK|FR|IT|DE|LAT|LATAM|MX|AR)'
    r'\s*(?:[\]\)\}]|\|)\s*', re.I)


def clean_title(name):
    """Remove prefixos de idioma/país: '[BR] X', 'BR| X', '|PT-BR| X'."""
    s = name or ''
    for _i in range(2):
        s2 = _LANG_PREFIX.sub('', s, count=1)
        if s2 == s:
            break
        s = s2
    return s.strip() or (name or '').strip()


_YEAR_RE = re.compile(r'(?:[\(\[\{]\s*((?:19|20)\d{2})\s*[\)\]\}]|[\s\-\u2013\u2014]((?:19|20)\d{2}))\s*$')


def split_year(name):
    """'Filme (2019)' -> ('Filme', 2019). Ignora números que não são ano plausível."""
    name = name or ''
    m = _YEAR_RE.search(name)
    if not m:
        return name.strip(), 0
    y = int(m.group(1) or m.group(2))
    if not (1900 <= y <= time.localtime().tm_year + 1):
        return name.strip(), 0
    return name[:m.start()].strip(' -\u2013\u2014|'), y


def fmt_hm(ts):
    return time.strftime('%H:%M', time.localtime(ts)) if ts else ''


def fmt_date(ts):
    return time.strftime('%d/%m/%Y', time.localtime(ts)) if ts else ''


def fmt_dur(sec):
    sec = to_int(sec)
    if sec <= 0:
        return ''
    h, r = divmod(sec, 3600)
    m = r // 60
    return '%dh%02d' % (h, m) if h else '%d min' % m


# ------------------------------------------------------------------ DoH
# Resolvedor central DoH (Cloudflare) do addon: TODAS as consultas DNS do
# processo — API Xtream, EPG, TMDB/TVmaze e os proxies locais (hlsproxy,
# tsproxy e vodproxy em resources/lib) — passam por ele enquanto a opção
# "Resolver DNS pela Cloudflare (DoH)" estiver ativa nas configurações
# (padrão: ATIVA). Desativar a opção devolve as consultas ao DNS do
# sistema em tempo quase real (sem reiniciar o Kodi).
from . import dohresolver

dohresolver.install()
