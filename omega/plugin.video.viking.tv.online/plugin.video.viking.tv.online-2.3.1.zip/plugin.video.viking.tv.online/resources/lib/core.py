# -*- coding: utf-8 -*-
"""Contexto compartilhado (Xtream + EPG + Meta) e ações com diálogos usadas pelo plugin e pela UI."""
import threading
import time

import xbmcgui

from .common import ADDON_NAME, Cancelled, fmt_date, log, log_exc, notify
from .epg import Epg
from .i18n import _
from .meta import Meta
from .xtream import Xtream, XtreamError, fetch_credentials, test_server


class Core(object):
    def __init__(self):
        self.xt = Xtream()
        self.epg = Epg(self.xt)
        self.meta = Meta(self.xt)


def kind_label(kind):
    return {'live': _('Canais'), 'movie': _('Filmes'), 'series': _('Séries')}.get(kind, kind)


def ensure_catalog(core, kinds, force=False):
    """Sincroniza os catálogos que faltam/estão vencidos (ou todos, com force), com barra
    de progresso. True se tudo pronto; False se cancelado ou com erro (já mostra o motivo)."""
    todo = [k for k in kinds if force or core.xt.needs_sync(k)]
    if not todo:
        return True
    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, _('Carregando catálogo…'))
    error = None
    try:
        for i, k in enumerate(todo):
            def cb(p, m, i=i, k=k):
                if dp.iscanceled():
                    raise Cancelled()
                dp.update(int((i * 100 + p) / len(todo)), '%s\n%s' % (kind_label(k), m))
            core.xt.sync(k, force=True, progress=cb)
    except Cancelled:
        dp.close()
        return False
    except XtreamError as e:
        error = str(e)
    dp.close()
    if error:
        xbmcgui.Dialog().ok(ADDON_NAME, error)
        return False
    return True


def refresh_epg(core, force=True):
    """Atualiza o EPG com barra de progresso (ação manual)."""
    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, _('Atualizando EPG…'))
    total, error = 0, None
    try:
        if core.xt.needs_sync('live'):
            core.xt.sync('live', force=True)

        def cb(p, m):
            if dp.iscanceled():
                raise Cancelled()
            dp.update(max(0, min(100, int(p))), m)
        total = core.epg.refresh(progress=cb, force=force, abort=dp.iscanceled)
    except Cancelled:
        dp.close()
        return 0
    except XtreamError as e:
        error = str(e)
    dp.close()
    if error:
        xbmcgui.Dialog().ok(ADDON_NAME, error)
    else:
        notify(_('EPG atualizado: %d programas') % total)
    return total


def account_summary(info):
    """Texto curto: 'Ativo • Expira 14/03/2027 • Conexões 0/2'."""
    status = (info.get('status') or '').strip()
    known = {'active': _('Ativo'), 'expired': _('Expirado'), 'banned': _('Banido'), 'disabled': _('Desativado')}
    parts = [known.get(status.lower(), status) or _('Ativo')]
    if info.get('exp'):
        parts.append(_('Expira %s') % fmt_date(info['exp']))
    if info.get('max'):
        parts.append(_('Conexões %d/%d') % (info.get('cons', 0), info['max']))
    if info.get('trial'):
        parts.append(_('Teste'))
    return '  \u2022  '.join(parts)


def test_connection(core):
    try:
        info = core.xt.user_info(force=True)
    except XtreamError as e:
        xbmcgui.Dialog().ok(ADDON_NAME, str(e))
        return False
    lines = [account_summary(info)]
    if info.get('formats'):
        lines.append(_('Formatos: %s') % ', '.join(str(f) for f in info['formats']))
    if info.get('message'):
        lines.append(info['message'])
    exp = info.get('exp')
    if exp and exp < time.time():
        lines.append(_('Atenção: a assinatura parece vencida.'))
    xbmcgui.Dialog().ok(ADDON_NAME, '\n'.join(lines))
    return True


def test_all_servers(core, timeout=12):
    """Testa todos os servidores do link de credenciais em paralelo.

    Devolve uma lista de (srv_dict, ok, expired, label), na mesma ordem do
    JSON remoto. Cada servidor recebe uma chamada player_api.php curta
    (retries=0) para determinar se está ativo, expirado/sem conexão.
    """
    try:
        servers = fetch_credentials(core.xt.cred_url, force=False)
    except Exception:
        log_exc('test_all_servers fetch')
        servers = []
    if not servers:
        return []
    ua = core.xt.ua
    verify = core.xt.verify
    results = [None] * len(servers)

    def _worker(i, s):
        try:
            ok, exp, label = test_server(s, ua=ua, verify=verify, timeout=timeout)
        except Exception:
            ok, exp, label = False, False, _('erro')
        results[i] = (s, ok, exp, label)

    threads = []
    for i, s in enumerate(servers):
        t = threading.Thread(target=_worker, args=(i, s))
        t.daemon = True
        t.start()
        threads.append(t)
    deadline = time.time() + timeout + 4
    for t in threads:
        remaining = max(0.1, deadline - time.time())
        t.join(remaining)
    for i, r in enumerate(results):
        if r is None:
            results[i] = (servers[i], False, False, _('sem conexão'))
    return results
