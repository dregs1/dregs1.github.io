# -*- coding: utf-8 -*-
"""Banco SQLite local (catálogo, EPG, favoritos, histórico, cache de metadados).

Uma conexão por thread (UI + workers + service). Sem WAL: o perfil do Kodi em
Android/FUSE nem sempre suporta memória compartilhada; commits curtos bastam.
"""
import os
import sqlite3
import threading

import xbmc

from .common import PROFILE, log

SCHEMA = (
    'CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT)',
    'CREATE TABLE IF NOT EXISTS cat(kind TEXT NOT NULL, id TEXT NOT NULL, name TEXT, '
    'ord INTEGER DEFAULT 0, PRIMARY KEY(kind, id))',
    'CREATE TABLE IF NOT EXISTS item(kind TEXT NOT NULL, id TEXT NOT NULL, name TEXT, norm TEXT, '
    'cat TEXT, icon TEXT, rating REAL DEFAULT 0, added INTEGER DEFAULT 0, ext TEXT, epg TEXT, '
    'archive INTEGER DEFAULT 0, num INTEGER DEFAULT 0, extra TEXT, PRIMARY KEY(kind, id))',
    'CREATE INDEX IF NOT EXISTS item_cat ON item(kind, cat, num)',
    'CREATE INDEX IF NOT EXISTS item_norm ON item(kind, norm)',
    'CREATE TABLE IF NOT EXISTS fav(kind TEXT NOT NULL, id TEXT NOT NULL, ts INTEGER, '
    'PRIMARY KEY(kind, id))',
    'CREATE TABLE IF NOT EXISTS hist(kind TEXT NOT NULL, id TEXT NOT NULL, ts INTEGER, pos REAL, '
    'total REAL, done INTEGER DEFAULT 0, info TEXT, PRIMARY KEY(kind, id))',
    'CREATE TABLE IF NOT EXISTS meta(kind TEXT NOT NULL, id TEXT NOT NULL, ts INTEGER, data TEXT, '
    'PRIMARY KEY(kind, id))',
    'CREATE TABLE IF NOT EXISTS epg(ch TEXT NOT NULL, start INTEGER NOT NULL, stop INTEGER NOT NULL, '
    'title TEXT, descr TEXT, PRIMARY KEY(ch, start))',
    'CREATE INDEX IF NOT EXISTS epg_stop ON epg(stop)',
    'CREATE TABLE IF NOT EXISTS epgname(norm TEXT NOT NULL, ch TEXT NOT NULL, PRIMARY KEY(norm, ch))',
)


class _DB(object):
    def __init__(self, path):
        self.path = path
        self._local = threading.local()
        try:
            self._init_schema()
        except sqlite3.DatabaseError:
            log('Banco corrompido; recriando.', xbmc.LOGWARNING)
            self._local = threading.local()
            try:
                os.remove(self.path)
            except OSError:
                pass
            self._init_schema()

    def _connect(self):
        c = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA synchronous=NORMAL')
        c.execute('PRAGMA temp_store=MEMORY')
        return c

    def conn(self):
        c = getattr(self._local, 'c', None)
        if c is None:
            c = self._local.c = self._connect()
        return c

    def _init_schema(self):
        c = self.conn()
        for sql in SCHEMA:
            c.execute(sql)
        c.commit()

    def q(self, sql, args=()):
        return self.conn().execute(sql, args).fetchall()

    def q1(self, sql, args=()):
        return self.conn().execute(sql, args).fetchone()

    def x(self, sql, args=()):
        c = self.conn()
        cur = c.execute(sql, args)
        c.commit()
        return cur

    def many(self, sql, rows):
        c = self.conn()
        c.executemany(sql, rows)
        c.commit()

    def commit(self):
        self.conn().commit()


_DBI = None
_LOCK = threading.Lock()


def db():
    global _DBI
    if _DBI is None:
        with _LOCK:
            if _DBI is None:
                _DBI = _DB(os.path.join(PROFILE, 'xtreamplayer.db'))
    return _DBI


# --------------------------------------------------------------------- kv
def kv_get(key, default=None):
    r = db().q1('SELECT v FROM kv WHERE k=?', (key,))
    return r['v'] if r else default


def kv_set(key, value):
    db().x('INSERT OR REPLACE INTO kv(k, v) VALUES (?, ?)', (key, str(value)))


# ---------------------------------------------------------------- limpeza
def reset_account():
    """Troca de conta: tudo que pertence à conta anterior é descartado."""
    c = db().conn()
    for t in ('cat', 'item', 'fav', 'hist', 'meta', 'epg', 'epgname'):
        c.execute('DELETE FROM %s' % t)
    c.execute("DELETE FROM kv WHERE k LIKE 'sync_%' OR k IN ('uinfo', 'uinfo_ts', 'epg_ts')")
    c.commit()


def clear_cache():
    """Limpa catálogo, EPG e descrições; mantém favoritos e histórico."""
    c = db().conn()
    for t in ('cat', 'item', 'meta', 'epg', 'epgname'):
        c.execute('DELETE FROM %s' % t)
    c.execute("DELETE FROM kv WHERE k LIKE 'sync_%' OR k IN ('uinfo', 'uinfo_ts', 'epg_ts')")
    c.commit()
    try:
        c.execute('VACUUM')
    except sqlite3.Error:
        pass
