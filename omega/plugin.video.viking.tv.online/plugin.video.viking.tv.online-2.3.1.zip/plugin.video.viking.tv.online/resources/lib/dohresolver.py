# -*- coding: utf-8 -*-
"""Resolvedor central DNS-over-HTTPS (DoH) da Cloudflare para o VIKING TV ONLINE.

Todas as consultas DNS do addon — API Xtream Codes, EPG/XMLTV, TMDB,
TVmaze e os proxies locais (hlsproxy.py, tsproxy.py e vodproxy.py em
resources/lib/) — passam por este resolvedor quando a opção
"Resolver DNS pela Cloudflare (DoH)" está ativa nas configurações do
addon (padrão: ATIVA). O DoH embutido que existia em hlsproxy.py e
vodproxy.py foi substituído por este resolvedor único e central.

Como funciona:
  * Consultas A/AAAA via https://cloudflare-dns.com/dns-query (JSON),
    conectando direto nos IPs de bootstrap 1.1.1.1 / 1.0.0.1 (com SNI
    cloudflare-dns.com) — nenhuma consulta DNS prévia é necessária.
  * Cache com TTL (positivo e negativo), deduplicação de consultas
    simultâneas (inflight) e circuit breaker: após falhas seguidas o
    DoH fica suspenso por um tempo e o DNS do sistema é usado; volta
    sozinho depois do cooldown.
  * Fallback transparente: qualquer falha (rede, TLS, timeout) cai no
    DNS do sistema, sem quebrar a navegação/reprodução.
  * install()/uninstall() trocam socket.getaddrinfo e
    socket.gethostbyname do processo — isso cobre urllib (http.py do
    addon), requests e urllib3 (usados pelos proxies).
  * A opção das configurações é verificada em tempo quase real (cache
    de 5s): desativar o DoH devolve todas as consultas ao DNS do
    sistema; ativar volta a usar a Cloudflare, sem reiniciar o Kodi.

Somente stdlib (socket/ssl/json/threading) — não depende de requests
nem de nada que precise de vendor/ no sys.path.
"""

import json
import random
import socket
import ssl
import threading
import time
import urllib.parse

# Importações do Kodi (com fallback para uso standalone / testes).
try:
    import xbmc
except ImportError:  # pragma: no cover — fora do Kodi
    import logging

    class _XbmcStub(object):
        LOGDEBUG = logging.DEBUG
        LOGINFO = logging.INFO
        LOGWARNING = logging.WARNING
        LOGERROR = logging.ERROR

        @staticmethod
        def log(msg, level=logging.INFO):
            logging.getLogger("dohresolver").log(level, msg)

    xbmc = _XbmcStub()

try:
    import xbmcaddon
except ImportError:  # pragma: no cover — fora do Kodi
    xbmcaddon = None

try:
    import xbmcvfs
except ImportError:  # pragma: no cover — fora do Kodi
    xbmcvfs = None

__version__ = "1.0.0"

ADDON_ID = "plugin.video.viking.tv.online"
LOG_PREFIX = "[VIKING TV DoH] "

# ---------------- CONFIGURAÇÃO DOH (Cloudflare) ----------------
DOH_ENDPOINT_HOST = "cloudflare-dns.com"
DOH_BOOTSTRAP_IPS = ("1.1.1.1", "1.0.0.1")
DOH_TIMEOUT = 1.5
DOH_TOTAL_BUDGET = 2.5           # teto para A+AAAA na mesma consulta
DOH_BREAKER_THRESHOLD = 3        # falhas seguidas antes de abrir o breaker
DOH_BREAKER_COOLDOWN = 120.0     # DoH suspenso por N s (usa DNS do sistema)
DOH_TTL_DEFAULT = 300
DOH_TTL_MIN = 30
DOH_TTL_MAX = 3600
DOH_NEGATIVE_TTL = 20
DOH_MAX_ENTRIES = 4096

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 10) "
    "AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
)

# ---------------- OPÇÃO NAS CONFIGURAÇÕES DO ADDON ----------------
# Setting booleano "doh_enabled" (resources/settings.xml), padrão: true.
SETTING_KEY = "doh_enabled"
SETTING_DEFAULT = True
_SETTING_RECHECK = 5.0           # revalida a opção a cada N segundos

# Originais salvos ANTES de qualquer patch — usados como fallback.
_ORIG_GETADDRINFO = socket.getaddrinfo
_ORIG_GETHOSTBYNAME = socket.gethostbyname


# ---------------- LOG ----------------
# LOG DESATIVADO — blindagem anti-vazamento: nenhuma consulta DNS, host,
# IP ou URL reescrita é registrada no kodi.log (os hosts dos servidores
# do addon também são informação sensível).

def _log(level, msg, *args):
    """No-op: log desativado (proteção de credenciais/links)."""
    return None


# ---------------- OPÇÃO (ativar/desativar o DoH) ----------------

_SETTING = {"value": None, "checked": 0.0}
_SETTING_LOCK = threading.Lock()


def is_enabled():
    """Lê a opção 'doh_enabled' do addon (padrão: True) com cache de 5s.

    Fora do Kodi (testes standalone) devolve o padrão True.
    """
    now = time.time()
    with _SETTING_LOCK:
        if _SETTING["value"] is None or (now - _SETTING["checked"]) >= _SETTING_RECHECK:
            value = SETTING_DEFAULT
            if xbmcaddon is not None:
                try:
                    raw = xbmcaddon.Addon(ADDON_ID).getSetting(SETTING_KEY)
                    if raw not in (None, ""):
                        value = str(raw).lower() == "true"
                except Exception:
                    value = SETTING_DEFAULT
            _SETTING["value"] = value
            _SETTING["checked"] = now
        return _SETTING["value"]


def refresh_settings():
    """Descarta o cache da opção: a próxima leitura busca o valor atual."""
    with _SETTING_LOCK:
        _SETTING["value"] = None


# ---------------- HELPERS ----------------

def _is_ip(text):
    if not text:
        return False
    for fam in (socket.AF_INET, socket.AF_INET6):
        try:
            socket.inet_pton(fam, text)
            return True
        except OSError:
            continue
    return False


def _clean_host(hostname):
    if isinstance(hostname, bytes):
        try:
            hostname = hostname.decode("ascii")
        except Exception:
            return None
    if not isinstance(hostname, str):
        return None
    hostname = hostname.strip().lower()
    if hostname.startswith("[") and hostname.endswith("]"):
        hostname = hostname[1:-1]
    return hostname or None


# ---------------- CACHE / BREAKER ----------------

class _Entry(object):
    __slots__ = ("ips4", "ips6", "expire", "stored")

    def __init__(self, ips4, ips6, ttl):
        now = time.time()
        self.ips4 = list(ips4 or ())
        self.ips6 = list(ips6 or ())
        self.expire = now + max(DOH_TTL_MIN, min(ttl, DOH_TTL_MAX))
        self.stored = now


_CACHE = {}
_INFLIGHT = {}
_LOCK = threading.Lock()
_BREAKER = {"fails": 0, "until": 0.0}

_STATS = {"queries": 0, "hits": 0, "misses": 0, "fails": 0, "breaker": 0}
_STATS_LOCK = threading.Lock()


def _bump(name, n=1):
    with _STATS_LOCK:
        _STATS[name] = _STATS.get(name, 0) + n


def _available():
    with _LOCK:
        return time.time() >= _BREAKER["until"]


def _note_success():
    with _LOCK:
        _BREAKER["fails"] = 0


def _note_fail():
    with _LOCK:
        _BREAKER["fails"] += 1
        if _BREAKER["fails"] >= DOH_BREAKER_THRESHOLD:
            _BREAKER["until"] = time.time() + DOH_BREAKER_COOLDOWN
            _BREAKER["fails"] = 0
            _bump("breaker")
            _log(xbmc.LOGWARNING,
                 "DoH suspenso por %ds — usando DNS do sistema",
                 int(DOH_BREAKER_COOLDOWN))


def _cache_get(hostname):
    now = time.time()
    with _LOCK:
        entry = _CACHE.get(hostname)
        if entry is None:
            return None
        if entry.expire < now:
            _CACHE.pop(hostname, None)
            return None
        return entry


def _cache_put(hostname, ips4, ips6, ttl):
    with _LOCK:
        if len(_CACHE) >= DOH_MAX_ENTRIES:
            now = time.time()
            for k in [k for k, v in _CACHE.items() if v.expire < now]:
                _CACHE.pop(k, None)
            while len(_CACHE) >= DOH_MAX_ENTRIES:
                oldest = min(_CACHE.items(), key=lambda kv: kv[1].stored)
                _CACHE.pop(oldest[0], None)
        _CACHE[hostname] = _Entry(ips4, ips6, ttl)


def cache_clear():
    """Limpa o cache de DNS e as consultas em andamento."""
    with _LOCK:
        _CACHE.clear()
        _INFLIGHT.clear()


def cache_stats():
    now = time.time()
    with _LOCK:
        total = len(_CACHE)
        live = sum(1 for v in _CACHE.values() if v.expire >= now)
        breaker_until = _BREAKER["until"]
    with _STATS_LOCK:
        stats = dict(_STATS)
    return {"entries": total, "live": live, "inflight": len(_INFLIGHT),
            "breaker_until": breaker_until, "enabled": is_enabled(),
            "stats": stats}


# ---------------- CONSULTA DOH (Cloudflare) ----------------

_CTX_LOCK = threading.Lock()
_CTX = {"verified": None, "plain": None}


def _ca_files():
    """Candidatos de bundle CA: certifi (vendor/) e o cacert.pem do Kodi."""
    files = []
    try:
        import certifi
        where = certifi.where()
        if where:
            files.append(where)
    except Exception:
        pass
    if xbmcvfs is not None:
        try:
            cafile = xbmcvfs.translatePath("special://xbmc/system/certs/cacert.pem")
            if cafile:
                files.append(cafile)
        except Exception:
            pass
    return files


def _ctx_verified():
    """Contexto TLS com CA explícita — no Kodi/Android o armazenamento
    padrão de certificados costuma estar ausente e o handshake falha."""
    with _CTX_LOCK:
        if _CTX["verified"] is None:
            ctx = None
            for cafile in _ca_files():
                try:
                    if __import__("os").path.exists(cafile):
                        ctx = ssl.create_default_context(cafile=cafile)
                        break
                except Exception:
                    ctx = None
            if ctx is None:
                try:
                    ctx = ssl.create_default_context()
                except Exception:
                    ctx = None
            _CTX["verified"] = ctx if ctx is not None else False
        v = _CTX["verified"]
    return v if v is not False else None


def _ctx_plain():
    with _CTX_LOCK:
        if _CTX["plain"] is None:
            ctx = None
            try:
                ctx = ssl._create_unverified_context()
            except Exception:
                ctx = None
            if ctx is None:
                try:
                    ctx = ssl.create_default_context()
                    ctx.check_hostname = False
                    ctx.verify_mode = ssl.CERT_NONE
                except Exception:
                    ctx = None
            _CTX["plain"] = ctx if ctx is not None else False
        p = _CTX["plain"]
    return p if p is not False else None


def _query_once(bootstrap_ip, ctx, hostname, rtype):
    sock = socket.create_connection((bootstrap_ip, 443), timeout=DOH_TIMEOUT)
    try:
        ssock = ctx.wrap_socket(sock, server_hostname=DOH_ENDPOINT_HOST)
    except Exception:
        try:
            sock.close()
        except Exception:
            pass
        raise
    try:
        path = "/dns-query?name={}&type={}&cd=false".format(
            urllib.parse.quote(hostname), rtype,
        )
        req = (
            "GET {} HTTP/1.1\r\n"
            "Host: {}\r\n"
            "Accept: application/dns-json\r\n"
            "User-Agent: {}\r\n"
            "Connection: close\r\n"
            "\r\n"
        ).format(path, DOH_ENDPOINT_HOST, USER_AGENT)
        ssock.sendall(req.encode("ascii"))
        chunks = []
        while True:
            chunk = ssock.recv(8192)
            if not chunk:
                break
            chunks.append(chunk)
        raw = b"".join(chunks)
    finally:
        try:
            ssock.close()
        except Exception:
            pass

    head, _, body = raw.partition(b"\r\n\r\n")
    headers = {}
    for line in head.split(b"\r\n")[1:]:
        if b":" in line:
            k, v = line.split(b":", 1)
            headers[k.strip().lower()] = v.strip().lower()
    if headers.get(b"transfer-encoding") == b"chunked":
        out = []
        i = 0
        while i < len(body):
            j = body.find(b"\r\n", i)
            if j < 0:
                break
            size = int(body[i:j].split(b";")[0], 16)
            if size == 0:
                break
            out.append(body[j + 2:j + 2 + size])
            i = j + 2 + size + 2
        body = b"".join(out)
    return json.loads(body.decode("utf-8", "replace"))


def _query_raw(hostname, rtype):
    """Tenta primeiro com verificação de certificado; se o handshake TLS
    falhar por CA (comum no Kodi), repete uma vez sem verificação."""
    bootstrap_ip = random.choice(DOH_BOOTSTRAP_IPS)
    last_ssl = None
    for _plain in (False, True):
        ctx = _ctx_plain() if _plain else _ctx_verified()
        if ctx is None:
            continue
        try:
            return _query_once(bootstrap_ip, ctx, hostname, rtype)
        except ssl.SSLError as exc:
            last_ssl = exc
            continue
    if last_ssl is not None:
        raise last_ssl
    raise RuntimeError("DoH: nenhum contexto TLS disponível")


def _parse_answer(data):
    ips4, ips6 = [], []
    ttl = DOH_TTL_DEFAULT
    answers = data.get("Answer") or []
    first = True
    for ans in answers:
        try:
            atype = int(ans.get("type", 0))
        except (TypeError, ValueError):
            continue
        ip = ans.get("data")
        if not ip:
            continue
        try:
            attl = int(ans.get("TTL", DOH_TTL_DEFAULT))
        except (TypeError, ValueError):
            attl = DOH_TTL_DEFAULT
        if first:
            ttl = attl
            first = False
        else:
            ttl = min(ttl, attl)
        if atype == 1 and _is_ip(ip):
            ips4.append(ip)
        elif atype == 28 and _is_ip(ip):
            ips6.append(ip)
    return ips4, ips6, ttl


def _lookup_uncached(hostname):
    ips4, ips6 = [], []
    ttls = []
    last_exc = None
    stop_at = time.time() + DOH_TOTAL_BUDGET
    for rtype in ("A", "AAAA"):
        if ips4 and time.time() >= stop_at:
            break
        try:
            data = _query_raw(hostname, rtype)
            r4, r6, ttl = _parse_answer(data)
            ips4.extend(r4)
            ips6.extend(r6)
            if r4 or r6:
                ttls.append(ttl)
        except Exception as exc:
            last_exc = exc
    if not ips4 and not ips6:
        if last_exc is not None:
            raise last_exc
        return [], [], DOH_NEGATIVE_TTL, True
    ttl = min(ttls) if ttls else DOH_TTL_DEFAULT
    return ips4, ips6, ttl, False


def _resolve(hostname, family):
    """Resolve via DoH Cloudflare. Devolve lista de IPs ou None.

    Não consulta o DNS do sistema: o fallback é responsabilidade de quem
    chama (hooks resolve_url etc.).
    """
    hostname = _clean_host(hostname)
    if not hostname:
        return None
    if _is_ip(hostname):
        return [hostname]

    entry = _cache_get(hostname)
    if entry is not None:
        if family == socket.AF_INET and entry.ips4:
            _bump("hits")
            return list(entry.ips4)
        if family == socket.AF_INET6 and entry.ips6:
            _bump("hits")
            return list(entry.ips6)
        if family in (0, socket.AF_UNSPEC):
            ips = list(entry.ips4) or list(entry.ips6)
            if ips:
                _bump("hits")
                return ips
        return None        # família sem registros: não reconsulta o DoH
    _bump("misses")

    my_event = None
    leader = False
    with _LOCK:
        ev = _INFLIGHT.get(hostname)
        if ev is None:
            ev = threading.Event()
            _INFLIGHT[hostname] = ev
            leader = True
        else:
            my_event = ev

    if not leader:
        my_event.wait(timeout=DOH_TIMEOUT + 1.0)
        entry = _cache_get(hostname)
        if entry is not None:
            if family == socket.AF_INET and entry.ips4:
                return list(entry.ips4)
            if family == socket.AF_INET6 and entry.ips6:
                return list(entry.ips6)
            ips = list(entry.ips4) or list(entry.ips6)
            if ips:
                return ips
        return None

    try:
        ips4, ips6, ttl, negative = _lookup_uncached(hostname)
        _cache_put(hostname, ips4, ips6, ttl)
        _note_success()
        if negative:
            _log(xbmc.LOGDEBUG, "NXDOMAIN %s", hostname)
        else:
            _log(xbmc.LOGDEBUG, "%s -> v4=%s v6=%s ttl=%ds",
                 hostname, ips4, ips6, ttl)
        if family == socket.AF_INET:
            return list(ips4) or None
        if family == socket.AF_INET6:
            return list(ips6) or None
        return (list(ips4) or list(ips6)) or None
    except Exception as exc:
        _bump("fails")
        _note_fail()
        _log(xbmc.LOGDEBUG, "falha resolvendo %s: %s", hostname, exc)
        return None
    finally:
        with _LOCK:
            if _INFLIGHT.get(hostname) is ev:
                _INFLIGHT.pop(hostname, None)
        ev.set()


# ---------------- API PÚBLICA ----------------

def resolve_list(hostname, family=socket.AF_UNSPEC):
    """Resolve um hostname e devolve a LISTA de IPs (ou None).

    DoH desativado nas configurações -> devolve None (quem chama decide
    o fallback). Falha do DoH -> None (idem).
    """
    if not is_enabled():
        return None
    return _resolve(hostname, family)


def resolve(hostname):
    """Resolve um hostname e devolve o primeiro IPv4 (str) ou None.

    Usado pelo vodproxy (doh_resolve). DoH desativado ou falhando ->
    tenta o DNS do sistema (gethostbyname ORIGINAL, sem passar pelos
    hooks); se também falhar, devolve None.
    """
    h = _clean_host(hostname)
    if not h:
        return hostname
    if _is_ip(h):
        return h
    if is_enabled():
        ips = _resolve(h, socket.AF_INET)
        if ips:
            return ips[0]
    try:
        return _ORIG_GETHOSTBYNAME(h)
    except Exception:
        return None


def system_gethostbyname(hostname):
    """DNS do sistema, direto no original (ignora os hooks)."""
    try:
        return _ORIG_GETHOSTBYNAME(hostname)
    except Exception:
        return None


def resolve_url(url):
    """Reescreve o hostname de uma URL pelo IP resolvido via DoH (IPv4).

    Mantém userinfo, porta e path. URLs com host já em IP, sem host ou
    que não puderam ser resolvidas são devolvidas sem alteração.
    """
    if not url:
        return url
    try:
        parsed = urllib.parse.urlparse(url)
        host = parsed.hostname
        if not host or _is_ip(host):
            return url
        ip = resolve(host)
        if not ip or ip == host or not _is_ip(ip):
            return url
        userinfo = ""
        if "@" in parsed.netloc:
            userinfo = parsed.netloc.rsplit("@", 1)[0] + "@"
        port = parsed.port
        new_netloc = "{}{}".format(userinfo, ip) + (":{}".format(port) if port else "")
        new_url = urllib.parse.urlunparse(parsed._replace(netloc=new_netloc))
        _log(xbmc.LOGDEBUG, "URL reescrita: %s -> %s", host, ip)
        return new_url
    except Exception as exc:
        _log(xbmc.LOGDEBUG, "resolve_url erro: %s", exc)
        return url


# ---------------- HOOKS GLOBAIS (socket) ----------------

def doh_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    """socket.getaddrinfo via DoH Cloudflare (com fallback de sistema)."""
    AI_NUMERICHOST = getattr(socket, "AI_NUMERICHOST", 0x4)
    if flags & AI_NUMERICHOST:
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    if not is_enabled():
        # DoH desativado nas configurações: DNS do sistema direto.
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    if isinstance(host, bytes):
        try:
            host = host.decode("ascii")
        except Exception:
            return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    h = _clean_host(host)
    if not h or _is_ip(h):
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)
    if h in ("localhost", "localhost.localdomain") or h.endswith(".local"):
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    if not _available():
        # breaker aberto: DoH suspenso, resolve direto pelo DNS do sistema
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    p = 0 if port is None else int(port)

    families = []
    if family == socket.AF_INET:
        families = [socket.AF_INET]
    elif family == socket.AF_INET6:
        families = [socket.AF_INET6]
    elif family in (socket.AF_UNSPEC, 0):
        families = [socket.AF_INET, socket.AF_INET6]
    else:
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)

    socktype = type if type else socket.SOCK_STREAM
    protocol = proto if proto else 0

    results = []
    for fam in families:
        ips = _resolve(host, fam)
        if not ips:
            continue
        for ip in ips:
            try:
                sockaddr = (ip, p) if fam == socket.AF_INET else (ip, p, 0, 0)
                results.append((fam, socktype, protocol, "", sockaddr))
            except Exception:
                continue
        if results:
            break

    if not results:
        _log(xbmc.LOGDEBUG, "DoH sem resultado para %s, usando sistema", host)
        return _ORIG_GETADDRINFO(host, port, family, type, proto, flags)
    return results


def doh_gethostbyname(hostname):
    """socket.gethostbyname via DoH Cloudflare (com fallback de sistema)."""
    h = _clean_host(hostname)
    if not h or _is_ip(h) or not is_enabled():
        return _ORIG_GETHOSTBYNAME(hostname)
    ips = _resolve(h, socket.AF_INET)
    if ips:
        return ips[0]
    return _ORIG_GETHOSTBYNAME(hostname)


_HOOKED = False
_HOOK_LOCK = threading.Lock()


def installed():
    """True se os hooks de DNS estão ativos no processo."""
    return (socket.getaddrinfo is doh_getaddrinfo
            and socket.gethostbyname is doh_gethostbyname)


def install():
    """Instala os hooks globais de DNS do processo (idempotente).

    A partir da chamada, TODAS as resoluções de nomes feitas em Python
    (urllib, requests, urllib3, sockets) passam pelo resolvedor —
    inclusive as dos proxies. Respeita a opção do addon em tempo quase
    real: com o DoH desativado os hooks apenas repassam ao DNS original.
    """
    global _HOOKED
    with _HOOK_LOCK:
        if _HOOKED and installed():
            return True
        try:
            global _ORIG_GETADDRINFO, _ORIG_GETHOSTBYNAME
            if socket.getaddrinfo is not doh_getaddrinfo:
                _ORIG_GETADDRINFO = socket.getaddrinfo
                socket.getaddrinfo = doh_getaddrinfo
            if socket.gethostbyname is not doh_gethostbyname:
                _ORIG_GETHOSTBYNAME = socket.gethostbyname
                socket.gethostbyname = doh_gethostbyname
            _HOOKED = True
            _log(xbmc.LOGINFO,
                 "hooks instalados (getaddrinfo/gethostbyname) — DoH Cloudflare %s",
                 "ATIVO" if is_enabled() else "DESATIVADO nas configurações")
            return True
        except Exception as exc:
            _log(xbmc.LOGERROR, "falha ao instalar os hooks de DNS: %s", exc)
            return False


def uninstall():
    """Restaura as funções originais de DNS do processo (idempotente)."""
    global _HOOKED
    with _HOOK_LOCK:
        try:
            if socket.getaddrinfo is doh_getaddrinfo:
                socket.getaddrinfo = _ORIG_GETADDRINFO
            if socket.gethostbyname is doh_gethostbyname:
                socket.gethostbyname = _ORIG_GETHOSTBYNAME
            _HOOKED = False
            _log(xbmc.LOGINFO, "hooks de DNS restaurados (DNS do sistema)")
            return True
        except Exception as exc:
            _log(xbmc.LOGERROR, "falha ao restaurar os hooks de DNS: %s", exc)
            return False


__all__ = [
    "install", "uninstall", "installed", "is_enabled", "refresh_settings",
    "resolve", "resolve_list", "resolve_url", "system_gethostbyname",
    "doh_getaddrinfo", "doh_gethostbyname", "cache_clear", "cache_stats",
]
