# -*- coding: utf-8 -*-
"""EPG: XMLTV (Xtream + URLs externas) em SQLite, parse em streaming (iterparse).

Carregamento em lotes e sem manter o XML em memória: roda em TV boxes com pouca RAM.
Fallback por canal: get_short_epg do painel. Tempos guardados como vieram; o ajuste de
fuso (setting epg_shift) é aplicado só na leitura.
"""
import calendar
import contextlib
import gzip
import os
import re
import time
import xml.etree.ElementTree as ET

import xbmc

from . import http
from .common import PROFILE, S, SB, SI, Cancelled, clean_title, log, norm_text, to_int
from .db import db, kv_get, kv_set
from .i18n import _

_TZ_RE = re.compile(r'^\s*(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)?\s*([+-]\d{4})?')
_CH_TAGS = re.compile(r'\b(?:hd|fhd|uhd|sd|4k|h265|hevc|h264|raw)\b')


def parse_xt_time(s):
    """'20261021203000 -0300' -> epoch UTC (sem offset = UTC)."""
    m = _TZ_RE.match(s or '')
    if not m:
        return 0
    y, mo, d, h, mi, sec, tz = m.groups()
    try:
        ts = calendar.timegm((int(y), int(mo), int(d), int(h), int(mi), int(sec or 0)))
    except (ValueError, OverflowError):
        return 0
    if tz:
        off = (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60) * (1 if tz[0] == '+' else -1)
        ts -= off
    return ts


def norm_chan(name):
    """'BR| Globo SP HD' -> 'globosp' (para casar nomes entre painel e XMLTV)."""
    s = re.sub(r'[\[\(\{][^\]\)\}]*[\]\)\}]', ' ', clean_title(name or ''))
    s = _CH_TAGS.sub(' ', norm_text(s))
    return re.sub(r'\s+', '', s)


@contextlib.contextmanager
def open_xml(path):
    """Abre XML puro ou gzip (inclusive gzip duplo)."""
    opened = [open(path, 'rb')]
    f = opened[0]
    try:
        for _i in range(2):
            if f.peek(2)[:2] == b'\x1f\x8b':
                f = gzip.GzipFile(fileobj=f, mode='rb')
                opened.append(f)
            else:
                break
        yield f
    finally:
        for o in reversed(opened):
            try:
                o.close()
            except Exception:
                pass


def _pick(el, tag):
    best = ''
    for t in el.findall(tag):
        txt = (t.text or '').strip()
        if not txt:
            continue
        if (t.get('lang') or '').lower().startswith('pt'):
            return txt
        best = best or txt
    return best


_INS = 'INSERT OR REPLACE INTO epg(ch, start, stop, title, descr) VALUES (?,?,?,?,?)'


def parse_xmltv(fobj, t_min, t_max, keep_ids=None, keep_names=None, abort=None, batch=3000):
    """Lê XMLTV em streaming e grava na tabela epg.

    keep_ids: ids (minúsculos) a guardar (None = todos); keep_names: nomes normalizados
    p/ casar canais de XMLTV externo que não usam o mesmo id do painel."""
    c = db().conn()
    rows, names, matched = [], [], set()
    total = n = 0
    root = None
    try:
        for ev, el in ET.iterparse(fobj, events=('start', 'end')):
            if ev == 'start':
                if root is None:
                    root = el
                continue
            tag = el.tag
            if tag == 'programme':
                ch = (el.get('channel') or '').strip().lower()
                if ch and (keep_ids is None or ch in keep_ids or ch in matched):
                    start = parse_xt_time(el.get('start'))
                    stop = parse_xt_time(el.get('stop'))
                    if start and stop and stop >= t_min and start <= t_max:
                        rows.append((ch, start, stop, _pick(el, 'title'),
                                     _pick(el, 'desc') or _pick(el, 'sub-title')))
                        total += 1
                        if len(rows) >= batch:
                            c.executemany(_INS, rows)
                            c.commit()
                            rows = []
                el.clear()
            elif tag == 'channel':
                cid = (el.get('id') or '').strip().lower()
                if cid and keep_names:
                    for dn in el.findall('display-name'):
                        nn = norm_chan(dn.text or '')
                        if nn:
                            names.append((nn, cid))
                            if nn in keep_names:
                                matched.add(cid)
                el.clear()
            n += 1
            if n % 5000 == 0:
                if root is not None:
                    root.clear()
                if abort and abort():
                    raise Cancelled()
    except ET.ParseError as e:
        log('XMLTV truncado/inválido (%s); mantendo o que foi lido.' % e, xbmc.LOGWARNING)
    if rows:
        c.executemany(_INS, rows)
    if names:
        c.executemany('INSERT OR IGNORE INTO epgname(norm, ch) VALUES (?,?)', names)
    c.commit()
    return total


def summarize(progs, now=None):
    """Lista de (start, stop, title, descr) -> {'now', 'next', 'later'} (programa atual e os seguintes)."""
    now = now or time.time()
    cur, rest = None, []
    for p in progs or []:
        if p[0] <= now < p[1]:
            cur = p
        elif p[0] > now:
            rest.append(p)
    return {'now': cur, 'next': rest[0] if rest else None, 'later': rest[1] if len(rest) > 1 else None}


class Epg(object):
    def __init__(self, xt):
        self.xt = xt
        self._names = None

    # ------------------------------------------------------------ estado
    def last_update(self):
        return to_int(kv_get('epg_ts'))

    def due(self):
        return (time.time() - self.last_update()) >= max(1, SI('epg_interval', 12)) * 3600

    def has_data(self):
        return db().q1('SELECT 1 FROM epg LIMIT 1') is not None

    # --------------------------------------------------------- atualização
    def refresh(self, progress=None, force=False, abort=None):
        """Baixa e indexa o EPG. Devolve nº de programas gravados."""
        if not SB('epg_enable', True):
            return 0
        if not force and (not self.due() or time.time() - to_int(kv_get('epg_busy')) < 900):
            return 0
        sources = []
        if self.xt.configured:
            sources.append(('xtream', self.xt.xmltv_url()))
        for u in re.split(r'[\s,;]+', S('epg_url', '')):
            if u.lower().startswith(('http://', 'https://')):
                sources.append(('ext', u))
        if not sources:
            return 0
        ids = {(r['epg'] or '').lower() for r in
               db().q("SELECT DISTINCT epg FROM item WHERE kind='live' AND epg<>''")}
        names = set()
        if SB('epg_name_match', True):
            names = {norm_chan(r['name']) for r in db().q("SELECT name FROM item WHERE kind='live'")}
            names.discard('')
        now = int(time.time())
        t_min, t_max = now - 3 * 3600, now + max(1, SI('epg_days', 2)) * 86400
        total = 0
        kv_set('epg_busy', now)
        try:
            for i, (kind, url) in enumerate(sources):
                try:
                    total += self._load(url, kind, t_min, t_max, ids, names, progress, i, len(sources), abort)
                except Cancelled:
                    raise
                except Exception as e:
                    log('EPG (%s) falhou: %s' % (kind, e), xbmc.LOGWARNING)
            db().x('DELETE FROM epg WHERE stop < ?', (now - 6 * 3600,))
            kv_set('epg_ts', now)
            self._names = None
        finally:
            kv_set('epg_busy', 0)
        log('EPG atualizado: %d programas' % total)
        return total

    def _load(self, url, kind, t_min, t_max, ids, names, progress, idx, n, abort):
        tmp = os.path.join(PROFILE, 'epg_download.tmp')
        base, span = 100.0 * idx / n, 100.0 / n

        def dl(done, size):
            if abort and abort():
                return False
            if progress:
                frac = (float(done) / size) if size else 0.5
                progress(int(base + span * 0.5 * frac), _('Baixando EPG…'))
            return True

        http.download(url, tmp, headers={'User-Agent': self.xt.ua}, timeout=90,
                      verify=self.xt.verify if kind == 'xtream' else True, progress=dl)
        try:
            if progress:
                progress(int(base + span * 0.5), _('Processando EPG…'))
            with open_xml(tmp) as f:
                if kind == 'xtream':
                    return parse_xmltv(f, t_min, t_max, keep_ids=ids or None, abort=abort)
                return parse_xmltv(f, t_min, t_max, keep_ids=ids, keep_names=names, abort=abort)
        finally:
            try:
                os.remove(tmp)
            except OSError:
                pass

    # ------------------------------------------------------------- consulta
    def _name_map(self):
        if self._names is None:
            self._names = {r['norm']: r['ch'] for r in db().q('SELECT norm, ch FROM epgname')}
        return self._names

    def _keys(self, row):
        ks = []
        e = (row.get('epg') or '').strip().lower()
        if e:
            ks.append(e)
        ks.append('sid:%s' % row['id'])
        return ks

    def _query(self, keys, frm, to):
        """Janela em horário de exibição -> {chave: [(start, stop, title, descr)]} (já com fuso)."""
        shift = SI('epg_shift', 0) * 3600
        keys = list(keys)
        out = {}
        for i in range(0, len(keys), 400):
            chunk = keys[i:i + 400]
            sql = ('SELECT ch, start, stop, title, descr FROM epg WHERE ch IN (%s) AND stop > ? '
                   'AND start < ? ORDER BY ch, start' % ','.join('?' * len(chunk)))
            for r in db().q(sql, chunk + [frm - shift, to - shift]):
                out.setdefault(r['ch'], []).append(
                    (r['start'] + shift, r['stop'] + shift, r['title'] or '', r['descr'] or ''))
        return out

    def for_items(self, rows, n=3, now=None):
        """{id do canal: [até n programas a partir de agora]} em uma consulta em lote."""
        now = int(now or time.time())
        cand = {r['id']: self._keys(r) for r in rows}
        allkeys = set(k for ks in cand.values() for k in ks)
        data = self._query(allkeys, now, now + 12 * 3600)
        out, missing = {}, []
        for r in rows:
            for k in cand[r['id']]:
                if data.get(k):
                    out[r['id']] = data[k][:n]
                    break
            else:
                missing.append(r)
        if missing and SB('epg_name_match', True):
            nm = self._name_map()
            if nm:
                byname = {}
                for r in missing:
                    ch = nm.get(norm_chan(r['name']))
                    if ch:
                        byname[r['id']] = ch
                data2 = self._query(set(byname.values()), now, now + 12 * 3600)
                for rid, ch in byname.items():
                    if data2.get(ch):
                        out[rid] = data2[ch][:n]
        return out

    def schedule(self, row, hours=24, now=None):
        """Programação do canal (de 2h atrás até 'hours' à frente); cai no short EPG do painel."""
        now = int(now or time.time())
        keys = self._keys(row)
        nm = self._name_map() if SB('epg_name_match', True) else {}
        byname = nm.get(norm_chan(row.get('name') or ''))
        if byname:
            keys.append(byname)
        data = self._query(keys, now - 2 * 3600, now + hours * 3600)
        for k in keys:
            if data.get(k):
                return data[k]
        return self.fetch_short(row)

    def fetch_short(self, row):
        """Busca direto no painel (get_short_epg) e guarda sob a chave 'sid:<id>'."""
        try:
            progs = self.xt.short_epg(row['id'], 12)
        except Exception as e:
            log('short EPG de %s falhou: %s' % (row.get('id'), e))
            return []
        if not progs:
            return []
        db().many(_INS, [('sid:%s' % row['id'], s, e, t, d) for (s, e, t, d) in progs])
        shift = SI('epg_shift', 0) * 3600
        return [(s + shift, e + shift, t, d) for (s, e, t, d) in progs]
