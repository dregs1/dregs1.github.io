# -*- coding: utf-8 -*-
# hlsproxy.py
#
# HLS LOCAL PROXY — http.server (stdlib) + requests
#
# v2.4.0 — Sistema REF (Refresh/Reconnect/Fetch): quando um segmento/chave/
#          manifesto falha, reconecta automaticamente à URL DE ENTRADA do
#          canal, re-busca o manifesto atual (tokens novos), localiza o
#          segmento falhado e o serve — sem travar nem derrubar o player.
#          DoH consertado (CA certifi + fallback sem verificação + circuit
#          breaker) e segmentos bufferizados por completo (fim do corpo
#          truncado que corrompia a reprodução ao vivo).

import base64
import collections
import http.client
import http.server
import json
import logging
import queue
import random
import re
import select
import socket
import socketserver
import ssl
import sys
import threading
import time
import traceback
import urllib.parse

import requests
from requests.adapters import HTTPAdapter

try:
    from urllib3.util.retry import Retry
except Exception:  # pragma: no cover
    Retry = None

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:  # pragma: no cover
    xbmc = None
    xbmcgui = None
    xbmcplugin = None

__version__ = "2.4.0"

# ---------------- CONFIGURAÇÃO ----------------

LOCAL_HOST = "127.0.0.1"
BIND_HOST = "0.0.0.0"
PORT = 8080

CONNECT_TIMEOUT = 4
READ_TIMEOUT = 8
READ_TIMEOUT_STREAM = 8
MAX_REDIRECTS = 8
RETRIES = 3
RETRY_BASE = 0.25
MAX_RETRY_DELAY = 1.0
CHUNK_SIZE = 64 * 1024

FETCH_BUDGET = 8.0
MIN_CONNECT_TIMEOUT = 1.0
MIN_READ_TIMEOUT = 4.0

MAX_MANIFEST_BYTES = 8 * 1024 * 1024
MAX_KEY_BYTES = 64 * 1024
CLIENT_TIMEOUT = 60

STALL_TIMEOUT = 10.0
MAX_CONNS_PER_HOST = 6           # era 2 — ffmpeg abre várias conexões

# --- Master playlist & Adaptive Quality ---
MASTER_VARIANT = "adaptive"
MAX_HEIGHT = 0
MAX_BANDWIDTH = 0

# --- Cache de manifesto ---
MASTER_CACHE_TTL = 30.0
VOD_MANIFEST_TTL = 120.0
MANIFEST_CACHE_TTL_MIN = 0.8
MANIFEST_CACHE_TTL_MAX = 2.5
STALE_MANIFEST_MAX_AGE = 45.0

SEQ_BACKWARD_TOLERANCE = 10
SEQ_RETRIES = 2
SEQ_RETRY_DELAY = 0.25

# --- Cache / read-ahead de segmentos ---
SEGMENT_CACHE_BYTES = 32 * 1024 * 1024
SEGMENT_CACHE_TTL = 90.0
SEGMENT_MAX_CACHE = 10 * 1024 * 1024
LAST_SEGMENT_CACHE_TTL = 120.0

PREFETCH_AHEAD = 2
PREFETCH_BUDGET = 20.0
PREFETCH_WAIT = 5.0
PREFETCH_JOB_MAX_AGE = 30.0
PREFETCH_RESUBMIT_TTL = 120.0

SEGMENT_TOTAL_BUDGET = 8.0
SEGMENT_EXTENDED_RETRIES = 3
SEGMENT_EXTENDED_BACKOFF = 0.4

KEY_CACHE_TTL = 120.0

STICKY_EDGE = True
STICKY_MAX_AGE = 900.0
SEQ_JUMP_TOLERANCE = 10

# --- Playlist live virtual (anti-loop, anti-stall) ---
LIVE_VIRTUAL = True
LIVE_KEEP_SEGMENTS = 10          # equilíbrio janela/latência
LIVE_IDLE_TIMEOUT = 45.0
LIVE_FETCH_BUDGET = 8.0
LIVE_POLL_MIN = 1.5
LIVE_POLL_MAX = 5.0
LIVE_RESOLVE_INTERVAL = 120.0
LIVE_RESTART_TOLERANCE = 30
LIVE_NODE_RETRIES = 2
LIVE_HOST_MEMO = 60.0
LIVE_EDGE_PENALTY = 300.0
LIVE_MAX_EDGE_SWITCHES = 3

LAST_SEGMENT_FALLBACK = True    # última defesa contra 502 (só mesmo nome de segmento)
RESUME_ATTEMPTS = 2
RESUME_BUDGET = 6.0

# --- Sistema REF (Refresh/Reconnect/Fetch) ---
# Reconecta à URL DE ENTRADA do canal, re-busca o manifesto atual e serve o
# recurso falhado sem interromper a reprodução.
REF_ENABLED = True
REF_MAX_RECONNECTS = 3           # reconexões completas à entrada por pedido
REF_TOTAL_BUDGET = 18.0          # orçamento (s) para recuperar um recurso
REF_RETRY_DELAY = 0.3            # pausa entre ciclos de reconexão
REF_MAP_TTL = 3.0                # mapa fresco do canal reutilizado por N s
REF_MIN_INTERVAL = 2.0           # intervalo mínimo entre reconexões do canal
REF_STALE_GRACE = 60.0           # cache vencido há < N s ainda serve (emergência)
REF_BUFFER_MAX = 12 * 1024 * 1024   # tamanho máx. bufferizado antes de responder

DEBUG = False

# --- DoH Cloudflare ---
DOH_ENDPOINT_HOST = "cloudflare-dns.com"
DOH_BOOTSTRAP_IPS = ("1.1.1.1", "1.0.0.1")
DOH_TIMEOUT = 1.5
DOH_TOTAL_BUDGET = 2.5           # teto para A+AAAA na mesma consulta
DOH_BREAKER_THRESHOLD = 3        # falhas seguidas antes de abrir o breaker
DOH_BREAKER_COOLDOWN = 120.0     # DoH suspenso por N s (usa DNS do sistema)
DOH_TTL_DEFAULT = 300
DOH_TTL_MIN = 30
DOH_TTL_MAX = 3600
DOH_NEGATIVE_TTL = 20
DOH_MAX_ENTRIES = 4096

USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 10) "
    "AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
)

REDIRECT_CODES = (301, 302, 303, 307, 308)
RETRY_CODES = (406, 408, 425, 429, 500, 502, 503, 504, 521, 522, 523, 524)
AUTH_FAIL_CODES = (401, 403)

USAGE = (
    "Uso: /manifest/<base64url>.m3u8  ou  "
    "/?type=manifest&url=https%3A%2F%2Fservidor%2Flista.m3u8\n"
)

CLIENT_GONE = (
    BrokenPipeError,
    ConnectionResetError,
    ConnectionAbortedError,
    socket.timeout,
    ConnectionError,
)

_KINDS = ("manifest", "segment", "key")
_PATH_RE = re.compile(r"^/(manifest|segment|key)/([A-Za-z0-9_-]+)(?:\.[A-Za-z0-9]{1,8})?$")
_URI_ATTR_RE = re.compile(r"""(?<![\w-])(URI\s*=\s*)(["'])(.*?)\2""", re.IGNORECASE)
_HOST_RE = re.compile(r"^(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:.]+\])(?::\d{1,5})?$")

_KEY_TAGS = ("#EXT-X-KEY", "#EXT-X-SESSION-KEY")
_MANIFEST_TAGS = ("#EXT-X-MEDIA", "#EXT-X-I-FRAME-STREAM-INF", "#EXT-X-RENDITION-REPORT")
_SEGMENT_EXTS = frozenset((
    "ts", "m4s", "mp4", "m4v", "m4a", "aac", "ac3", "eac3", "mp3",
    "mkv", "mov", "vtt", "webvtt",
))
_CTYPES = {
    "m4s": "video/mp4", "mp4": "video/mp4", "m4v": "video/mp4",
    "m4a": "audio/mp4", "aac": "audio/aac", "ac3": "audio/ac3",
    "eac3": "audio/eac3", "mp3": "audio/mpeg", "mkv": "video/x-matroska",
    "mov": "video/quicktime", "vtt": "text/vtt", "webvtt": "text/vtt",
}

# ---------------- LOG / ESTATÍSTICAS ----------------

_LOG_PREFIX = "[HLSPROXY] "
_pylog = logging.getLogger("hlsproxy")
_pylog.addHandler(logging.NullHandler())

STATS = {
    "manifest": 0, "segment": 0, "key": 0, "errors": 0,
    "cache_hit": 0, "token_refresh": 0, "last_segment_fallback": 0,
    "seq_rejected": 0, "prefetch_ok": 0, "prefetch_fail": 0,
    "stale_manifest": 0, "seq_renumbered": 0, "host_switch": 0,
    "dup_skipped": 0, "doh_hit": 0, "doh_miss": 0, "doh_fail": 0,
    "edge_rejected": 0, "loop_guard": 0, "render_fallback": 0,
    "doh_breaker": 0, "ref_reconnect": 0, "ref_skip_recent": 0,
    "ref_map_hit": 0, "ref_recovered": 0, "stale_segment": 0,
}
_STATS_LOCK = threading.Lock()

_PLAY_AT = 0.0
_FIRST = {"manifest": False, "segment": False}
_FIRST_LOCK = threading.Lock()

_BANDWIDTH_HISTORY = collections.deque(maxlen=6)


def record_bandwidth(bytes_transferred, elapsed_time):
    if elapsed_time > 0:
        bw = (bytes_transferred * 8) / elapsed_time
        with _STATS_LOCK:
            _BANDWIDTH_HISTORY.append(bw)


def get_estimated_bandwidth():
    with _STATS_LOCK:
        if not _BANDWIDTH_HISTORY:
            return 0
        return sum(_BANDWIDTH_HISTORY) / len(_BANDWIDTH_HISTORY)


def _to_bytes(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode("utf-8")
    return str(value).encode("utf-8")


def _to_text(value):
    if isinstance(value, str):
        return value
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def _fmt(message, *args):
    text = _to_text(message)
    if not args:
        return text
    try:
        return text % tuple(
            a.decode("utf-8", "replace") if isinstance(a, bytes) else a
            for a in args
        )
    except Exception:
        return text


def _log(level, message, *args):
    # LOG DESATIVADO — blindagem anti-vazamento: URLs de stream (com
    # usuário/senha), hosts de origem e edges nunca chegam ao kodi.log.
    return None


def _bump(name, n=1):
    with _STATS_LOCK:
        STATS[name] = STATS.get(name, 0) + n


def _short(url):
    try:
        p = urllib.parse.urlsplit(url)
        host = p.hostname or ""
        if ":" in host:
            host = "[{}]".format(host)
        port = p.port
        hostport = "{}:{}".format(host, port) if port else host
        return "{}://{}/.../{}".format(
            p.scheme, hostport, p.path.rsplit("/", 1)[-1][:48]
        )
    except Exception:
        return "?"


def _segment_ctype(url):
    try:
        name = urllib.parse.urlparse(url).path.rsplit("/", 1)[-1]
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    except Exception:
        ext = ""
    return _CTYPES.get(ext, "video/mp2t")


# =====================================================================
# DoH — RESOLVEDOR CENTRAL DO ADDON (resources/lib/dohresolver.py)
# ---------------------------------------------------------------------
# O DoH embutido do hlsproxy foi SUBSTITUÍDO pelo resolvedor central do
# addon (Cloudflare): todas as consultas DNS deste proxy — e de todo o
# restante do addon — passam por ele. O resolvedor central respeita a
# opção "Resolver DNS pela Cloudflare (DoH)" nas configurações do addon
# (padrão: ATIVA) e faz fallback automático para o DNS do sistema.
# =====================================================================

try:  # uso normal: dentro do pacote resources/lib do addon
    from . import dohresolver as _dohresolver
except Exception:  # pragma: no cover — standalone / outros layouts
    try:
        from resources.lib import dohresolver as _dohresolver
    except Exception:
        import dohresolver as _dohresolver


def _doh_log(level, msg, *args):
    _log(level, "[DoH] " + msg, *args)


def _doh_resolve(hostname, family):
    """Delega a resolução ao resolvedor central do addon (Cloudflare)."""
    return _dohresolver.resolve_list(hostname, family)


def doh_cache_clear():
    """Limpa o cache de DNS do resolvedor central."""
    _dohresolver.cache_clear()


def doh_cache_stats():
    """Estatísticas do cache de DNS do resolvedor central."""
    return _dohresolver.cache_stats()


# Instala os hooks globais de DNS do resolvedor central (idempotente).
# A partir daqui TODAS as consultas DNS do processo — inclusive as
# deste proxy (requests/urllib3 usam socket.getaddrinfo) — passam pelo
# resolvedor central, que honra a opção DoH das configurações.
_dohresolver.install()


# ---------------- SESSÃO ÚNICA E PERSISTENTE ----------------

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": USER_AGENT})

if Retry is not None:
    _upstream_retry = Retry(
        connect=1, read=0, status=0, redirect=0,
        backoff_factor=0.1, raise_on_status=False,
    )
else:
    _upstream_retry = 1

_ADAPTER = HTTPAdapter(
    pool_connections=16,
    pool_maxsize=32,
    max_retries=_upstream_retry,
)
SESSION.mount("http://", _ADAPTER)
SESSION.mount("https://", _ADAPTER)


# ---------------- SEMÁFORO POR HOST ----------------

class _HostGate:
    __slots__ = ("sem", "locks_lock", "locks")

    def __init__(self, limit):
        self.sem = threading.BoundedSemaphore(max(1, limit))
        self.locks_lock = threading.Lock()
        self.locks = {}

    def lock_for(self, url):
        with self.locks_lock:
            lock = self.locks.get(url)
            if lock is None:
                lock = threading.Lock()
                self.locks[url] = lock
                if len(self.locks) > 512:
                    for k, v in list(self.locks.items()):
                        if not v.locked() and k != url:
                            self.locks.pop(k, None)
            return lock


_GATES = {}
_GATES_LOCK = threading.Lock()


def _gate_for(url):
    try:
        host = urllib.parse.urlsplit(url).netloc.rsplit("@", 1)[-1].lower()
    except Exception:
        host = "?"
    with _GATES_LOCK:
        gate = _GATES.get(host)
        if gate is None:
            gate = _HostGate(MAX_CONNS_PER_HOST)
            _GATES[host] = gate
        return gate


# ---------------- CACHE ----------------

class _TTLCache:
    def __init__(self, max_bytes, ttl):
        self.max_bytes = max_bytes
        self.ttl = ttl
        self._data = collections.OrderedDict()
        self._bytes = 0
        self._lock = threading.Lock()

    def get(self, key):
        now = time.time()
        with self._lock:
            item = self._data.get(key)
            if item is None:
                return None
            expire, data = item
            if expire < now:
                return None      # vencido: mantém para get_stale()
            self._data.move_to_end(key)
            return data

    def get_stale(self, key, grace):
        """Retorna mesmo vencido dentro da janela de graça (emergência REF)."""
        now = time.time()
        with self._lock:
            item = self._data.get(key)
            if item is None:
                return None
            expire, data = item
            if now <= expire + max(0.0, grace):
                return data
            self._data.pop(key, None)
            self._bytes -= len(data)
            return None

    def put(self, key, data):
        if self.max_bytes <= 0:
            return
        size = len(data)
        if size > self.max_bytes:
            return
        now = time.time()
        with self._lock:
            old = self._data.pop(key, None)
            if old is not None:
                self._bytes -= len(old[1])
            self._data[key] = (now + self.ttl, data)
            self._bytes += size
            while self._bytes > self.max_bytes and self._data:
                _, (_, evicted) = self._data.popitem(last=False)
                self._bytes -= len(evicted)

    def clear(self):
        with self._lock:
            self._data.clear()
            self._bytes = 0


_SEGMENT_CACHE = _TTLCache(SEGMENT_CACHE_BYTES, SEGMENT_CACHE_TTL)
_KEY_CACHE = _TTLCache(1024 * 1024, KEY_CACHE_TTL)


class _LastSegmentCache:
    def __init__(self, ttl):
        self.ttl = ttl
        self._data = {}
        self._lock = threading.Lock()

    def get(self, manifest_url, name=None):
        now = time.time()
        with self._lock:
            item = self._data.get(manifest_url)
            if item is None:
                return None
            expire, sname, data = item
            if expire < now:
                self._data.pop(manifest_url, None)
                return None
            if name is not None and sname != name:
                return None
            return data

    def put(self, manifest_url, name, data):
        if not data or not name:
            return
        with self._lock:
            self._data[manifest_url] = (time.time() + self.ttl, name, data)
            if len(self._data) > 16:
                oldest = sorted(self._data.items(), key=lambda kv: kv[1][0])[:4]
                for k, _ in oldest:
                    self._data.pop(k, None)

    def clear(self):
        with self._lock:
            self._data.clear()


_LAST_SEGMENT = _LastSegmentCache(LAST_SEGMENT_CACHE_TTL)


class _ManifestEntry:
    __slots__ = ("expire", "stored", "final_url", "body", "media_sequence",
                 "is_live", "is_master", "segments", "seg_index",
                 "variant_url", "target", "complex")

    def __init__(self, ttl, final_url, body, meta, variant_url=None):
        now = time.time()
        self.expire = now + ttl
        self.stored = now
        self.final_url = final_url
        self.body = body
        self.media_sequence = meta["seq"]
        self.is_live = meta["is_live"]
        self.is_master = meta["is_master"]
        self.segments = meta["segments"]
        self.seg_index = {u: i for i, u in enumerate(self.segments)}
        self.variant_url = variant_url
        self.target = meta["target"]
        self.complex = meta["complex"]


_MANIFEST_CACHE = {}
_MANIFEST_LOCK = threading.Lock()


def _parse_manifest_meta(text, base_url):
    seq = None
    is_vod = False
    is_master = False
    target = None
    complex_ = False
    segments = []
    durations = []
    discs = []
    pending_dur = None
    pending_disc = False

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            upper = line.upper()
            if upper.startswith("#EXT-X-MEDIA-SEQUENCE:"):
                try:
                    seq = int(line.split(":", 1)[1].strip())
                except (ValueError, IndexError):
                    pass
            elif upper.startswith("#EXT-X-TARGETDURATION:"):
                try:
                    target = float(line.split(":", 1)[1].strip())
                except (ValueError, IndexError):
                    pass
            elif upper.startswith("#EXT-X-PLAYLIST-TYPE:"):
                if "VOD" in upper:
                    is_vod = True
            elif upper.startswith("#EXT-X-ENDLIST"):
                is_vod = True
            elif upper.startswith("#EXT-X-STREAM-INF"):
                is_master = True
            elif upper.startswith("#EXTINF:"):
                try:
                    pending_dur = float(line.split(":", 1)[1].split(",", 1)[0])
                except (ValueError, IndexError):
                    pending_dur = None
            elif (upper.startswith("#EXT-X-DISCONTINUITY")
                  and not upper.startswith("#EXT-X-DISCONTINUITY-SEQUENCE")):
                pending_disc = True
            elif upper.startswith(("#EXT-X-MAP", "#EXT-X-BYTERANGE")):
                complex_ = True
            elif upper.startswith(("#EXT-X-KEY", "#EXT-X-SESSION-KEY")):
                if "METHOD=NONE" not in upper:
                    complex_ = True
            continue
        absolute = urllib.parse.urljoin(base_url, line)
        if _is_http(absolute):
            segments.append(absolute)
            durations.append(pending_dur if pending_dur else (target or 6.0))
            discs.append(pending_disc)
        pending_dur = None
        pending_disc = False

    if is_master:
        segments, durations, discs = [], [], []
    return {
        "seq": seq,
        "is_live": not is_vod,
        "is_master": is_master,
        "target": target,
        "segments": segments,
        "durations": durations,
        "discs": discs,
        "complex": complex_,
    }


def _manifest_ttl(meta):
    if meta["is_master"]:
        return MASTER_CACHE_TTL
    if not meta["is_live"]:
        return VOD_MANIFEST_TTL
    target = meta["target"] or 6.0
    return min(max(target / 4.0, MANIFEST_CACHE_TTL_MIN), MANIFEST_CACHE_TTL_MAX)


def _manifest_cache_get(url, allow_stale=False):
    if not url:
        return None
    now = time.time()
    with _MANIFEST_LOCK:
        entry = _MANIFEST_CACHE.get(url)
        if entry is None:
            return None
        if entry.expire >= now:
            return entry
        if allow_stale and (now - entry.expire) <= STALE_MANIFEST_MAX_AGE:
            return entry
        return None


def _manifest_cache_put(url, entry):
    with _MANIFEST_LOCK:
        _MANIFEST_CACHE[url] = entry
        if len(_MANIFEST_CACHE) > 64:
            oldest = sorted(_MANIFEST_CACHE.items(), key=lambda kv: kv[1].stored)[:16]
            for k, _ in oldest:
                if k != url:
                    _MANIFEST_CACHE.pop(k, None)


_SEQ_STATE = {}
_STICKY = {}
_SEQ_LOCK = threading.Lock()
_SEQ_LINE_RE = re.compile(r"(?im)^(#EXT-X-MEDIA-SEQUENCE:)[ \t]*\d+")


def _manifest_cache_clear():
    with _MANIFEST_LOCK:
        _MANIFEST_CACHE.clear()
    with _SEQ_LOCK:
        _SEQ_STATE.clear()
        _STICKY.clear()
    with _LIVES_LOCK:
        lives = list(_LIVES.values())
        _LIVES.clear()
        _LIVE_LAST.clear()
    for live in lives:
        live.stop_ev.set()


def _reset_stream_state(url):
    with _LIVES_LOCK:
        live = _LIVES.pop(url, None)
        _LIVE_LAST.pop(url, None)
    if live is not None:
        live.stop_ev.set()
    with _SEQ_LOCK:
        _SEQ_STATE.pop(url, None)
        _STICKY.pop(url, None)
    with _MANIFEST_LOCK:
        _MANIFEST_CACHE.pop(url, None)
    with _REF_LOCK:
        _REF_STATE.pop(url, None)


def _sticky_target(url):
    if not STICKY_EDGE:
        return url
    with _SEQ_LOCK:
        item = _STICKY.get(url)
        if item is None:
            return url
        final_url, since = item
        if time.time() - since > STICKY_MAX_AGE:
            _STICKY.pop(url, None)
            return url
        return final_url


def _sticky_forget(url):
    with _SEQ_LOCK:
        _STICKY.pop(url, None)


def _sticky_remember(url, final_url, fetched_via_original):
    if not STICKY_EDGE:
        return
    with _SEQ_LOCK:
        if fetched_via_original or url not in _STICKY:
            _STICKY[url] = (final_url, time.time())


def _normalize_sequence(url, text, meta):
    """Apenas para pipeline não-live (VOD/relay). Nunca use em _LiveStream."""
    raw = meta["seq"]
    segs = meta["segments"]
    if raw is None or meta["is_master"] or not meta["is_live"] or not segs:
        return text, meta
    now = time.time()
    with _SEQ_LOCK:
        st = _SEQ_STATE.get(url)
        if st is None:
            _SEQ_STATE[url] = {"offset": 0, "out": raw, "segs": segs, "t": now}
            return text, meta
        out = raw + st["offset"]
        prev_out = st["out"]
        prev_segs = st["segs"]
        prev_end = prev_out + len(prev_segs)
        coherent = prev_out <= out <= prev_end + max(SEQ_JUMP_TOLERANCE, len(segs))
        if not coherent:
            prev_idx = {u: i for i, u in enumerate(prev_segs)}
            new_out = None
            for i, u in enumerate(segs):
                if u in prev_idx:
                    new_out = prev_out + prev_idx[u] - i
                    break
            if new_out is None:
                target = meta["target"] or 6.0
                adv = int(round((now - st["t"]) / max(target, 1.0)))
                new_out = prev_out + max(0, adv)
            if new_out >= prev_out:
                st["offset"] = new_out - raw
                out = new_out
                _bump("seq_renumbered")
        if out >= prev_out:
            st["out"] = out
            st["segs"] = segs
            st["t"] = now
    if out != raw:
        text = _SEQ_LINE_RE.sub(lambda m: m.group(1) + str(out), text, count=1)
        meta["seq"] = out
    return text, meta


# ---------------- MASTER PLAYLIST & ADAPTAÇÃO ----------------

def _attr(line, name):
    m = re.search(
        r'(?<![\w-])' + re.escape(name) + r'=(?:"([^"]*)"|([^,]*))',
        line, re.IGNORECASE,
    )
    if not m:
        return None
    if m.group(1) is not None:
        return m.group(1)
    return (m.group(2) or "").strip()


def _collapse_master(text):
    lines = text.splitlines()
    n = len(lines)
    variants = []
    i = 0
    while i < n:
        s = lines[i].strip()
        if s.upper().startswith("#EXT-X-STREAM-INF"):
            j = i + 1
            while j < n and (not lines[j].strip() or lines[j].strip().startswith("#")):
                j += 1
            if j >= n:
                break
            try:
                bw = int(_attr(s, "BANDWIDTH") or 0)
            except ValueError:
                bw = 0
            height = 0
            res = (_attr(s, "RESOLUTION") or "").lower()
            if "x" in res:
                try:
                    height = int(res.split("x", 1)[1])
                except ValueError:
                    height = 0
            variants.append({"inf": i, "uri": j, "bw": bw, "h": height, "line": s})
            i = j + 1
            continue
        i += 1

    if not variants:
        return text, None

    def uri_of(v):
        return lines[v["uri"]].strip()

    if len(variants) == 1:
        return text, uri_of(variants[0])
    if MASTER_VARIANT == "all":
        return text, None

    pool = variants
    if MAX_HEIGHT > 0:
        capped = [v for v in pool if 0 < v["h"] <= MAX_HEIGHT]
        if capped:
            pool = capped
    if MAX_BANDWIDTH > 0:
        capped = [v for v in pool if 0 < v["bw"] <= MAX_BANDWIDTH]
        if capped:
            pool = capped

    est_bw = get_estimated_bandwidth()
    if MASTER_VARIANT == "adaptive" and est_bw > 0:
        suitable = [v for v in pool if v["bw"] <= est_bw * 0.85]
        if suitable:
            chosen = max(suitable, key=lambda v: v["bw"])
        else:
            chosen = min(pool, key=lambda v: v["bw"])
        _log("debug", "Qualidade adaptada: bw=%.1f Mbps, bitrate=%d bps",
             est_bw / 1e6, chosen["bw"])
    elif MASTER_VARIANT == "lowest":
        chosen = min(pool, key=lambda v: v["bw"])
    else:
        chosen = max(pool, key=lambda v: v["bw"])

    groups = set()
    for key in ("AUDIO", "SUBTITLES", "VIDEO"):
        val = _attr(chosen["line"], key)
        if val:
            groups.add(val)

    drop = set()
    for v in variants:
        if v is not chosen:
            drop.add(v["inf"])
            drop.add(v["uri"])

    out = []
    for idx, raw in enumerate(lines):
        if idx in drop:
            continue
        s = raw.strip()
        up = s.upper()
        if up.startswith("#EXT-X-I-FRAME-STREAM-INF"):
            continue
        if up.startswith("#EXT-X-MEDIA:"):
            mtype = (_attr(s, "TYPE") or "").upper()
            gid = _attr(s, "GROUP-ID")
            if mtype != "CLOSED-CAPTIONS" and gid not in groups:
                continue
        out.append(raw)
    return "\n".join(out) + "\n", uri_of(chosen)


# ---------------- CABEÇALHOS E REQUISIÇÕES ----------------

def origin_of(url):
    p = urllib.parse.urlparse(url)
    return "{}://{}".format(p.scheme, p.netloc.rsplit("@", 1)[-1])


def make_headers(url, parent_url=None, client_range=None, level=0,
                 identity=True):
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "*/*",
    }
    if client_range:
        headers["Range"] = client_range
    if level >= 1:
        return headers
    if identity:
        headers["Accept-Encoding"] = "identity"
    origin = origin_of(url)
    referer = parent_url if parent_url else origin + "/"
    headers["Connection"] = "keep-alive"
    headers["Host"] = urllib.parse.urlparse(url).netloc.rsplit("@", 1)[-1]
    headers["Origin"] = origin
    headers["Referer"] = referer
    return headers


def _timeouts(deadline, streaming=False):
    read_default = READ_TIMEOUT_STREAM if streaming else READ_TIMEOUT
    if deadline is None:
        return (CONNECT_TIMEOUT, read_default)
    left = deadline - time.time()
    return (
        min(CONNECT_TIMEOUT, max(left, MIN_CONNECT_TIMEOUT)),
        min(read_default, max(left, MIN_READ_TIMEOUT)),
    )


def manual_request(url, parent_url=None, stream=False, client_range=None,
                   deadline=None, streaming=False, header_level=0,
                   header_identity=True):
    current = url
    for _hop in range(MAX_REDIRECTS + 1):
        p = urllib.parse.urlparse(current)
        if p.scheme not in ("http", "https") or not p.hostname:
            raise ValueError("URL HTTP/HTTPS inválida")
        headers = make_headers(current, parent_url, client_range,
                               level=header_level, identity=header_identity)
        response = SESSION.get(
            current, headers=headers, allow_redirects=False,
            timeout=_timeouts(deadline, streaming), stream=stream,
        )
        if response.status_code in REDIRECT_CODES:
            location = response.headers.get("Location")
            status = response.status_code
            response.close()
            if not location:
                raise RuntimeError("HTTP %s sem Location" % status)
            current = urllib.parse.urljoin(current, location)
            continue
        return response
    raise requests.TooManyRedirects("Limite de redirecionamentos excedido")


def fetch_with_retry(url, parent_url=None, stream=False, client_range=None,
                     deadline=None, kind="recurso", streaming=False,
                     retries=None, backoff_base=None, header_identity=True):
    if retries is None:
        retries = RETRIES
    if backoff_base is None:
        backoff_base = RETRY_BASE

    gate = _gate_for(url)
    last_error = None
    attempts = 0
    for attempt in range(retries):
        if attempt and deadline is not None and time.time() >= deadline:
            break
        response = None
        attempts += 1
        try:
            with gate.sem:
                response = manual_request(
                    url, parent_url=parent_url, stream=stream,
                    client_range=client_range, deadline=deadline,
                    streaming=streaming,
                    header_level=min(attempt, 1),
                    header_identity=header_identity,
                )
            status = response.status_code
            if status < 400:
                return response
            response.close()
            response = None
            last_error = RuntimeError("HTTP %s" % status)
            if status in AUTH_FAIL_CODES:
                break
            if status not in RETRY_CODES:
                break
        except (requests.RequestException, OSError) as exc:
            last_error = exc
            if response is not None:
                response.close()
        if attempt + 1 >= retries:
            break
        delay = min(MAX_RETRY_DELAY, backoff_base * (2 ** attempt)) + random.uniform(0, 0.1)
        if deadline is not None:
            delay = min(delay, deadline - time.time())
            if delay <= 0:
                break
        time.sleep(delay)
    raise RuntimeError(
        _fmt("Falha após %s tentativa(s) (%s): %s", attempts, kind, last_error)
    )


# ---------------- URLs DO PROXY ----------------

def _b64e(text):
    return base64.urlsafe_b64encode(_to_bytes(text)).rstrip(b"=").decode("ascii")


def _b64d(token):
    raw = _to_bytes(token)
    raw += b"=" * (-len(raw) % 4)
    return base64.urlsafe_b64decode(raw).decode("utf-8", "replace")


def _is_http(url):
    p = urllib.parse.urlparse(url)
    return p.scheme in ("http", "https") and bool(p.netloc)


def _proxy_ext(kind, upstream_url):
    if kind == "manifest":
        return "m3u8"
    if kind == "key":
        return "key"
    name = urllib.parse.urlparse(upstream_url).path.rsplit("/", 1)[-1]
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    return ext if ext in _SEGMENT_EXTS else "ts"


def local_proxy_url(kind, upstream_url, base, parent=None):
    base_url = "{}/{}/{}.{}".format(
        base.rstrip("/"), kind, _b64e(upstream_url), _proxy_ext(kind, upstream_url)
    )
    if parent:
        base_url += "?parent=" + urllib.parse.quote(_b64e(parent), safe="")
    return base_url


def _rewrite_uri_attr(match, kind, final_url, base, manifest_url):
    uri = match.group(3)
    absolute = urllib.parse.urljoin(final_url, uri)
    if not _is_http(absolute):
        return match.group(0)
    return (
        match.group(1) + match.group(2)
        + local_proxy_url(kind, absolute, base, parent=manifest_url)
        + match.group(2)
    )


def rewrite_manifest(content, final_url, base, manifest_url):
    output = []
    expect = None
    for original_line in content.splitlines():
        line = original_line.strip()
        if not line:
            output.append(original_line)
            continue
        if line.startswith("#"):
            tag = line.split(":", 1)[0].upper()
            if tag == "#EXT-X-STREAM-INF":
                expect = "manifest"
            elif tag == "#EXTINF":
                expect = "segment"
            if tag in _KEY_TAGS:
                kind = "key"
            elif tag in _MANIFEST_TAGS:
                kind = "manifest"
            else:
                kind = "segment"
            line = _URI_ATTR_RE.sub(
                lambda m: _rewrite_uri_attr(m, kind, final_url, base, manifest_url),
                line,
            )
            output.append(line)
            continue
        absolute = urllib.parse.urljoin(final_url, line)
        if _is_http(absolute):
            if expect:
                kind = expect
            else:
                path = urllib.parse.urlparse(absolute).path.lower()
                kind = "manifest" if path.endswith(".m3u8") else "segment"
            output.append(local_proxy_url(kind, absolute, base, parent=manifest_url))
        else:
            output.append(original_line)
        expect = None
    return "\n".join(output) + "\n"


# ---------------- LEITURA DO CORPO ----------------

def _peek(chunks, size=64):
    buf = b""
    for chunk in chunks:
        if chunk:
            buf += chunk
            if len(buf) >= size:
                break
    return buf


def _is_hls_text(head):
    return head.lstrip(b"\xef\xbb\xbf \t\r\n").startswith(b"#EXTM3U")


def _read_body(head, chunks, limit, deadline=None):
    parts = [head]
    total = len(head)
    for chunk in chunks:
        if not chunk:
            continue
        total += len(chunk)
        if total > limit:
            raise ValueError("resposta maior que %d bytes" % limit)
        if deadline is not None and time.time() > deadline:
            raise RuntimeError("tempo esgotado lendo a resposta da origem")
        parts.append(chunk)
    return b"".join(parts)


# ---------------- RENOVAÇÃO DE TOKEN ----------------

def _segments_map_for(manifest_text, base_url):
    result = {}
    for raw in manifest_text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            if line.startswith(_KEY_TAGS[0]) or line.startswith(_KEY_TAGS[1]):
                for m in _URI_ATTR_RE.finditer(line):
                    uri = m.group(3)
                    absu = urllib.parse.urljoin(base_url, uri)
                    if _is_http(absu):
                        name = urllib.parse.urlsplit(absu).path.rsplit("/", 1)[-1]
                        result[name] = absu
            continue
        absolute = urllib.parse.urljoin(base_url, line)
        if _is_http(absolute):
            name = urllib.parse.urlsplit(absolute).path.rsplit("/", 1)[-1]
            result[name] = absolute
    return result


def _refetch_manifest_url(url):
    deadline = time.time() + FETCH_BUDGET
    upstream = fetch_with_retry(
        url, stream=True, deadline=deadline, kind="manifest-refresh",
        header_identity=False,
    )
    try:
        final_url = upstream.url
        data = _read_body(
            b"", upstream.iter_content(chunk_size=CHUNK_SIZE),
            MAX_MANIFEST_BYTES, time.time() + READ_TIMEOUT,
        )
        return final_url, data.decode("utf-8", "replace")
    finally:
        upstream.close()


def _refresh_token_for(segment_url, manifest_url_hint):
    if not manifest_url_hint:
        return None
    name = urllib.parse.urlsplit(segment_url).path.rsplit("/", 1)[-1]
    if not name:
        return None
    try:
        final_url, text = _refetch_manifest_url(manifest_url_hint)
    except Exception:
        return None

    stack = [(final_url, text, 0)]
    seen = set()
    while stack:
        base_u, body, depth = stack.pop(0)
        if base_u in seen or depth > 2:
            continue
        seen.add(base_u)
        entries = _segments_map_for(body, base_u)
        if name in entries:
            _bump("token_refresh")
            return entries[name]
        if depth < 2:
            for m in _URI_ATTR_RE.finditer(body):
                uri = m.group(3)
                absu = urllib.parse.urljoin(base_u, uri)
                if _is_http(absu) and absu.lower().split("?")[0].endswith(".m3u8"):
                    try:
                        _, child = _refetch_manifest_url(absu)
                        stack.append((absu, child, depth + 1))
                    except Exception:
                        continue
    return None


# ---------------- SISTEMA REF (Refresh/Reconnect/Fetch) ----------------
#
# Quando um recurso (segmento/chave/manifesto) falha, o REF:
#   1. esquece o edge “grudado” (sticky) do canal;
#   2. reconecta à URL DE ENTRADA do canal e re-busca o manifesto atual
#      (os tokens/URLs renovados pela origem entram no mapa);
#   3. localiza o recurso falhado pelo nome no mapa fresco e serve com a
#      URL nova — sem o player perceber e sem a reprodução parar.

_REF_STATE = {}          # entry_url -> {"t", "map", "map_t"}
_REF_LOCK = threading.Lock()
_REF_LOCKS = {}


def _ref_lock(entry_url):
    with _REF_LOCK:
        lock = _REF_LOCKS.get(entry_url)
        if lock is None:
            lock = threading.Lock()
            _REF_LOCKS[entry_url] = lock
            if len(_REF_LOCKS) > 128:
                for k, v in list(_REF_LOCKS.items()):
                    if not v.locked() and k != entry_url:
                        _REF_LOCKS.pop(k, None)
        return lock


def _ref_state_for(entry_url):
    with _REF_LOCK:
        st = _REF_STATE.get(entry_url)
        if st is None:
            st = {"t": 0.0, "map": None, "map_t": 0.0}
            _REF_STATE[entry_url] = st
            if len(_REF_STATE) > 64:
                for k in sorted(_REF_STATE,
                                key=lambda x: _REF_STATE[x]["map_t"])[:16]:
                    _REF_STATE.pop(k, None)
        return st


def _ref_map_cached(entry_url):
    now = time.time()
    with _REF_LOCK:
        st = _REF_STATE.get(entry_url)
    if not st or not st.get("map"):
        return None
    if now - st.get("map_t", 0.0) > REF_MAP_TTL:
        return None
    return st["map"]


def _ref_collect_segments(final_url, text, depth=0, seen=None, budget=None):
    """Varre o manifesto (e filhos .m3u8, inclusive variantes em linhas
    próprias) e devolve {nome: url} de segmentos, chaves e mapas."""
    if seen is None:
        seen = set()
    if budget is None:
        budget = time.time() + 6.0
    if final_url in seen or depth > 2 or time.time() > budget:
        return {}
    seen.add(final_url)
    result = dict(_segments_map_for(text, final_url))

    children = []
    for m in _URI_ATTR_RE.finditer(text):
        uri = m.group(3)
        absu = urllib.parse.urljoin(final_url, uri)
        if _is_http(absu) and absu.lower().split("?")[0].endswith(".m3u8"):
            children.append(absu)
    for raw in text.splitlines():          # variantes em linhas próprias
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        absu = urllib.parse.urljoin(final_url, line)
        if _is_http(absu) and absu.lower().split("?")[0].endswith(".m3u8"):
            children.append(absu)

    if depth < 2:
        for absu in children:
            if absu in seen or time.time() > budget:
                continue
            try:
                child_final, child_text = _refetch_manifest_url(absu)
            except Exception:
                continue
            result.update(_ref_collect_segments(child_final, child_text,
                                                depth + 1, seen, budget))
    return result


def ref_reconnect(entry_url, reason=""):
    # Reconecta à URL DE ENTRADA do canal; devolve o mapa fresco
    # {nome: url} (tokens/URLs renovados pela origem), ou None se a origem
    # também não atender. Serializado por canal e limitado a uma reconexão
    # a cada REF_MIN_INTERVAL segundos.
    if not REF_ENABLED or not _is_http(entry_url or ""):
        return None
    lock = _ref_lock(entry_url)
    with lock:
        now = time.time()
        st = _ref_state_for(entry_url)
        if now - st["t"] < REF_MIN_INTERVAL:
            _bump("ref_skip_recent")
            m = st.get("map")
            if m and now - st.get("map_t", 0.0) <= REF_MAP_TTL:
                return m
            return None
        st["t"] = now

    _bump("ref_reconnect")
    _log("info", "REF: reconectando à URL de entrada do canal (%s) — %s",
         _short(entry_url), reason or "recurso falhou")
    _sticky_forget(entry_url)
    try:
        final_url, text = _refetch_manifest_url(entry_url)
    except Exception as exc:
        _log("debug", "REF: reconexão falhou: %s", exc)
        return None
    fresh = _ref_collect_segments(final_url, text)
    with _REF_LOCK:
        st["map"] = fresh
        st["map_t"] = time.time()

    # acorda o live virtual: volta a resolver pela URL de entrada
    with _LIVES_LOCK:
        live = _LIVES.get(entry_url)
    if live is not None:
        live.node_url = None
        live.resolved_at = 0.0

    # aquece o cache com os segmentos mais recentes do mapa fresco
    if fresh:
        recent = list(fresh.values())[-PREFETCH_AHEAD:]
        for u in recent:
            if _is_http(u):
                _PREFETCH.submit(u, entry_url)
    return fresh


def ref_lookup_segment(entry_url, segment_url):
    # Procura a URL atual do segmento falhado: usa o mapa fresco do canal e,
    # se necessário, dispara uma reconexão à URL de entrada.
    if not entry_url:
        return None
    name = urllib.parse.urlsplit(segment_url).path.rsplit("/", 1)[-1]
    if not name:
        return None
    cached = _ref_map_cached(entry_url)
    if cached is not None:
        new = cached.get(name)
        if new:
            return new
    fresh = ref_reconnect(
        entry_url, "segmento falhou: %s" % _short(segment_url))
    if not fresh:
        return None
    new = fresh.get(name)
    if new:
        _bump("ref_map_hit")
    return new


# ---------------- CARGA DE MANIFESTO ----------------

def _load_manifest(url):
    prev = _manifest_cache_get(url, allow_stale=True)
    entry = None

    for attempt in range(SEQ_RETRIES + 1):
        deadline = time.time() + FETCH_BUDGET
        target_url = _sticky_target(url)
        via_original = target_url == url
        if via_original:
            upstream = fetch_with_retry(
                url, stream=True, deadline=deadline, kind="manifest",
                header_identity=False,
            )
        else:
            try:
                upstream = fetch_with_retry(
                    target_url, stream=True, deadline=deadline,
                    kind="manifest-edge", retries=1,
                    header_identity=False,
                )
            except Exception:
                _sticky_forget(url)
                via_original = True
                deadline = time.time() + FETCH_BUDGET
                upstream = fetch_with_retry(
                    url, stream=True, deadline=deadline, kind="manifest",
                    header_identity=False,
                )
        keep = False
        try:
            final_url = upstream.url
            ctype = (upstream.headers.get("Content-Type") or "").lower()
            chunks = upstream.iter_content(chunk_size=CHUNK_SIZE)
            head = _peek(chunks)

            if _is_hls_text(head):
                data = _read_body(head, chunks, MAX_MANIFEST_BYTES,
                                  time.time() + READ_TIMEOUT)
                data = data.lstrip(b"\xef\xbb\xbf \t\r\n")
                text = data.decode("utf-8", "replace")
            elif ctype.startswith("text/") or head.lstrip()[:1] in (b"<", b"{"):
                raise ValueError("a origem não devolveu um manifesto HLS")
            else:
                keep = True
                return ("relay", upstream, head, chunks)
        finally:
            if not keep:
                upstream.close()

        meta = _parse_manifest_meta(text, final_url)
        if meta["is_live"] and not meta["is_master"]:
            _sticky_remember(url, final_url, via_original)
            if meta["complex"] or not LIVE_VIRTUAL:
                text, meta = _normalize_sequence(url, text, meta)

        if (prev is not None and meta["is_live"] and not meta["is_master"]
                and not prev.is_master
                and prev.media_sequence is not None
                and meta["seq"] is not None):
            drop = prev.media_sequence - meta["seq"]
            if 0 < drop <= SEQ_BACKWARD_TOLERANCE:
                _bump("seq_rejected")
                if attempt < SEQ_RETRIES:
                    time.sleep(SEQ_RETRY_DELAY)
                    continue
                if (time.time() - prev.expire) <= STALE_MANIFEST_MAX_AGE:
                    prev.expire = time.time() + MANIFEST_CACHE_TTL_MIN
                    return ("manifest", prev)

        variant_url = None
        body_text = text
        if meta["is_master"]:
            body_text, chosen = _collapse_master(text)
            if chosen:
                variant_url = urllib.parse.urljoin(final_url, chosen)
                if not _is_http(variant_url):
                    variant_url = None

        entry = _ManifestEntry(
            _manifest_ttl(meta), final_url, body_text, meta, variant_url,
        )
        break

    if entry is None:
        raise RuntimeError("manifesto indisponível")

    _manifest_cache_put(url, entry)
    _prefetch_from_entry(entry, url)
    return ("manifest", entry)


def _warm_manifest(url):
    try:
        gate = _gate_for(url)
        lock = gate.lock_for(url)
        with lock:
            if _manifest_cache_get(url) is not None:
                return
            res = _load_manifest(url)
        if res[0] == "relay":
            try:
                res[1].close()
            except Exception:
                pass
    except Exception:
        pass


def _warm_manifest_async(url):
    t = threading.Thread(target=_warm_manifest, args=(url,), daemon=True)
    t.start()


# ---------------- READ-AHEAD DE SEGMENTOS ----------------

class _Prefetcher:
    def __init__(self):
        self._q = queue.Queue(maxsize=32)
        self._lock = threading.Lock()
        self._jobs = {}
        self._done = collections.OrderedDict()
        self._thread = None

    def _ensure(self):
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(
                target=self._run, name="hlsproxy-prefetch", daemon=True,
            )
            self._thread.start()

    def submit(self, url, parent=None):
        if PREFETCH_AHEAD <= 0 or SEGMENT_CACHE_BYTES <= 0:
            return False
        if _SEGMENT_CACHE.get(url) is not None:
            return False
        now = time.time()
        with self._lock:
            if url in self._jobs:
                return False
            ts = self._done.get(url)
            if ts is not None and now - ts < PREFETCH_RESUBMIT_TTL:
                return False
            job = {"ev": threading.Event(), "state": "queued", "t": now}
            self._jobs[url] = job
            self._done[url] = now
            while len(self._done) > 512:
                self._done.popitem(last=False)
        try:
            self._q.put_nowait((url, parent, job))
        except queue.Full:
            with self._lock:
                if self._jobs.get(url) is job:
                    self._jobs.pop(url, None)
                self._done.pop(url, None)
            job["ev"].set()
            return False
        self._ensure()
        return True

    def wait(self, url, timeout):
        with self._lock:
            job = self._jobs.get(url)
            if job is None:
                return False
            if job["state"] == "queued":
                job["state"] = "cancelled"
                return False
        return job["ev"].wait(timeout)

    def clear(self):
        with self._lock:
            self._done.clear()
            for job in self._jobs.values():
                if job["state"] == "queued":
                    job["state"] = "cancelled"

    def _run(self):
        while True:
            url, parent, job = self._q.get()
            run = False
            with self._lock:
                expired = (time.time() - job["t"]) > PREFETCH_JOB_MAX_AGE
                if job["state"] != "cancelled" and not expired:
                    job["state"] = "running"
                    run = True
            try:
                if run:
                    self._fetch(url, parent)
            except Exception:
                _bump("prefetch_fail")
            finally:
                with self._lock:
                    if self._jobs.get(url) is job:
                        self._jobs.pop(url, None)
                job["ev"].set()

    def _fetch(self, url, parent):
        t0 = time.time()
        deadline = t0 + PREFETCH_BUDGET
        upstream = fetch_with_retry(
            url, stream=True, deadline=deadline, kind="read-ahead",
            streaming=True, retries=2,
        )
        size = None
        try:
            if upstream.status_code != 200:
                return
            cl = upstream.headers.get("Content-Length")
            encoded = bool(upstream.headers.get("Content-Encoding"))
            if cl and not encoded:
                try:
                    size = int(cl)
                except (TypeError, ValueError):
                    size = None
            if size is not None and size > SEGMENT_MAX_CACHE:
                return
            parts = []
            total = 0
            for chunk in upstream.iter_content(chunk_size=CHUNK_SIZE):
                if not chunk:
                    continue
                total += len(chunk)
                if total > SEGMENT_MAX_CACHE:
                    return
                if time.time() > deadline:
                    raise RuntimeError("tempo esgotado no read-ahead")
                parts.append(chunk)
        finally:
            upstream.close()

        data = b"".join(parts)
        if not data or (size is not None and len(data) != size):
            _bump("prefetch_fail")
            return

        record_bandwidth(len(data), time.time() - t0)
        _SEGMENT_CACHE.put(url, data)
        if parent:
            seg_name = urllib.parse.urlsplit(url).path.rsplit("/", 1)[-1]
            _LAST_SEGMENT.put(parent, seg_name, data)
        _bump("prefetch_ok")


_PREFETCH = _Prefetcher()


def _prefetch_from_entry(entry, manifest_url, after=None):
    if PREFETCH_AHEAD <= 0 or entry is None:
        return
    if entry.is_master:
        if entry.variant_url:
            _warm_manifest_async(entry.variant_url)
        return
    segs = entry.segments
    if not segs:
        return
    if after is not None:
        idx = entry.seg_index.get(after)
        if idx is None:
            return
        targets = segs[idx + 1: idx + 1 + PREFETCH_AHEAD]
    elif entry.is_live:
        targets = segs[-PREFETCH_AHEAD:]
    else:
        targets = segs[:PREFETCH_AHEAD]
    for target in targets:
        _PREFETCH.submit(target, manifest_url)


def _resume_upstream(url, offset):
    try:
        resp = fetch_with_retry(
            url, stream=True, client_range="bytes=%d-" % offset,
            deadline=time.time() + RESUME_BUDGET, kind="resume",
            streaming=True, retries=2,
        )
    except Exception:
        return None
    if resp.status_code != 206:
        resp.close()
        return None
    return resp


# ---------------- PLAYLIST LIVE VIRTUAL ----------------

def _seg_key(url):
    try:
        return urllib.parse.urlsplit(url).path or url
    except Exception:
        return url


def _host_of(url):
    try:
        return urllib.parse.urlsplit(url).netloc.rsplit("@", 1)[-1].lower()
    except Exception:
        return ""


_LIVES = {}
_LIVE_LAST = {}
_LIVES_LOCK = threading.Lock()


class _LiveStream:
    is_live = True
    is_master = False
    variant_url = None
    complex = False

    def __init__(self, url):
        self.url = url
        self.lock = threading.Lock()
        self.segs = []
        self.next_vseq = 0
        self.disc_seq = 0
        self.target = 6.0
        self.node_host = None
        self.node_url = None
        self.node_ttl = None
        self.resolved_at = 0.0
        self.raw_end = {}
        self.raw_end_t = {}
        self.seen = collections.OrderedDict()
        self.seen_keys = collections.OrderedDict()
        self.banned_hosts = {}
        self.edge_switches = 0
        self.pending_disc = False
        self.last_append = time.time()
        self.last_ok = time.time()
        self.last_access = time.time()
        self.fail_count = 0
        self.stop_ev = threading.Event()
        self.thread = None
        self.last_rendered = None   # fallback quando janela fica vazia

    def touch(self):
        self.last_access = time.time()

    @property
    def segments(self):
        with self.lock:
            return [s["url"] for s in self.segs]

    @property
    def seg_index(self):
        with self.lock:
            return {s["url"]: i for i, s in enumerate(self.segs)}

    def _saved_state(self):
        with _LIVES_LOCK:
            saved = _LIVE_LAST.get(self.url)
        if saved and time.time() - saved["t"] < 3600:
            return saved
        return None

    def _seed_vseq(self, raw):
        saved = self._saved_state()
        if saved:
            return saved["vseq"] + int(
                (time.time() - saved["t"]) / max(self.target, 1.0)
            )
        return raw

    def _restore_state(self):
        saved = self._saved_state()
        if not saved:
            return
        now = time.time()
        for key in (saved.get("keys") or [])[-512:]:
            self.seen_keys[key] = now
        host = saved.get("host")
        if host:
            end = saved.get("raw_end")
            if end is not None:
                self.raw_end[host] = end
                self.raw_end_t[host] = saved.get("raw_t") or now

    def _is_banned(self, host):
        if not host:
            return False
        exp = self.banned_hosts.get(host)
        if exp is None:
            return False
        if exp < time.time():
            self.banned_hosts.pop(host, None)
            return False
        return True

    def ingest(self, final_url, meta):
        host = _host_of(final_url)
        segs = meta["segments"]
        durs = meta["durations"]
        discs = meta["discs"]
        n = len(segs)
        if not n:
            return 0
        raw = meta["seq"] if meta["seq"] is not None else 0
        now = time.time()
        keys = [_seg_key(u) for u in segs]
        key_dedupe = len(set(keys)) == n

        if self.node_host and host and host != self.node_host:
            same_host = sum(1 for u in segs if _host_of(u) == self.node_host)
            other_host = n - same_host
            if other_host >= max(1, (n + 1) // 2):
                _bump("edge_rejected")
                _log("debug", "edge rejeitado %s (node=%s, %d/%d)",
                     host, self.node_host, other_host, n)
                return 0
            if self._is_banned(host):
                _bump("edge_rejected")
                return 0

        with self.lock:
            if meta["target"]:
                self.target = meta["target"]
            avg = max((sum(durs) / len(durs)) if durs else self.target, 1.0)
            raw_end = self.raw_end.get(host)
            raw_fresh = (
                raw_end is not None
                and now - self.raw_end_t.get(host, 0.0) <= LIVE_HOST_MEMO
            )
            start_idx = 0
            mark_disc = False
            switched = False

            if self.node_host is None:
                self.node_host = host
                start_idx = max(0, n - LIVE_KEEP_SEGMENTS)
                self.next_vseq = self._seed_vseq(raw)
            elif host and host != self.node_host:
                if self.edge_switches < LIVE_MAX_EDGE_SWITCHES:
                    self.edge_switches += 1
                    switched = True
                    mark_disc = True
                    self.pending_disc = True
                    self.node_host = host
                    start_idx = max(0, n - LIVE_KEEP_SEGMENTS)
                else:
                    _bump("loop_guard")
                    return 0
            elif raw_fresh and raw_end - (raw + n) <= LIVE_RESTART_TOLERANCE:
                if raw_end > raw + n:
                    _bump("loop_guard")
                    return 0
                start_idx = max(0, min(raw_end - raw, n))
                if raw > raw_end:
                    mark_disc = True
            else:
                start_idx = None
                if key_dedupe:
                    last_known = -1
                    for i, k in enumerate(keys):
                        if k in self.seen_keys:
                            last_known = i
                    if last_known >= 0:
                        start_idx = last_known + 1
                if start_idx is None:
                    elapsed = now - self.last_append
                    k_est = min(n, max(0, int(elapsed / avg)))
                    start_idx = n - k_est
                if raw < (raw_end or 0):
                    mark_disc = True

            added = 0
            for i in range(start_idx, n):
                u = segs[i]
                if u in self.seen:
                    _bump("dup_skipped")
                    continue
                if key_dedupe and keys[i] in self.seen_keys:
                    _bump("dup_skipped")
                    continue
                disc = bool(discs[i] or mark_disc or self.pending_disc)
                mark_disc = False
                self.pending_disc = False
                self.segs.append({
                    "vseq": self.next_vseq, "url": u,
                    "dur": durs[i], "disc": disc,
                })
                self.next_vseq += 1
                self.seen[u] = now
                if key_dedupe:
                    self.seen_keys[keys[i]] = now
                added += 1

            self.raw_end[host] = raw + n
            self.raw_end_t[host] = now
            while len(self.seen) > 1024:
                self.seen.popitem(last=False)
            while len(self.seen_keys) > 1024:
                self.seen_keys.popitem(last=False)
            while len(self.segs) > LIVE_KEEP_SEGMENTS:
                old = self.segs.pop(0)
                if old["disc"]:
                    self.disc_seq += 1
            if added:
                self.last_append = now
            self.last_ok = now

        if switched:
            _bump("host_switch")
            _log("info", "troca de edge: %s", host)
        return added

    def render(self, base):
        with self.lock:
            segs = list(self.segs)
            disc_seq = self.disc_seq
            target = self.target
            last_rendered = self.last_rendered
        if not segs:
            if last_rendered is not None:
                _bump("render_fallback")
                return last_rendered
            return None
        longest = max([target] + [sg["dur"] for sg in segs])
        lines = [
            "#EXTM3U",
            "#EXT-X-VERSION:3",
            "#EXT-X-TARGETDURATION:%d" % int(longest + 0.999),
            "#EXT-X-MEDIA-SEQUENCE:%d" % segs[0]["vseq"],
        ]
        if disc_seq:
            lines.append("#EXT-X-DISCONTINUITY-SEQUENCE:%d" % disc_seq)
        for sg in segs:
            if sg["disc"]:
                lines.append("#EXT-X-DISCONTINUITY")
            lines.append("#EXTINF:%.3f," % sg["dur"])
            lines.append(local_proxy_url("segment", sg["url"], base, parent=self.url))
        body = "\n".join(lines) + "\n"
        with self.lock:
            self.last_rendered = body
        return body


def _auth_like(exc):
    text = str(exc)
    return "HTTP 406" in text or "HTTP 401" in text or "HTTP 403" in text


def _live_fetch(live):
    now = time.time()
    candidates = []
    node = live.node_url
    use_node = bool(node and node != live.url)
    if use_node:
        age = now - live.resolved_at
        if age >= LIVE_RESOLVE_INTERVAL:
            use_node = False
        elif live.node_ttl is not None and age >= live.node_ttl * 0.8:
            use_node = False
    if use_node:
        candidates.append((node, LIVE_NODE_RETRIES))
    candidates.append((live.url, None))

    last_exc = None
    for target, retries in candidates:
        try:
            deadline = time.time() + LIVE_FETCH_BUDGET
            upstream = fetch_with_retry(
                target, stream=True, deadline=deadline, kind="live-manifest",
                retries=retries, header_identity=False,
            )
            try:
                final_url = upstream.url
                data = _read_body(
                    b"", upstream.iter_content(chunk_size=CHUNK_SIZE),
                    MAX_MANIFEST_BYTES, time.time() + READ_TIMEOUT,
                )
            finally:
                upstream.close()
            text = data.lstrip(b"\xef\xbb\xbf \t\r\n").decode("utf-8", "replace")
            if not text.startswith("#EXTM3U"):
                raise ValueError("resposta não é HLS")
            if target == live.url:
                live.node_url = final_url if final_url != live.url else None
                live.resolved_at = time.time()
            return final_url, text
        except Exception as exc:
            last_exc = exc
            if target != live.url:
                live.node_url = None
                if _auth_like(exc):
                    ttl = min(max(time.time() - live.resolved_at, 2.0), 120.0)
                    if live.node_ttl is None or ttl < live.node_ttl:
                        live.node_ttl = ttl
    raise last_exc


def _live_refresh(live):
    final_url, text = _live_fetch(live)
    meta = _parse_manifest_meta(text, final_url)
    if meta["is_master"] or not meta["is_live"] or meta["complex"]:
        raise RuntimeError("manifesto deixou de ser um live simples")
    # NÃO aplica _normalize_sequence aqui — o _LiveStream controla o seq
    added = live.ingest(final_url, meta)
    live.fail_count = 0
    if added:
        _prefetch_from_entry(live, live.url)


def _live_loop(live):
    try:
        while not live.stop_ev.is_set():
            interval = min(max(live.target / 2.0, LIVE_POLL_MIN), LIVE_POLL_MAX)
            if live.stop_ev.wait(interval):
                break
            if time.time() - live.last_access > LIVE_IDLE_TIMEOUT:
                break
            try:
                _live_refresh(live)
            except Exception:
                live.fail_count += 1
                if live.fail_count == 2:
                    live.node_url = None
                    _sticky_forget(live.url)
                    _log("warning", "live: edge falhando, voltando pela URL de entrada")
                elif live.fail_count >= 3 and live.fail_count % 3 == 0:
                    ref_reconnect(live.url, "live-refresh")
    finally:
        with live.lock:
            stopped = live.stop_ev.is_set()
            vseq = live.next_vseq
            keys = list(live.seen_keys)[-32:]
            host = live.node_host
            raw_end = live.raw_end.get(host) if host else None
            raw_t = live.raw_end_t.get(host) if host else None
        with _LIVES_LOCK:
            if _LIVES.get(live.url) is live:
                del _LIVES[live.url]
                if not stopped:
                    _LIVE_LAST[live.url] = {
                        "vseq": vseq, "t": time.time(), "keys": keys,
                        "host": host, "raw_end": raw_end, "raw_t": raw_t,
                    }


def _live_start(url, entry):
    with _LIVES_LOCK:
        live = _LIVES.get(url)
    if live is not None:
        return live
    live = _LiveStream(url)
    live._restore_state()
    live.node_url = entry.final_url if entry.final_url != url else None
    live.resolved_at = time.time()
    live.ingest(entry.final_url, _parse_manifest_meta(entry.body, entry.final_url))
    with _LIVES_LOCK:
        existing = _LIVES.get(url)
        if existing is not None:
            return existing
        _LIVES[url] = live
    t = threading.Thread(target=_live_loop, args=(live,),
                         name="hlsproxy-live", daemon=True)
    live.thread = t
    t.start()
    return live


# ---------------- SERVIDOR HTTP LOCAL ----------------

class HLSProxyHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "HLSProxy/" + __version__
    sys_version = ""
    timeout = CLIENT_TIMEOUT

    def setup(self):
        http.server.BaseHTTPRequestHandler.setup(self)
        self._started = False
        self._keep_alive = True
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        try:
            self.connection.setsockopt(
                socket.SOL_SOCKET, socket.SO_SNDBUF, 512 * 1024
            )
        except Exception:
            pass

    def log_message(self, format, *args):
        if DEBUG:
            _log("debug", "%s %s", self.client_address[0], format % args)

    def do_GET(self):
        self._handle(False)

    def do_HEAD(self):
        self._handle(True)

    def _handle(self, head_only):
        self._started = False
        self._keep_alive = self._want_keep_alive()
        try:
            self._route(head_only)
        except CLIENT_GONE:
            self._keep_alive = False
        except Exception:
            if not self._started:
                try:
                    self._error(500, "Erro interno", head_only)
                except Exception:
                    pass
            self._keep_alive = False
        if not self._keep_alive:
            self.close_connection = True

    def _want_keep_alive(self):
        conn = (self.headers.get("Connection") or "").lower()
        return "close" not in conn

    def _route(self, head_only):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path in ("/health", "/ping"):
            return self._reply(200, b"OK", "text/plain", head_only)

        kind, url, parent = self._parse_target(parsed)
        if not kind:
            return self._error(400, USAGE, head_only)

        _bump(kind)

        if kind == "manifest":
            self._serve_manifest(url, head_only, parent)
        elif kind == "key":
            self._serve_key(url, head_only, parent)
        else:
            self._serve_segment(url, head_only, parent)

    def _parse_target(self, parsed):
        parent = None
        try:
            match = _PATH_RE.match(parsed.path)
            if match:
                kind, url = match.group(1), _b64d(match.group(2))
                params = dict(urllib.parse.parse_qsl(parsed.query))
                parent = params.get("parent") or None
            else:
                params = dict(urllib.parse.parse_qsl(parsed.query))
                kind = (params.get("type") or "manifest").lower()
                url = (params.get("url") or "").strip()
                parent = params.get("parent") or None
            if parent:
                try:
                    parent = _b64d(parent)
                except Exception:
                    parent = None
        except Exception:
            return None, None, None

        if kind not in _KINDS:
            return None, None, None

        p = urllib.parse.urlparse(url)
        if p.scheme not in ("http", "https") or not p.hostname:
            return None, None, None

        return kind, url, parent

    def _base_url(self):
        host = self.headers.get("Host") or ""
        if not _HOST_RE.match(host):
            host = "%s:%d" % (LOCAL_HOST, self.server.server_port)
        return "http://" + host

    def _begin(self, status, headers, content_length=None):
        self._started = True
        self.send_response(status)
        for name, value in headers:
            self.send_header(name, _to_text(value))
        if content_length is not None:
            self.send_header("Content-Length", str(content_length))
        if not self._keep_alive:
            self.send_header("Connection", "close")
        self.end_headers()

    def _reply(self, status, body, ctype, head_only=False, extra=None):
        body = _to_bytes(body)
        headers = [("Content-Type", ctype)]
        if extra:
            headers.extend(extra)
        self._begin(status, headers, content_length=len(body))
        if body and not head_only:
            self.wfile.write(body)

    def _error(self, status, text, head_only=False):
        _bump("errors")
        self._reply(
            status, text, "text/plain; charset=utf-8", head_only,
            [("Cache-Control", "no-store")],
        )

    def _relay(self, upstream, default_ctype, head_only, prefix=b"", chunks=None,
               resume_url=None):
        sent = 0
        resumes = 0
        t0 = time.time()
        try:
            up = upstream.headers
            content_length = None
            if up.get("Content-Length") and not up.get("Content-Encoding"):
                try:
                    content_length = int(up.get("Content-Length"))
                except (TypeError, ValueError):
                    content_length = None
            if content_length is None:
                self._keep_alive = False
            headers = [
                ("Content-Type", up.get("Content-Type") or default_ctype),
                ("Cache-Control", "no-store"),
            ]
            for name in ("Content-Range", "Accept-Ranges"):
                if up.get(name):
                    headers.append((name, up.get(name)))
            self._begin(upstream.status_code, headers, content_length=content_length)
            if head_only:
                return 0

            if prefix:
                self.wfile.write(prefix)
                sent += len(prefix)

            if chunks is None:
                chunks = upstream.iter_content(chunk_size=CHUNK_SIZE)

            last_activity = time.time()
            while True:
                if content_length is not None and sent >= content_length:
                    break
                chunk = None
                broken = False
                if time.time() - last_activity > STALL_TIMEOUT:
                    broken = True
                else:
                    try:
                        chunk = next(chunks)
                    except StopIteration:
                        if content_length is not None and sent < content_length:
                            broken = True
                        else:
                            break
                    except Exception:
                        broken = True

                if broken:
                    if (resume_url and content_length is not None
                            and resumes < RESUME_ATTEMPTS):
                        resumes += 1
                        new_up = _resume_upstream(resume_url, sent)
                        if new_up is not None:
                            try:
                                upstream.close()
                            except Exception:
                                pass
                            upstream = new_up
                            chunks = upstream.iter_content(chunk_size=CHUNK_SIZE)
                            last_activity = time.time()
                            continue
                    break

                if chunk:
                    if content_length is not None and sent + len(chunk) > content_length:
                        chunk = chunk[:content_length - sent]
                    self.wfile.write(chunk)
                    sent += len(chunk)
                    last_activity = time.time()

            if content_length is not None and sent < content_length:
                self._keep_alive = False
        finally:
            try:
                upstream.close()
            except Exception:
                pass

        if sent > 0:
            record_bandwidth(sent, time.time() - t0)
        return sent

    def _send_manifest(self, entry, url, head_only):
        body = _to_bytes(
            rewrite_manifest(entry.body, entry.final_url, self._base_url(), url)
        )
        return self._reply(
            200, body, "application/vnd.apple.mpegurl", head_only,
            [("Cache-Control", "no-store")],
        )

    def _send_live(self, live, head_only):
        live.touch()
        body = live.render(self._base_url())
        if body is None:
            return False
        self._reply(
            200, _to_bytes(body), "application/vnd.apple.mpegurl", head_only,
            [("Cache-Control", "no-store")],
        )
        return True

    def _serve_manifest(self, url, head_only, parent=None):
        t0 = time.time()
        live = _LIVES.get(url) if LIVE_VIRTUAL else None
        if live is not None and self._send_live(live, head_only):
            return

        gate = _gate_for(url)
        lock = gate.lock_for(url)
        relay = None
        entry = None
        live = None

        with lock:
            live = _LIVES.get(url) if LIVE_VIRTUAL else None
            if live is None:
                entry = _manifest_cache_get(url)
                if entry is not None:
                    _bump("cache_hit")
                else:
                    res = None
                    try:
                        res = _load_manifest(url)
                    except Exception:
                        res = None
                    if res is None and REF_ENABLED:
                        # REF: reconecta à URL de entrada antes de desistir
                        ref_deadline = t0 + REF_TOTAL_BUDGET
                        for _cycle in range(REF_MAX_RECONNECTS):
                            if time.time() > ref_deadline:
                                break
                            ref_reconnect(url, "manifesto indisponível")
                            try:
                                res = _load_manifest(url)
                                break
                            except Exception:
                                res = None
                            time.sleep(REF_RETRY_DELAY)
                    if res is not None and res[0] == "manifest":
                        entry = res[1]
                    elif res is not None:
                        relay = res

        if live is not None:
            if self._send_live(live, head_only):
                return
        if relay is not None:
            _, upstream, head, chunks = relay
            return self._relay(
                upstream, "video/mp2t", head_only, prefix=head, chunks=chunks,
            )

        if entry is not None:
            if (LIVE_VIRTUAL and entry.is_live and not entry.is_master
                    and not entry.complex and entry.segments):
                try:
                    live = _live_start(url, entry)
                    if self._send_live(live, head_only):
                        return
                except Exception:
                    pass
            return self._send_manifest(entry, url, head_only)

        # Último recurso: usa stale se houver. Nunca 502 se já tocamos antes.
        stale = _manifest_cache_get(url, allow_stale=True)
        if stale is not None:
            _bump("stale_manifest")
            return self._send_manifest(stale, url, head_only)

        # Se o live existia mas render() retornou None (janela vazia),
        # mantém o last_rendered em vez de 502.
        if live is not None and live.last_rendered is not None:
            _bump("render_fallback")
            return self._reply(
                200, _to_bytes(live.last_rendered),
                "application/vnd.apple.mpegurl", head_only,
                [("Cache-Control", "no-store")],
            )

        self._error(502, "Manifesto temporariamente indisponível", head_only)

    def _serve_key(self, url, head_only, parent=None):
        cached = _KEY_CACHE.get(url)
        if cached is not None:
            _bump("cache_hit")
            return self._reply(
                200, cached, "application/octet-stream", head_only,
                [("Cache-Control", "no-store")],
            )

        t0 = time.time()
        deadline = time.time() + FETCH_BUDGET

        def _get(target):
            upstream = fetch_with_retry(
                target, stream=True, deadline=deadline, kind="key",
                header_identity=False,
            )
            try:
                body = _read_body(
                    b"", upstream.iter_content(chunk_size=CHUNK_SIZE),
                    MAX_KEY_BYTES, time.time() + READ_TIMEOUT,
                )
                return body, upstream.headers.get("Content-Type") or "application/octet-stream"
            finally:
                upstream.close()

        data = None
        ctype = "application/octet-stream"
        try:
            data, ctype = _get(url)
        except Exception:
            data = None

        if data is None and parent:
            new_url = _refresh_token_for(url, parent)
            if new_url and new_url != url:
                try:
                    deadline = time.time() + FETCH_BUDGET
                    data, ctype = _get(new_url)
                except Exception:
                    data = None

        if data is None and parent and REF_ENABLED:
            for _cycle in range(2):
                if time.time() - t0 > REF_TOTAL_BUDGET:
                    break
                new_url = ref_lookup_segment(parent, url)
                if new_url and new_url != url:
                    try:
                        deadline = time.time() + FETCH_BUDGET
                        data, ctype = _get(new_url)
                    except Exception:
                        data = None
                if data is not None:
                    break
                time.sleep(REF_RETRY_DELAY)

        if data is None:
            return self._error(502, "Chave temporariamente indisponível", head_only)

        _KEY_CACHE.put(url, data)
        self._reply(200, data, ctype, head_only, [("Cache-Control", "no-store")])

    def _serve_segment(self, url, head_only, parent=None):
        started = time.time()
        ranged = bool(self.headers.get("Range"))
        entry = _LIVES.get(parent) if parent else None
        if entry is None and parent:
            entry = _manifest_cache_get(parent, allow_stale=True)

        if not ranged:
            cached = _SEGMENT_CACHE.get(url)
            if cached is None and _PREFETCH.wait(url, PREFETCH_WAIT):
                cached = _SEGMENT_CACHE.get(url)
            if cached is not None:
                _bump("cache_hit")
                if entry is not None:
                    _prefetch_from_entry(entry, parent, after=url)
                return self._reply(
                    200, cached, _segment_ctype(url), head_only,
                    [("Cache-Control", "no-store")],
                )
            # prefetch já foi agendado por _live_refresh / _load_manifest.
            # Não duplicar aqui.

        return self._serve_segment_direct(
            url, head_only, parent, entry, ranged, started
        )

    def _client_gone(self):
        # Detecta cliente desconectado durante a espera do REF (sem consumir
        # bytes de um possível próximo pedido pipeline).
        try:
            readable, _, _ = select.select([self.connection], [], [], 0)
            if not readable:
                return False
            data = self.connection.recv(1, socket.MSG_PEEK | socket.MSG_DONTWAIT)
            return data == b""
        except Exception:
            return False

    def _serve_segment_direct(self, url, head_only, parent, entry, ranged, started):
        # Pipeline com REF: abrir -> baixar inteiro (verificado) -> servir.
        # Falha em qualquer etapa cai na recuperação (token + reconexão à
        # URL de entrada) e NADA é enviado ao player antes de estar completo.
        manifest_key = parent or url
        entry_url = parent if _is_http(parent or "") else None
        ctype_default = _segment_ctype(url)

        buffered = REF_ENABLED and not ranged
        deadline = time.time() + (REF_TOTAL_BUDGET if buffered
                                  else SEGMENT_TOTAL_BUDGET)

        def _open(target, retries=None, backoff=None):
            return fetch_with_retry(
                target, stream=True,
                client_range=self.headers.get("Range"),
                deadline=deadline, kind="segment",
                streaming=True,
                retries=retries, backoff_base=backoff,
            )

        target = url
        token_tried = False
        ref_cycles = 0

        while True:
            if self._client_gone():
                self._keep_alive = False
                self.close_connection = True
                return
            if time.time() >= deadline:
                break

            # 1) tenta abrir a origem
            upstream = None
            try:
                upstream = _open(target)
            except Exception:
                upstream = None

            if upstream is not None:
                if not buffered:
                    return self._relay(
                        upstream, ctype_default, head_only,
                        resume_url=None if ranged else target,
                    )

                # 2) baixa o segmento INTEIRO antes de responder:
                #    o player nunca recebe corpo truncado
                try:
                    cl = upstream.headers.get("Content-Length")
                    try:
                        size = int(cl) if cl else None
                    except (TypeError, ValueError):
                        size = None
                    encoded = bool(upstream.headers.get("Content-Encoding"))
                    if (encoded
                            or upstream.status_code not in (200, 206)
                            or (size is not None and size > REF_BUFFER_MAX)):
                        return self._relay(
                            upstream, ctype_default, head_only,
                            resume_url=None if ranged else target,
                        )
                    read_deadline = time.time() + min(
                        12.0, max(4.0, deadline - time.time()))
                    body = _read_body(
                        b"", upstream.iter_content(chunk_size=CHUNK_SIZE),
                        REF_BUFFER_MAX + CHUNK_SIZE, read_deadline,
                    )
                    if size is not None and len(body) != size:
                        raise RuntimeError(
                            "corpo incompleto (%d de %d bytes)"
                            % (len(body), size))
                except ValueError as exc:
                    # corpo maior que o buffer e sem Content-Length:
                    # reabre e repassa em streaming
                    try:
                        upstream.close()
                    except Exception:
                        pass
                    _log("debug", "segmento grande (%s), repassando", exc)
                    try:
                        big = _open(target)
                    except Exception:
                        return self._error(
                            502, "Segmento temporariamente indisponível", head_only)
                    return self._relay(
                        big, ctype_default, head_only,
                        resume_url=None if ranged else target,
                    )
                except Exception:
                    # caiu no meio: nada foi enviado, dá para tentar de novo
                    try:
                        upstream.close()
                    except Exception:
                        pass
                    upstream = None
                else:
                    try:
                        upstream.close()
                    except Exception:
                        pass
                    if target != url:
                        _bump("ref_recovered")
                        _log("info", "REF: segmento recuperado via %s",
                             _short(target))
                    return self._finish_segment(
                        url, target, manifest_key, body, ctype_default,
                        head_only, started, ranged,
                    )

            # 3) falhou: renovação de token (uma vez por URL)
            if not token_tried and entry_url and time.time() < deadline:
                token_tried = True
                new_url = _refresh_token_for(target, entry_url)
                if new_url and new_url != target:
                    target = new_url
                    continue

            # 4) REF: reconecta à URL de entrada do canal
            if ref_cycles < REF_MAX_RECONNECTS and time.time() < deadline:
                ref_cycles += 1
                new_url = ref_lookup_segment(entry_url, target)
                if new_url and new_url != target:
                    target = new_url
                    token_tried = False
                    continue
                left = deadline - time.time()
                if left > 0:
                    time.sleep(min(REF_RETRY_DELAY, left))
                continue

            break

        # 5) últimas defesas antes do 502
        if buffered:
            stale = _SEGMENT_CACHE.get_stale(url, REF_STALE_GRACE)
            if stale is None:
                stale = _SEGMENT_CACHE.get_stale(target, REF_STALE_GRACE)
            if stale is not None:
                _bump("stale_segment")
                _log("info", "segmento servido do cache vencido (grace REF)")
                return self._reply(
                    200, stale, ctype_default, head_only,
                    [("Cache-Control", "no-store")],
                )
        if LAST_SEGMENT_FALLBACK:
            name = urllib.parse.urlsplit(url).path.rsplit("/", 1)[-1]
            fallback = _LAST_SEGMENT.get(manifest_key, name)
            if fallback is not None:
                _bump("last_segment_fallback")
                return self._reply(
                    200, fallback, ctype_default, head_only,
                    [("Cache-Control", "no-store")],
                )
        return self._error(502, "Segmento temporariamente indisponível", head_only)

    def _finish_segment(self, url, target, manifest_key, data, ctype,
                        head_only, started, ranged):
        if (not ranged and not head_only and data
                and len(data) <= SEGMENT_MAX_CACHE):
            _SEGMENT_CACHE.put(url, data)
            if target != url:
                _SEGMENT_CACHE.put(target, data)
            if manifest_key:
                name = urllib.parse.urlsplit(url).path.rsplit("/", 1)[-1]
                _LAST_SEGMENT.put(manifest_key, name, data)
        if data:
            record_bandwidth(len(data), time.time() - started)
        return self._reply(
            200, data, ctype, head_only,
            [("Cache-Control", "no-store")],
        )


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128
    _stopping = False

    def server_bind(self):
        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = host
        self.server_port = port

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, OSError):
            return


_SERVER = None
_SERVER_THREAD = None
_SERVER_LOCK = threading.Lock()


def _serve(server):
    while not server._stopping:
        try:
            server.serve_forever(poll_interval=0.5)
            return
        except Exception:
            if server._stopping:
                return
            time.sleep(0.5)


def _ensure_server_running(host=LOCAL_HOST, port=0):
    global _SERVER, _SERVER_THREAD
    with _SERVER_LOCK:
        if _SERVER is not None and _SERVER_THREAD is not None and _SERVER_THREAD.is_alive():
            return _SERVER.server_port
        if _SERVER is not None:
            try:
                _SERVER.server_close()
            except Exception:
                pass
        server = ThreadedHTTPServer((host, port), HLSProxyHandler)
        thread = threading.Thread(target=_serve, args=(server,), daemon=True)
        thread.start()
        _SERVER, _SERVER_THREAD = server, thread
        return server.server_port


def stop_server():
    global _SERVER, _SERVER_THREAD
    with _SERVER_LOCK:
        server, thread = _SERVER, _SERVER_THREAD
        _SERVER = _SERVER_THREAD = None
    if server is None:
        return
    server._stopping = True
    try:
        if thread is not None and thread.is_alive():
            server.shutdown()
    except Exception:
        pass
    try:
        server.server_close()
    except Exception:
        pass
    try:
        _PREFETCH.clear()
        _SEGMENT_CACHE.clear()
        _KEY_CACHE.clear()
        _LAST_SEGMENT.clear()
        _manifest_cache_clear()
        doh_cache_clear()
        with _REF_LOCK:
            _REF_STATE.clear()
    except Exception:
        pass


class HLSAddon:
    def __init__(self, handle):
        self.handle = int(handle)

    @staticmethod
    def get_proxy_url(stream_url):
        port = _ensure_server_running()
        base = "http://%s:%d" % (LOCAL_HOST, port)
        return local_proxy_url("manifest", stream_url.strip(), base)

    def play_stream(self, stream_url, *args, **kwargs):
        global _PLAY_AT
        title = kwargs.get("title") or kwargs.get("title_name")
        url = (stream_url or "").strip()
        parsed = urllib.parse.urlparse(url)

        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            return self._fail("URL de stream inválida.")

        try:
            proxy_url = self.get_proxy_url(url)
        except Exception:
            return self._fail("Não foi possível iniciar o proxy HLS.")

        with _FIRST_LOCK:
            _FIRST["manifest"] = False
            _FIRST["segment"] = False
        _PLAY_AT = time.time()

        _reset_stream_state(url)
        _warm_manifest_async(url)

        if xbmcgui is None or xbmcplugin is None:
            return proxy_url

        li = xbmcgui.ListItem(path=proxy_url)
        li.setProperty("IsPlayable", "true")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        if title:
            li.setLabel(title)

        xbmcplugin.setResolvedUrl(self.handle, True, li)
        return proxy_url

    def stop(self):
        stop_server()

    def stats(self):
        with _STATS_LOCK:
            return dict(STATS)

    def _fail(self, message):
        try:
            xbmcgui.Dialog().ok(
                "[B][COLOR white]Erro[/COLOR][/B]",
                "[B][COLOR white]%s[/COLOR][/B]" % message,
            )
        except Exception:
            pass
        try:
            xbmcplugin.setResolvedUrl(
                handle=self.handle, succeeded=False, listitem=xbmcgui.ListItem()
            )
        except Exception:
            pass
        return None


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    port = int(argv[0]) if argv else PORT

    logging.basicConfig(
        level=logging.DEBUG if DEBUG else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    server = ThreadedHTTPServer((BIND_HOST, port), HLSProxyHandler)
    sys.stdout.write(
        "HLS Proxy local iniciado em http://127.0.0.1:{}\n".format(server.server_port)
    )
    sys.stdout.write(USAGE)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()