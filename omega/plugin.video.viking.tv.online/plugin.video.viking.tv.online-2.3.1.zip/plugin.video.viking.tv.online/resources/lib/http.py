# -*- coding: utf-8 -*-
"""Cliente HTTP mínimo (stdlib): sem dependência de script.module.requests."""
import gzip
import json
import os
import re
import socket
import ssl
import time
import urllib.error
import urllib.request

import xbmcvfs

from .common import dbg, log

DEFAULT_UA = 'VLC/3.0.20 LibVLC/3.0.20'


class HttpError(Exception):
    def __init__(self, message, code=None):
        Exception.__init__(self, message)
        self.code = code


def _ssl_ctx(verify):
    ctx = ssl.create_default_context()
    try:
        # Kodi em Android/Linux embarcado pode não ter CAs do sistema: usa o bundle do Kodi
        cafile = xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem')
        if cafile and os.path.exists(cafile):
            ctx.load_verify_locations(cafile=cafile)
    except Exception:
        pass
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _headers(extra):
    h = {'User-Agent': DEFAULT_UA, 'Accept': '*/*', 'Accept-Encoding': 'gzip', 'Connection': 'close'}
    if extra:
        h.update(extra)
    return h


def _gunzip(body):
    if body[:2] == b'\x1f\x8b':
        try:
            return gzip.decompress(body)
        except Exception:
            pass
    return body


def fetch(url, headers=None, timeout=25, verify=True, retries=2, data=None):
    """GET/POST com retries em erros transitórios. Devolve bytes (já descomprimidos)."""
    ctx = _ssl_ctx(verify) if url.lower().startswith('https') else None
    last = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, data=data, headers=_headers(headers))
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                return _gunzip(resp.read())
        except urllib.error.HTTPError as e:
            if e.code >= 500 and attempt < retries:
                last = e
                time.sleep(0.8 * (attempt + 1))
                continue
            raise HttpError('HTTP %s' % e.code, e.code)
        except (urllib.error.URLError, socket.timeout, ConnectionError, ssl.SSLError, OSError) as e:
            last = e
            if attempt < retries:
                time.sleep(0.8 * (attempt + 1))
                continue
    raise HttpError(str(getattr(last, 'reason', None) or last))


def get_json(url, **kw):
    raw = fetch(url, **kw)
    text = raw.decode('utf-8', 'replace').lstrip('\ufeff \r\n\t')
    try:
        return json.loads(text)
    except ValueError:
        # alguns painéis prefixam avisos PHP/HTML antes do JSON
        m = re.search(r'[\[{]', text)
        if m:
            try:
                return json.loads(text[m.start():])
            except ValueError:
                pass
    # log desativado: a resposta bruta e a URL nunca são registradas
    raise HttpError('Resposta inválida (não é JSON)')


def download(url, dest, headers=None, timeout=60, verify=True, progress=None):
    """Baixa em streaming para arquivo (usado pelo XMLTV, que pode ter centenas de MB)."""
    ctx = _ssl_ctx(verify) if url.lower().startswith('https') else None
    req = urllib.request.Request(url, headers=_headers(headers))
    done = 0
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp, open(dest, 'wb') as out:
            try:
                total = int(resp.headers.get('Content-Length') or 0)
            except ValueError:
                total = 0
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                out.write(chunk)
                done += len(chunk)
                if progress and progress(done, total) is False:
                    raise HttpError('Cancelado')
    except urllib.error.HTTPError as e:
        raise HttpError('HTTP %s' % e.code, e.code)
    except (urllib.error.URLError, socket.timeout, ConnectionError, ssl.SSLError, OSError) as e:
        raise HttpError(str(getattr(e, 'reason', None) or e))
    # log desativado: a URL de download nunca é registrada
    return done
