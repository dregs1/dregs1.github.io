# -*- coding: utf-8 -*-
"""Textos da interface: sempre em português do Brasil, qualquer que seja o idioma do Kodi."""


def _(text):
    return text
