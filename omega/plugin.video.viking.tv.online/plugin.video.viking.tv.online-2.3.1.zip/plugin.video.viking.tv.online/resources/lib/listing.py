# -*- coding: utf-8 -*-
"""Helpers de ListItem compartilhados pelo modo lista (plugin) e pela interface IBO.

Kodi 20+ usa os setters de InfoTagVideo (ListItem.setInfo está deprecated e pode sair do
Kodi 22+); Kodi 19 cai no setInfo clássico. Cada setter é isolado em try/except.
"""
import queue
import threading
import time

import xbmc

from .common import FANART, SB, clean_title, dbg, fmt_hm, to_float, to_int
from .epg import summarize
from .i18n import _


def display_name(row):
    name = row.get('name') or ''
    return clean_title(name) if SB('clean_names', True) else name.strip()


def episode_ids(e):
    """IDs (str) de um episódio: o principal + as duplicatas do painel unidas em 'alts' (meta.parse_seasons)."""
    return [str(e.get('id'))] + [str(a.get('id')) for a in (e.get('alts') or []) if isinstance(a, dict)]


def pack_alts(e):
    """'alts' do episódio -> 'id:ext,id:ext' (vai na URL do plugin); None se não há duplicatas."""
    s = ','.join('%s:%s' % (a['id'], a.get('ext') or 'mp4') for a in (e.get('alts') or []))
    return s or None


def unpack_alts(s):
    """Inverso de pack_alts -> [{'id','ext'}]."""
    out = []
    for part in (s or '').split(','):
        rid, _sep, ext = part.partition(':')
        if rid.strip():
            out.append({'id': rid.strip(), 'ext': ext.strip() or 'mp4'})
    return out


def apply_video_info(li, d, mediatype='video'):
    """d: dict normalizado (title, plot, year, rating, genres, duration, cast, ...)."""
    title = d.get('title') or ''
    plot = d.get('plot') or ''
    year = to_int(d.get('year'))
    rating = to_float(d.get('rating'))
    cast = [c for c in (d.get('cast') or []) if c.get('name')]
    try:
        tag = li.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None and hasattr(tag, 'setPlot'):          # Kodi 20+
        def call(name, *args):
            try:
                getattr(tag, name)(*args)
            except Exception as e:
                dbg('InfoTagVideo.%s falhou: %s' % (name, e))
        call('setMediaType', mediatype)
        if title:
            call('setTitle', title)
        if d.get('orig'):
            call('setOriginalTitle', d['orig'])
        if plot:
            call('setPlot', plot)
            call('setPlotOutline', plot[:240])
        if d.get('tagline'):
            call('setTagLine', d['tagline'])
        if year:
            call('setYear', year)
        if rating:
            call('setRating', rating, to_int(d.get('votes')))
        if d.get('genres'):
            call('setGenres', list(d['genres']))
        if d.get('duration'):
            call('setDuration', to_int(d['duration']))
        if d.get('mpaa'):
            call('setMpaa', d['mpaa'])
        if d.get('directors'):
            call('setDirectors', list(d['directors']))
        if d.get('studio'):
            call('setStudios', list(d['studio']))
        if d.get('premiered'):
            call('setPremiered', str(d['premiered'])[:10])
        if d.get('trailer'):
            call('setTrailer', d['trailer'])
        if d.get('tvshowtitle'):
            call('setTvShowTitle', d['tvshowtitle'])
        if d.get('season') is not None:
            call('setSeason', to_int(d['season']))
        if d.get('episode') is not None:
            call('setEpisode', to_int(d['episode']))
        if cast and hasattr(xbmc, 'Actor'):
            try:
                call('setCast', [xbmc.Actor(c['name'], c.get('role') or '', i, c.get('thumb') or '')
                                 for i, c in enumerate(cast)])
            except Exception as e:
                dbg('Actor falhou: %s' % e)
        if d.get('resume'):
            call('setResumePoint', float(d['resume']), float(d.get('total') or 0))
        if d.get('playcount') is not None:
            call('setPlaycount', to_int(d['playcount']))
    else:                                                    # Kodi 19
        info = {'mediatype': mediatype}
        if title:
            info['title'] = title
        if plot:
            info['plot'] = plot
            info['plotoutline'] = plot[:240]
        if year:
            info['year'] = year
        if rating:
            info['rating'] = rating
        if d.get('votes'):
            info['votes'] = str(d['votes'])
        if d.get('genres'):
            info['genre'] = list(d['genres'])
        if d.get('duration'):
            info['duration'] = to_int(d['duration'])
        if d.get('mpaa'):
            info['mpaa'] = d['mpaa']
        if d.get('directors'):
            info['director'] = list(d['directors'])
        if d.get('studio'):
            info['studio'] = list(d['studio'])
        if d.get('premiered'):
            info['premiered'] = str(d['premiered'])[:10]
        if d.get('trailer'):
            info['trailer'] = d['trailer']
        if d.get('tvshowtitle'):
            info['tvshowtitle'] = d['tvshowtitle']
        if d.get('season') is not None:
            info['season'] = to_int(d['season'])
        if d.get('episode') is not None:
            info['episode'] = to_int(d['episode'])
        if d.get('playcount') is not None:
            info['playcount'] = to_int(d['playcount'])
        try:
            li.setInfo('video', info)
            if cast:
                li.setCast([{'name': c['name'], 'role': c.get('role') or '',
                             'thumbnail': c.get('thumb') or ''} for c in cast])
        except Exception as e:
            dbg('setInfo falhou: %s' % e)
    if d.get('resume'):                                      # barra de progresso (Kodi 19+)
        li.setProperty('ResumeTime', str(int(d['resume'])))
        li.setProperty('TotalTime', str(int(d.get('total') or 0)))


def set_art(li, d=None, icon='', fanart=''):
    d = d or {}
    poster = d.get('poster') or icon
    art = {'fanart': d.get('fanart') or fanart or FANART}
    if poster:
        art.update({'poster': poster, 'thumb': poster, 'icon': poster})
    li.setArt(art)


# --------------------------------------------------------------------- EPG
def epg_label(name, progs, now=None):
    """'Canal  •  Programa (20:30-21:15)' — sem tags de cor forçadas nos rótulos."""
    cur = summarize(progs, now).get('now')
    if not cur:
        return name
    return '%s  \u2022  %s (%s-%s)' % (name, cur[2], fmt_hm(cur[0]), fmt_hm(cur[1]))


def epg_plot(progs, now=None):
    sm = summarize(progs, now)
    lines = []

    def line(prefix, p):
        return '%s: %s (%s-%s)' % (prefix, p[2], fmt_hm(p[0]), fmt_hm(p[1]))
    if sm['now']:
        lines.append(line(_('Passando agora'), sm['now']))
        if sm['now'][3]:
            lines.append(sm['now'][3])
    if sm['next']:
        lines += ['', line(_('A seguir'), sm['next'])]
    if sm['later']:
        lines.append(line(_('Depois'), sm['later']))
    return '\n'.join(lines)


# ------------------------------------------------------------------ workers
def parallel(fn, items, workers=4, budget=10.0):
    """fn(item) em threads daemon, parando de iniciar tarefas após 'budget' segundos."""
    items = list(items)
    if not items:
        return
    q = queue.Queue()
    for it in items:
        q.put(it)
    deadline = time.time() + budget

    def work():
        while time.time() < deadline:
            try:
                it = q.get_nowait()
            except queue.Empty:
                return
            try:
                fn(it)
            except Exception as e:
                dbg('worker falhou: %s' % e)

    threads = [threading.Thread(target=work) for _i in range(min(workers, len(items)))]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(max(0.0, deadline - time.time()) + 0.5)
