# -*- coding: utf-8 -*-
"""Blindagem anti-vazamento de log do VIKING TV ONLINE.

Este módulo DESLIGA TODO O LOG do addon dentro do processo do Kodi:

  * ``xbmc.log`` é substituído por uma função muda — nenhuma mensagem
    deste addon (nem das bibliotecas vendor: requests/urllib3/etc.)
    chega ao kodi.log. Credenciais, usuários, senhas, tokens e links
    de servidores nunca são registrados;
  * o módulo ``logging`` do Python é silenciado (root + urllib3 +
    requests + charset_normalizer: nível CRITICAL, NullHandler e sem
    propagação) — as bibliotecas vendor não conseguem logar URLs;
  * arquivos de log antigos criados pelo addon em
    ``userdata/addon_data/<addon>/`` são APAGADOS (ex.:
    ``viking.tv.online.debug.log``) e nunca mais são criados;
  * ``scrub()`` ofusca, em qualquer texto, URLs (usuário/senha/host),
    caminhos Xtream ``/live/<user>/<pass>/`` e parâmetros sensíveis
    (username=, password=, token, key...). É a defesa extra usada nos
    poucos pontos em que um texto de erro ainda precisa existir em
    memória: mesmo que algo tente logar, o que sai é ofuscado.

Importante: o silenciamento vale para o processo Python DESTE addon
(cada plugin/serviço do Kodi roda no seu próprio interpretador), então
nenhum outro addon é afetado.
"""
import re

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:  # standalone / testes fora do Kodi
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

ADDON_ID = 'plugin.video.viking.tv.online'

# Chave-mestre: enquanto False, NADA é logado por este addon.
LOG_ENABLED = False

# ---------------------------------------------------------------------------
# Ofuscação de links/credenciais (defesa em profundidade)
# ---------------------------------------------------------------------------
_URL_RE = re.compile(r'https?://[^\s<>"\']+', re.I)
_USERPASS_URL_RE = re.compile(r'(https?://)([^/\s:@"\']+):([^@\s"\']+)@', re.I)
_XTREAM_PATH_RE = re.compile(
    r'/(?:live|movie|series|timeshift|play|passwords)/([^/\s?"\']+)(/[^/\s?"\']*/)?([^/\s?"\']*)', re.I)
_SENSITIVE_PARAM_RE = re.compile(
    r'(?i)\b(username|password|passwd|pass|pwd|usuario|usuário|senha|user|token|key|api_?key|auth|'
    r'credentials?|cred)\s*[=:]\s*([^\s&"\']+)')
_IPV4_RE = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}(?::\d{2,5})?\b')


def scrub(text):
    """Ofusca links, credenciais e IPs em qualquer texto.

    Usado como rede de segurança: se algum texto de erro/mensagem ainda
    circular com uma URL dentro, o que sai é sempre ofuscado.
    """
    try:
        s = text if isinstance(text, str) else str(text)
    except Exception:
        return '[texto]'

    # 1) usuário:senha@host -> host mascarado inteiro
    s = _USERPASS_URL_RE.sub(r'\1***:***@', s)
    # 2) qualquer URL restante -> link ofuscado
    s = _URL_RE.sub('[LINK-OFUSCADO]', s)
    # 3) caminhos Xtream /live/<user>/<pass>/...
    s = _XTREAM_PATH_RE.sub(lambda m: '/%s/***/***/%s' % (
        m.group(0).split('/')[1], m.group(3) or ''), s)
    # 4) pares username=... / password=... / token=...
    s = _SENSITIVE_PARAM_RE.sub(lambda m: '%s=***' % m.group(1), s)
    # 5) IPs (servidores de streaming/CDN)
    s = _IPV4_RE.sub('[IP-OFUSCADO]', s)
    return s


# ---------------------------------------------------------------------------
# Limpeza de arquivos de log em userdata/addon_data
# ---------------------------------------------------------------------------
_LEGACY_LOG_NAMES = (
    'viking.tv.online.debug.log',
    'viking.tv.online.log',
    'debug.log',
    'epg_download.tmp',   # resto de download do XMLTV que falhou
)
_PURGED = False


def _profile_dir():
    if xbmcaddon is None:
        return ''
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile')) or ''
    except Exception:
        return ''


def purge_log_files():
    """Apaga logs antigos do addon em addon_data (só roda uma vez por processo)."""
    global _PURGED
    if _PURGED:
        return
    _PURGED = True
    profile = _profile_dir()
    if not profile or xbmcvfs is None:
        return
    try:
        files = xbmcvfs.listdir(profile)[1] or []
    except Exception:
        return
    for name in files:
        try:
            low = str(name).lower()
            if low in _LEGACY_LOG_NAMES or low.endswith('.debug.log'):
                xbmcvfs.delete(xbmcvfs.join(profile, name))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Silenciamento do logging do Python (vendor: requests/urllib3/etc.)
# ---------------------------------------------------------------------------
_PYLOG_DONE = False


def silence_python_logging():
    """Bibliotecas vendor não logam nada (nem URLs de conexão)."""
    global _PYLOG_DONE
    if _PYLOG_DONE:
        return
    _PYLOG_DONE = True
    try:
        import logging

        class _Null(logging.Handler):
            def emit(self, record):
                return

        root = logging.getLogger()
        try:
            root.handlers = []
        except Exception:
            pass
        root.addHandler(_Null())
        root.setLevel(logging.CRITICAL)
        for name in ('urllib3', 'requests', 'requests.packages', 'charset_normalizer',
                     'charset_normalizer.md', 'werkzeug', 'dohresolver', 'vodproxy',
                     'tsproxy', 'hlsproxy', 'speedtest'):
            try:
                lg = logging.getLogger(name)
                lg.handlers = []
                lg.addHandler(_Null())
                lg.propagate = False
                lg.setLevel(logging.CRITICAL)
            except Exception:
                pass
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Mudo no xbmc.log (vale para TODO o processo deste addon)
# ---------------------------------------------------------------------------
_XBMC_LOG_MUTED = False
_ORIG_XBMC_LOG = None


def _muted_log(msg, level=None):
    """Recebe qualquer chamada de log e NÃO emite nada."""
    return None


def mute_xbmc_log():
    """Substitui xbmc.log por uma função muda neste processo.

    É a rede de segurança definitiva: mesmo que algum módulo esquecido
    (ou biblioteca vendor) tente chamar xbmc.log com URL/credencial,
    nada é escrito no kodi.log.
    """
    global _XBMC_LOG_MUTED, _ORIG_XBMC_LOG
    if _XBMC_LOG_MUTED or xbmc is None:
        return
    try:
        _ORIG_XBMC_LOG = xbmc.log
        xbmc.log = _muted_log
        _XBMC_LOG_MUTED = True
    except Exception:
        pass


def restore_xbmc_log():
    """Devolve o xbmc.log original (não usado em produção)."""
    global _XBMC_LOG_MUTED
    if not _XBMC_LOG_MUTED or xbmc is None or _ORIG_XBMC_LOG is None:
        return
    try:
        xbmc.log = _ORIG_XBMC_LOG
    except Exception:
        pass
    _XBMC_LOG_MUTED = False


# ---------------------------------------------------------------------------
# Ponto de entrada da blindagem
# ---------------------------------------------------------------------------
def install():
    """Instala TODA a blindagem de log. Idempotente (pode chamar N vezes)."""
    purge_log_files()
    silence_python_logging()
    mute_xbmc_log()
