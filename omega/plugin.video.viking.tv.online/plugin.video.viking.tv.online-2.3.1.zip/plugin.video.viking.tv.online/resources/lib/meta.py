# -*- coding: utf-8 -*-
"""Metadados de filmes/séries: Xtream (get_vod_info/get_series_info) + TMDB + TVmaze.

Ordem: o que o provedor manda é a base; o TMDB (chave do próprio usuário) completa o que
faltar (ou sobrepõe, se 'Preferir TMDB'); TVmaze (sem chave) é a reserva para séries.
Tudo em cache no SQLite.
"""
import difflib
import json
import re
import time
from urllib.parse import urlencode

from . import catalog, http
from .common import S, SB, clean_title, dbg, norm_text, split_year, to_float, to_int
from .db import db
from .i18n import _

TMDB_API = 'https://api.themoviedb.org/3/'
TMDB_IMG = 'https://image.tmdb.org/t/p/'
TTL_INFO = 30 * 86400
TTL_RAW = 6 * 3600
_EMPTY = (None, '', [], 0, 0.0)

_NOISE = re.compile(r'(?i)[\[\(\{]\s*(?:4k|uhd|fhd|hd|sd|h\.?265|hevc|dub(?:lado)?|leg(?:endado)?|'
                    r'nacional|dual(?:\s*[a\u00e1]udio)?|cam|ts|web-?dl|bluray|1080p|720p|480p|pt-?br|multi)'
                    r'\s*[\]\)\}]')
_WORDS = re.compile(r'(?i)\b(?:4k|uhd|fhd|1080p|720p|dublado|legendado|dual audio)\b')


# ---------------------------------------------------------------- helpers
def _split_list(v):
    if not v:
        return []
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in re.split(r'[,/|;]', str(v)) if x.strip()]


def _first(*vals):
    for v in vals:
        if isinstance(v, (list, tuple)):
            v = v[0] if v else ''
        if v is not None and str(v).strip() and str(v).strip().lower() not in ('none', 'null'):
            return str(v).strip()
    return ''


def _year_of(*vals):
    for v in vals:
        m = re.search(r'(?:19|20)\d{2}', str(v or ''))
        if m:
            return int(m.group(0))
    return 0


def _duration(info):
    s = to_int(info.get('duration_secs'))
    if s:
        return s
    m = re.match(r'^(\d+):(\d+):(\d+)$', str(info.get('duration') or ''))
    if m:
        return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
    rt = to_int(_first(info.get('episode_run_time')))
    return rt * 60 if rt else 0


def _rating(info):
    r = to_float(info.get('rating')) or to_float(info.get('rating_5based')) * 2
    return max(0.0, min(10.0, r))


def _strip_html(s):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', ' ', s or '')).strip()


def search_title(name):
    """Nome do provedor -> (título limpo p/ busca, ano)."""
    s = _NOISE.sub(' ', clean_title(name or ''))
    s, year = split_year(s)
    s = re.sub(r'\s+', ' ', _WORDS.sub(' ', s)).strip(' -\u2013|:')
    return s, year


def merge(base, extra, prefer=False):
    out = dict(base)
    for k, v in (extra or {}).items():
        if v in _EMPTY:
            continue
        if prefer or out.get(k) in _EMPTY:
            out[k] = v
    return out


def _best(results, title, year, tkeys, dkey):
    nt = norm_text(title)
    best, best_score = None, 0.0
    for r in (results or [])[:10]:
        ratios = [difflib.SequenceMatcher(None, nt, norm_text(r.get(k) or '')).ratio()
                  for k in tkeys if r.get(k)]
        score = max(ratios or [0.0])
        ry = to_int(str(r.get(dkey) or '')[:4])
        if year and ry:
            diff = abs(year - ry)
            score += 0.1 if diff == 0 else -0.15 * min(diff, 3)
        if score > best_score:
            best, best_score = r, score
    return best if best_score >= 0.55 else None


# ---------------------------------------------------------- normalizadores
def basic_info(row, kind):
    """Info mínima só com o que já está no catálogo local (sem rede)."""
    ex = catalog.extra(row)
    title, year = split_year(clean_title(row.get('name') or ''))
    d = {'title': title or row.get('name') or '',
         'year': year or _year_of(ex.get('year'), ex.get('release')),
         'rating': to_float(row.get('rating')), 'poster': row.get('icon') or '',
         'tmdb': str(ex.get('tmdb') or '')}
    if kind == 'series':
        d.update({'plot': _first(ex.get('plot')), 'genres': _split_list(ex.get('genre')),
                  'directors': _split_list(ex.get('director')),
                  'cast': [{'name': n} for n in _split_list(ex.get('cast'))],
                  'premiered': _first(ex.get('release')), 'fanart': _first(ex.get('backdrop')),
                  'trailer': _trailer(ex.get('trailer')),
                  'duration': to_int(_first(ex.get('runtime'))) * 60})
    return d


def _trailer(v):
    v = _first(v)
    if not v:
        return ''
    if v.startswith('http') or v.startswith('plugin://'):
        return v
    return 'plugin://plugin.video.youtube/play/?video_id=%s' % v


def from_xtream_vod(data, row):
    info = data.get('info') if isinstance(data, dict) else None
    if not isinstance(info, dict):
        return {}
    title, year = split_year(clean_title(_first(info.get('name'), row.get('name'))))
    return {
        'title': title, 'orig': _first(info.get('o_name')),
        'plot': _first(info.get('plot'), info.get('description')),
        'year': year or _year_of(info.get('releasedate'), info.get('release_date'), info.get('year')),
        'rating': _rating(info), 'votes': to_int(info.get('rating_count_kinopoisk')),
        'genres': _split_list(info.get('genre')), 'duration': _duration(info),
        'mpaa': _first(info.get('mpaa_rating'), info.get('age')),
        'directors': _split_list(info.get('director')),
        'cast': [{'name': n} for n in _split_list(info.get('actors') or info.get('cast'))],
        'premiered': _first(info.get('releasedate'), info.get('release_date')),
        'trailer': _trailer(info.get('youtube_trailer')),
        'poster': _first(info.get('movie_image'), info.get('cover_big'), row.get('icon')),
        'fanart': _first(info.get('backdrop_path')),
        'tmdb': _first(info.get('tmdb_id'), info.get('tmdb')),
    }


def from_xtream_series(info, row):
    if not isinstance(info, dict):
        return {}
    title, year = split_year(clean_title(_first(info.get('name'), row.get('name'))))
    return {
        'title': title, 'plot': _first(info.get('plot'), info.get('description')),
        'year': year or _year_of(info.get('releaseDate'), info.get('release_date')),
        'rating': _rating(info), 'genres': _split_list(info.get('genre')),
        'directors': _split_list(info.get('director')),
        'cast': [{'name': n} for n in _split_list(info.get('cast'))],
        'premiered': _first(info.get('releaseDate'), info.get('release_date')),
        'trailer': _trailer(info.get('youtube_trailer')),
        'poster': _first(info.get('cover'), row.get('icon')),
        'fanart': _first(info.get('backdrop_path')),
        'duration': to_int(_first(info.get('episode_run_time'))) * 60,
        'tmdb': _first(info.get('tmdb_id'), info.get('tmdb')),
    }


def norm_tmdb(kind, d):
    movie = kind == 'movie'
    credits = d.get('credits') or {}
    cast = [{'name': a.get('name') or '', 'role': a.get('character') or '',
             'thumb': (TMDB_IMG + 'w185' + a['profile_path']) if a.get('profile_path') else ''}
            for a in (credits.get('cast') or [])[:15] if a.get('name')]
    if movie:
        directors = [c.get('name') for c in (credits.get('crew') or []) if c.get('job') == 'Director'][:3]
        date = d.get('release_date') or ''
        runtime = to_int(d.get('runtime')) * 60
    else:
        directors = [c.get('name') for c in (d.get('created_by') or []) if c.get('name')][:3]
        date = d.get('first_air_date') or ''
        runtime = to_int((d.get('episode_run_time') or [0])[0]) * 60
    trailer = ''
    for v in (d.get('videos') or {}).get('results') or []:
        if v.get('site') == 'YouTube' and v.get('type') == 'Trailer' and v.get('key'):
            trailer = 'plugin://plugin.video.youtube/play/?video_id=%s' % v['key']
            break
    studios = [c.get('name') for c in (d.get('production_companies') or d.get('networks') or [])
               if c.get('name')][:2]
    return {
        'plot': d.get('overview') or '', 'tagline': d.get('tagline') or '',
        'orig': d.get('original_title') or d.get('original_name') or '',
        'year': to_int(date[:4]), 'premiered': date,
        'rating': round(to_float(d.get('vote_average')), 1), 'votes': to_int(d.get('vote_count')),
        'genres': [g.get('name') for g in (d.get('genres') or []) if g.get('name')],
        'duration': runtime, 'directors': directors, 'cast': cast, 'studio': studios,
        'trailer': trailer, 'tmdb': str(d.get('id') or ''),
        'poster': (TMDB_IMG + 'w500' + d['poster_path']) if d.get('poster_path') else '',
        'fanart': (TMDB_IMG + 'w1280' + d['backdrop_path']) if d.get('backdrop_path') else '',
    }


# "S01E02" / "T01E02" no título: padrão de muitos painéis ("Série - S01E02 - Título")
_EP_MARK = re.compile(r'(?i)(?<![a-z0-9])[st](\d{1,3})\s*[._-]?\s*e(\d{1,4})(?!\d)')
_EP_TAGS = re.compile(r'(?i)[\[\(\{][^\]\)\}]*[\]\)\}]|'
                      r'\b(?:dublado|legendado|dual|audio|dub|leg|fhd|uhd|hd|4k|1080p|720p|480p)\b')


def _ep_quality(ei):
    """Quanto o painel sabe do arquivo (duração, bitrate, vídeo/áudio). Só ordena os candidatos
    de um episódio duplicado; quem decide qual toca é o teste de reprodução (player.pick_episode)."""
    return (2 if _duration(ei) else 0) + (2 if to_int(ei.get('bitrate')) else 0) + \
        (1 if ei.get('video') else 0) + (1 if ei.get('audio') else 0)


def _merge_dupes(sn, eps):
    """Painéis às vezes listam o MESMO episódio mais de uma vez, com ids diferentes e 'episode_num'
    seguido ("Série - S01E01 - Piloto" aparece como nº 1 e nº 2) — e só um deles toca. Une cada grupo
    numa entrada só e guarda os outros ids em 'alts' ([{'id','ext'}]); o player testa os candidatos
    na hora de reproduzir. Chave do episódio: SxxEyy do título; sem isso, o título igual; sem título,
    o mesmo número. Temporada sem duplicata sai exatamente como veio do painel."""
    eps = [dict(e) for e in eps]
    keys = []
    for e in eps:
        m = _EP_MARK.search(e['title'])
        t = norm_text(_EP_TAGS.sub(' ', e['title']))
        if m and to_int(m.group(1)) == sn:
            keys.append(('e', to_int(m.group(2))))
        elif len(t) >= 3:
            keys.append(('t', t))
        elif not t and e['num'] > 0:
            keys.append(('n', e['num']))
        else:
            keys.append(('i', e['id']))
    weak = {}
    for k in keys:
        if k[0] in ('t', 'n'):
            weak[k] = weak.get(k, 0) + 1
    if sum(c - 1 for c in weak.values()) * 2 > len(eps):       # título genérico: não une por título
        keys = [('i', e['id']) if k[0] in ('t', 'n') else k for k, e in zip(keys, eps)]
    groups = {}
    for k, e in zip(keys, eps):
        g = groups.setdefault(k, [])
        if all(x['id'] != e['id'] for x in g):                 # mesmo id repetido = a mesma fonte
            g.append(e)
    renum = any(len(g) > 1 for g in groups.values())
    out = []
    for k, g in groups.items():
        g = sorted(g, key=lambda x: (-x['_q'], -x['duration']))    # estável: empate segue a ordem do painel
        main = g[0]
        for o in g[1:]:
            for f in ('title', 'plot', 'thumb', 'air', 'duration', 'rating'):
                if not main.get(f) and o.get(f):
                    main[f] = o[f]
        if len(g) > 1:
            main['alts'] = [{'id': o['id'], 'ext': o['ext']} for o in g[1:]]
        if renum and k[0] == 'e':
            main['num'] = k[1]                                 # numera pelo SxxEyy (E01, E02...)
        out.append(main)
    for e in out:
        e.pop('_q', None)
    return sorted(out, key=lambda x: x['num'])


def parse_seasons(raw):
    """get_series_info -> [{'number','name','plot','poster','episodes':[...]}] (tolera formatos)."""
    seasons_meta = {}
    for s in (raw.get('seasons') or []):
        if isinstance(s, dict):
            seasons_meta[to_int(s.get('season_number'))] = s
    eps_raw = raw.get('episodes') or {}
    flat = []
    if isinstance(eps_raw, dict):
        for sk, lst in eps_raw.items():
            for e in (lst or []):
                flat.append((to_int(sk), e))
    elif isinstance(eps_raw, list):
        for lst in eps_raw:
            if isinstance(lst, list):
                flat.extend((to_int(e.get('season')) if isinstance(e, dict) else 0, e) for e in lst)
            elif isinstance(lst, dict):
                flat.append((to_int(lst.get('season')), lst))
    by_season = {}
    for sn, e in flat:
        if not isinstance(e, dict) or e.get('id') in (None, ''):
            continue
        sn = to_int(e.get('season'), sn) or sn
        ei = e.get('info') if isinstance(e.get('info'), dict) else {}
        by_season.setdefault(sn, []).append({
            'id': str(e.get('id')), 'num': to_int(e.get('episode_num')),
            'title': str(e.get('title') or '').strip(), 'ext': e.get('container_extension') or 'mp4',
            'plot': _first(ei.get('plot')), 'duration': _duration(ei),
            'thumb': _first(ei.get('movie_image'), ei.get('cover_big')),
            'air': _first(ei.get('releasedate'), ei.get('air_date')), 'rating': _rating(ei),
            'season': sn, '_q': _ep_quality(ei)})
    out = []
    for sn in sorted(by_season):
        sm = seasons_meta.get(sn, {})
        try:
            eps_out = _merge_dupes(sn, by_season[sn])
        except Exception as ex:                  # nunca pior que antes: lista crua do painel
            dbg('unir episódios duplicados (T%s) falhou: %s' % (sn, ex))
            eps_out = sorted(({k: v for k, v in x.items() if k != '_q'} for x in by_season[sn]),
                             key=lambda x: x['num'])
        out.append({'number': sn, 'name': _first(sm.get('name')) or (_('Temporada %d') % sn),
                    'plot': _first(sm.get('overview')),
                    'poster': _first(sm.get('cover_big'), sm.get('cover')),
                    'episodes': eps_out})
    return out


# ------------------------------------------------------------------- Meta
class Meta(object):
    def __init__(self, xt):
        self.xt = xt

    # cache
    def _get(self, kind, rid, ttl):
        r = db().q1('SELECT data, ts FROM meta WHERE kind=? AND id=?', (kind, str(rid)))
        if r and time.time() - r['ts'] < ttl:
            try:
                return json.loads(r['data'])
            except ValueError:
                return None
        return None

    def _put(self, kind, rid, data):
        db().x('INSERT OR REPLACE INTO meta(kind, id, ts, data) VALUES (?,?,?,?)',
               (kind, str(rid), int(time.time()), json.dumps(data, ensure_ascii=False)))

    def cached(self, row, kind):
        """Info já em cache (qualquer idade) ou None. Sem rede."""
        return self._get(kind, row['id'], 10 ** 10)

    def quick(self, row, kind):
        """Cache ou info básica do catálogo. Sem rede, instantâneo (usado na UI)."""
        return self.cached(row, kind) or basic_info(row, kind)

    # TMDB / TVmaze
    def _tmdb(self, path, **params):
        key = S('tmdb_key').strip()
        if not key:
            return None
        params.setdefault('language', S('tmdb_lang', 'pt-BR') or 'pt-BR')
        headers = {}
        if len(key) > 40:       # token de leitura v4 (JWT)
            headers['Authorization'] = 'Bearer ' + key
        else:
            params['api_key'] = key
        url = TMDB_API + path + '?' + urlencode({k: v for k, v in params.items() if v not in (None, '')})
        try:
            return http.get_json(url, headers=headers, timeout=12, retries=1)
        except http.HttpError as e:
            dbg('TMDB %s falhou: %s' % (path, e))
            return None

    def _tmdb_lookup(self, kind, d, row):
        title, year = search_title(row.get('name') or d.get('title') or '')
        year = year or to_int(d.get('year'))
        path = 'movie' if kind == 'movie' else 'tv'
        tid = d.get('tmdb')
        if not tid:
            ykey = 'year' if kind == 'movie' else 'first_air_date_year'
            res = self._tmdb('search/' + path, query=title, **({ykey: year} if year else {}))
            results = (res or {}).get('results') or []
            if not results and year:
                results = (self._tmdb('search/' + path, query=title) or {}).get('results') or []
            tk = ('title', 'original_title') if kind == 'movie' else ('name', 'original_name')
            pick = _best(results, title, year, tk, 'release_date' if kind == 'movie' else 'first_air_date')
            if not pick:
                return None
            tid = pick['id']
        det = self._tmdb('%s/%s' % (path, tid), append_to_response='credits,videos')
        if not isinstance(det, dict) or not det.get('id'):
            return None
        if not det.get('overview') and (S('tmdb_lang', 'pt-BR') or 'pt-BR').lower() != 'en-us':
            en = self._tmdb('%s/%s' % (path, tid), language='en-US')
            if isinstance(en, dict) and en.get('overview'):
                det['overview'] = en['overview']
        return norm_tmdb(kind, det)

    def _tvmaze(self, d, row):
        title, year = search_title(row.get('name') or d.get('title') or '')
        if not title:
            return d
        try:
            j = http.get_json('https://api.tvmaze.com/singlesearch/shows?' + urlencode({'q': title}),
                              timeout=10, retries=1)
        except http.HttpError:
            return d
        if not isinstance(j, dict) or not j.get('name'):
            return d
        prem = j.get('premiered') or ''
        if year and to_int(prem[:4]) and abs(year - to_int(prem[:4])) > 1:
            return d
        add = {'plot': _strip_html(j.get('summary')), 'rating': to_float((j.get('rating') or {}).get('average')),
               'genres': j.get('genres') or [], 'poster': (j.get('image') or {}).get('original') or '',
               'premiered': prem, 'year': to_int(prem[:4]), 'duration': to_int(j.get('runtime')) * 60}
        return merge(d, add, False)

    def _enrich(self, kind, d, row):
        if not S('tmdb_key').strip():
            return self._tvmaze(d, row) if kind == 'series' and SB('use_tvmaze', True) else d
        prefer = SB('prefer_tmdb', False)
        if not (prefer or not d.get('plot') or not d.get('poster') or not d.get('cast')
                or not d.get('fanart')):
            return d
        t = self._tmdb_lookup(kind, d, row)
        if t:
            return merge(d, t, prefer)
        return self._tvmaze(d, row) if kind == 'series' and SB('use_tvmaze', True) else d

    # filmes
    def movie(self, row):
        rid = str(row['id'])
        hit = self._get('movie', rid, TTL_INFO)
        if hit:
            return hit
        d = basic_info(row, 'movie')
        ok = False
        try:
            d = merge(d, from_xtream_vod(self.xt.vod_info(rid), row), True)
            ok = True
        except Exception as e:
            dbg('get_vod_info %s falhou: %s' % (rid, e))
        d = self._enrich('movie', d, row)
        if ok:
            self._put('movie', rid, d)
        return d

    # séries
    def _series_raw(self, rid):
        hit = self._get('sraw', rid, TTL_RAW)
        if hit:
            return hit
        raw = self.xt.series_info_raw(rid)
        if raw:
            self._put('sraw', rid, raw)
        return raw

    def series(self, row):
        rid = str(row['id'])
        hit = self._get('series', rid, TTL_INFO)
        if hit:
            return hit
        d = basic_info(row, 'series')
        ok = False
        try:
            raw = self._series_raw(rid)
            d = merge(d, from_xtream_series(raw.get('info'), row), True)
            ok = True
        except Exception as e:
            dbg('get_series_info %s falhou: %s' % (rid, e))
        d = self._enrich('series', d, row)
        if ok:
            self._put('series', rid, d)
        return d

    def series_detail(self, row):
        """{'info': info da série, 'seasons': [...]} — levanta exceção se o painel falhar."""
        rid = str(row['id'])
        raw = self._series_raw(rid)
        return {'info': self.series(row), 'seasons': parse_seasons(raw)}

    def tmdb_season(self, tmdb_id, season):
        key = '%s:%s' % (tmdb_id, season)
        hit = self._get('tvs', key, TTL_INFO)
        if hit is not None:
            return hit
        d = self._tmdb('tv/%s/season/%s' % (tmdb_id, season))
        eps = {}
        for e in (d or {}).get('episodes') or []:
            eps[str(e.get('episode_number'))] = {
                'plot': e.get('overview') or '', 'title': e.get('name') or '',
                'thumb': (TMDB_IMG + 'w300' + e['still_path']) if e.get('still_path') else '',
                'air': e.get('air_date') or '', 'duration': to_int(e.get('runtime')) * 60}
        if d:
            self._put('tvs', key, eps)
        return eps

    def fill_episodes(self, info, season):
        """Completa sinopse/imagem dos episódios com o TMDB quando o provedor não mandou."""
        eps = season['episodes']
        tmdb = (info or {}).get('tmdb')
        if not tmdb or not S('tmdb_key').strip():
            return eps
        if all(e.get('plot') and e.get('thumb') for e in eps):
            return eps
        extra = self.tmdb_season(tmdb, season['number'])
        for e in eps:
            x = extra.get(str(e['num']))
            if x:
                for k in ('plot', 'thumb', 'air', 'duration'):
                    if not e.get(k) and x.get(k):
                        e[k] = x[k]
                if not e.get('title') and x.get('title'):
                    e['title'] = x['title']
        return eps
