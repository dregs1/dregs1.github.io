# -*- coding: utf-8 -*-
"""Modo lista (plugin://plugin.video.viking.tv.online/): qualquer skin e widget.

Canais mostram o programa atual no nome; filmes/séries trazem descrição, pôster, elenco.
Rótulos sem tags [COLOR]/[B] forçadas (o skin decide a aparência).
"""
import os
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from . import catalog, listing, player, store
from .common import (ADDON_ID, ADDON_NAME, FANART, MEDIA, SB, SI, Cancelled, busy, cfg_reload,
                     fmt_hm, log_exc, notify)
from .core import (Core, ensure_catalog, kind_label, refresh_epg, test_connection)
from .db import clear_cache
from .i18n import _
from .xtream import XtreamError

BASE = ''
HANDLE = -1
CORE = None
ACTION = ''
_ENDED = False
KINDS = ('live', 'movie', 'series')


# ----------------------------------------------------------------- helpers
def url(**q):
    return BASE + '?' + urlencode({k: v for k, v in q.items() if v is not None})


def _ico(name):
    return os.path.join(MEDIA, name)


def _folder(label, icon, plot='', **q):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': _ico(icon), 'thumb': _ico(icon), 'fanart': FANART})
    if plot:
        listing.apply_video_info(li, {'title': label, 'plot': plot})
    return (url(**q), li, True)


def _action(label, icon, **q):
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': _ico(icon), 'thumb': _ico(icon), 'fanart': FANART})
    li.setProperty('IsPlayable', 'false')
    return (url(**q), li, False)


def _end(items, content='files', title=''):
    global _ENDED
    xbmcplugin.setPluginCategory(HANDLE, title)
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addDirectoryItems(HANDLE, items, len(items))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
    _ENDED = True


def _fail():
    global _ENDED
    if HANDLE < 0 or _ENDED:
        return
    _ENDED = True
    if ACTION == 'play':
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    else:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def _configure():
    xbmcgui.Dialog().ok(ADDON_NAME,
                        _('Não foi possível carregar as credenciais do link remoto fixo do addon.\n\n'
                          'Verifique sua conexão com a internet e tente novamente.\n'
                          '(O link é configurado no default.py do addon, como no VIKING TV original).'))
    # tenta de novo com uma busca fresca do link remoto
    try:
        CORE.xt.reload_credentials()
    except Exception:
        log_exc('_configure reload_credentials')


def _ready(kinds):
    if not CORE.xt.configured:
        _configure()
        _fail()
        return False
    if not ensure_catalog(CORE, kinds):
        _fail()
        return False
    return True


def _page_size(kind):
    ps = max(10, SI('page_size', 50))
    return max(200, ps * 4) if kind == 'live' else ps


def _paged(kind, **kw):
    """Busca uma página (+1 p/ saber se há próxima). Devolve (rows, has_more, page)."""
    page = max(0, int(kw.pop('page', 0) or 0))
    ps = _page_size(kind)
    rows = catalog.items(kind, limit=ps + 1, offset=page * ps, **kw)
    return rows[:ps], len(rows) > ps, page


def _next(page, **q):
    return _folder(_('Próxima página') + ' \u00bb', 'ic-play.png', page=page, **q)


def _fav_ctx(kind, rid, favs):
    label = _('Remover dos favoritos') if rid in favs else _('Adicionar aos favoritos')
    return (label, 'RunPlugin(%s)' % url(action='fav', kind=kind, id=rid))


# ------------------------------------------------------------------ menu
def root(_q=None):
    if SB('open_ui', True) and HANDLE >= 0:
        xbmc.executebuiltin('RunScript(%s)' % ADDON_ID)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    menu()


def menu(_q=None):
    items = []
    if player.video_playing():
        items.append(_action(_('Voltar ao vídeo (tela cheia)'), 'ic-play.png', action='fullscreen'))
    items += [
        _folder(_('TV ao vivo'), 'ic-live.png', action='live'),
        _folder(_('Filmes'), 'ic-movies.png', action='movies'),
        _folder(_('Séries'), 'ic-series.png', action='series'),
        _folder(_('Guia de programação (EPG)'), 'ic-guide.png', action='guide'),
        _folder(_('Favoritos'), 'ic-star.png', action='favs'),
        _folder(_('Continuar assistindo'), 'ic-history.png', action='continue'),
        _folder(_('Buscar'), 'ic-search.png', action='search'),
        _action(_('Abrir interface IBO'), 'ic-live.png', action='ui'),
        _action(_('Atualizar catálogo e EPG'), 'ic-refresh.png', action='refresh_all'),
        _action(_('Configurações'), 'ic-settings.png', action='settings'),
    ]
    _end(items, 'files', ADDON_NAME)


# ------------------------------------------------------------- categorias
def _categories(kind, action, icon, all_label, guide=False):
    if not _ready([kind]):
        return
    cats = catalog.categories(kind)
    extra = {'guide': '1'} if guide else {}
    items = [_folder(_('Buscar') + '...', 'ic-search.png', action='search', kind=kind),
             _folder(all_label, icon, action=action, cat='', **extra)]
    items += [_folder('%s (%d)' % (c['name'], c['count']), icon, action=action, cat=c['id'], **extra)
              for c in cats]
    _end(items, 'files', kind_label(kind))


def live(_q=None):
    _categories('live', 'live_cat', 'ic-live.png', _('Todos os canais'))


def guide(_q=None):
    _categories('live', 'live_cat', 'ic-guide.png', _('Todos os canais'), guide=True)


def movies(_q=None):
    _categories('movie', 'movies_cat', 'ic-movies.png', _('Todos os filmes'))


def series(_q=None):
    _categories('series', 'series_cat', 'ic-series.png', _('Todas as séries'))


# --------------------------------------------------------- construtores de itens
def _live_items(rows, as_guide=False):
    now = time.time()
    progs = CORE.epg.for_items(rows, n=3, now=now) if SB('epg_enable', True) else {}
    favs = set(store.fav_ids('live'))
    items = []
    for r in rows:
        p = progs.get(r['id'], [])
        name = listing.display_name(r)
        label = listing.epg_label(name, p, now) if SB('epg_in_name', True) else name
        li = xbmcgui.ListItem(label)
        icon = r.get('icon') or ''
        listing.set_art(li, {'poster': icon}, icon)
        listing.apply_video_info(li, {'title': label, 'plot': listing.epg_plot(p, now) or name})
        li.addContextMenuItems([
            _fav_ctx('live', r['id'], favs),
            (_('Programação do canal'), 'Container.Update(%s)' % url(action='epg_channel', id=r['id']))])
        if as_guide:
            items.append((url(action='epg_channel', id=r['id']), li, True))
        else:
            # Canal ao vivo: item aponta direto para o f4mTester (como no addon
            # VIKING TV original) — clicar executa o plugin, que abre o canal.
            items.append((player.f4m_url_for_live(CORE.xt, r['id'], label, icon), li, False))
    return items


def _prefetch_movies(rows):
    if not SB('list_desc', True):
        return
    todo = [r for r in rows if CORE.meta.cached(r, 'movie') is None]
    if todo:
        listing.parallel(CORE.meta.movie, todo, workers=4, budget=8.0)


def _movie_items(rows):
    _prefetch_movies(rows)
    favs = set(store.fav_ids('movie'))
    watched = store.watched_ids('movie')
    items = []
    for r in rows:
        info = CORE.meta.quick(r, 'movie')
        name = listing.display_name(r)
        li = xbmcgui.ListItem(name)
        d = dict(info, title=name)
        if str(r['id']) in watched:
            d['playcount'] = 1
        listing.apply_video_info(li, d, 'movie')
        listing.set_art(li, info, r.get('icon'))
        li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems([_fav_ctx('movie', r['id'], favs)])
        items.append((url(action='play', kind='movie', id=r['id'], ext=r.get('ext') or 'mp4', title=name), li, False))
    return items


def _series_items(rows):
    favs = set(store.fav_ids('series'))
    items = []
    for r in rows:
        info = CORE.meta.quick(r, 'series')
        name = listing.display_name(r)
        li = xbmcgui.ListItem(name)
        listing.apply_video_info(li, dict(info, title=name), 'tvshow')
        listing.set_art(li, info, r.get('icon'))
        li.addContextMenuItems([_fav_ctx('series', r['id'], favs)])
        items.append((url(action='seasons', id=r['id']), li, True))
    return items


_BUILDERS = {'live': lambda rows, q: _live_items(rows, as_guide=bool(q.get('guide'))),
             'movie': lambda rows, q: _movie_items(rows),
             'series': lambda rows, q: _series_items(rows)}
_CONTENT = {'live': 'videos', 'movie': 'movies', 'series': 'tvshows'}


def _listing(kind, rows, more, page, q, title, next_q):
    items = _BUILDERS[kind](rows, q)
    if more:
        items.append(_next(page + 1, **next_q))
    _end(items, _CONTENT[kind], title)


def _cat_list(kind, action, q):
    if not _ready([kind]):
        return
    rows, more, page = _paged(kind, cat=q.get('cat') or None, sort=catalog.sort_for(kind),
                              page=q.get('page'))
    nq = {'action': action, 'cat': q.get('cat', '')}
    if q.get('guide'):
        nq['guide'] = '1'
    _listing(kind, rows, more, page, q, kind_label(kind), nq)


def live_cat(q):
    _cat_list('live', 'live_cat', q)


def movies_cat(q):
    _cat_list('movie', 'movies_cat', q)


def series_cat(q):
    _cat_list('series', 'series_cat', q)


# ----------------------------------------------------------- EPG por canal
def epg_channel(q):
    if not _ready(['live']):
        return
    row = catalog.get('live', q.get('id'))
    if not row:
        _fail()
        return
    now = time.time()
    name = listing.display_name(row)
    progs = CORE.epg.schedule(row, hours=36, now=now)
    items = []
    li = xbmcgui.ListItem(_('Assistir ao vivo: %s') % name)
    listing.set_art(li, {'poster': row.get('icon')}, row.get('icon'))
    # abre o canal direto com o f4mTester (como no addon VIKING TV original)
    items.append((player.f4m_url_for_live(CORE.xt, row['id'], name, row.get('icon') or ''),
                  li, False))
    for s, e, t, d in progs:
        label = '%s-%s  %s' % (fmt_hm(s), fmt_hm(e), t)
        if s <= now < e:
            label += '  (%s)' % _('passando agora')
        li = xbmcgui.ListItem(label)
        listing.apply_video_info(li, {'title': t, 'plot': d or t, 'duration': max(0, e - s)})
        listing.set_art(li, {'poster': row.get('icon')}, row.get('icon'))
        li.setProperty('IsPlayable', 'false')
        items.append((url(action='noop'), li, False))
    if not progs:
        items.append(_action(_('Sem programação disponível para este canal'), 'ic-guide.png', action='noop'))
    _end(items, 'videos', name)


# ------------------------------------------------------------- séries
def _series_detail(sid):
    row = catalog.get('series', sid)
    if not row:
        return None, None
    busy(True)
    try:
        return row, CORE.meta.series_detail(row)
    finally:
        busy(False)


def seasons(q):
    if not _ready(['series']):
        return
    row, det = _series_detail(q.get('id'))
    if not det or not det['seasons']:
        notify(_('Nenhum episódio disponível.'))
        _fail()
        return
    if len(det['seasons']) == 1:            # achata a navegação: 1 temporada vai direto aos episódios
        return episodes({'id': row['id'], 'season': det['seasons'][0]['number']})
    info = det['info']
    items = []
    for s in det['seasons']:
        li = xbmcgui.ListItem('%s (%d)' % (s['name'], len(s['episodes'])))
        listing.apply_video_info(li, dict(info, title=s['name'], plot=s.get('plot') or info.get('plot'),
                                          tvshowtitle=info.get('title'), season=s['number']), 'season')
        listing.set_art(li, {'poster': s.get('poster') or info.get('poster'), 'fanart': info.get('fanart')},
                        row.get('icon'))
        items.append((url(action='episodes', id=row['id'], season=s['number']), li, True))
    _end(items, 'seasons', listing.display_name(row))


def episodes(q):
    if not _ready(['series']):
        return
    row, det = _series_detail(q.get('id'))
    if not det:
        _fail()
        return
    sn = int(q.get('season') or 0)
    season = next((s for s in det['seasons'] if s['number'] == sn), None)
    if not season:
        _fail()
        return
    info = det['info']
    busy(True)
    try:
        eps = CORE.meta.fill_episodes(info, season)
    finally:
        busy(False)
    watched = store.watched_ids('episode')
    items = []
    for e in eps:
        title = e['title'] or (_('Episódio %d') % e['num'])
        label = '%02d. %s' % (e['num'], title)
        li = xbmcgui.ListItem(label)
        ep_info = {
            'title': title, 'plot': e.get('plot') or info.get('plot'), 'duration': e.get('duration'),
            'rating': e.get('rating'), 'premiered': e.get('air'), 'season': sn, 'episode': e['num'],
            'tvshowtitle': info.get('title'), 'year': info.get('year')}
        if any(i in watched for i in listing.episode_ids(e)):
            ep_info['playcount'] = 1
        listing.apply_video_info(li, ep_info, 'episode')
        listing.set_art(li, {'poster': e.get('thumb') or info.get('poster'), 'fanart': info.get('fanart')},
                        row.get('icon'))
        li.setProperty('IsPlayable', 'true')
        items.append((url(action='play', kind='episode', id=e['id'], ext=e['ext'], title=label,
                          sid=row['id'], alts=listing.pack_alts(e)), li, False))
    _end(items, 'episodes', '%s - %s' % (listing.display_name(row), season['name']))


# ------------------------------------------------------------ reprodução
def play(q):
    kind, rid = q.get('kind'), q.get('id')
    res = None
    if kind == 'live':
        row = catalog.get('live', rid) or {}
        name = listing.display_name(row) if row else (q.get('title') or '')
        icon = row.get('icon') or ''
        # build_playable lança o f4mTester via RunPlugin (como no original)
        res = player.build_playable(CORE.xt, 'live', rid, '', name,
                                    {'thumb': icon, 'icon': icon}, {'title': name})
    elif kind == 'movie':
        row = catalog.get('movie', rid) or {}
        info = CORE.meta.quick(row, 'movie') if row else {}
        name = listing.display_name(row) if row else (q.get('title') or '')
        icon = row.get('icon') or ''
        ext = row.get('ext') or q.get('ext') or 'mp4'
        res = player.build_playable(
            CORE.xt, 'movie', rid, ext, name,
            {'thumb': icon, 'poster': icon, 'fanart': info.get('fanart') or FANART}, info,
            {'name': name, 'icon': icon, 'ext': ext})
    elif kind == 'episode':
        title = q.get('title') or ''
        srow = catalog.get('series', q.get('sid')) or {}
        icon = srow.get('icon') or ''
        res = player.build_playable(
            CORE.xt, 'episode', rid, q.get('ext') or 'mp4', title, {'thumb': icon, 'poster': icon},
            {'title': title, 'tvshowtitle': listing.display_name(srow) if srow else ''},
            {'name': '%s - %s' % (listing.display_name(srow), title) if srow else title,
             'icon': icon, 'ext': q.get('ext') or 'mp4', 'series_id': q.get('sid')},
            alts=listing.unpack_alts(q.get('alts')))
    if not res:
        _fail()
        return
    global _ENDED
    if res[1] is None:
        # Canal ao vivo: o f4mTester já foi lançado com RunPlugin — nada a
        # resolver por aqui (comportamento do addon VIKING TV original).
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    else:
        xbmcplugin.setResolvedUrl(HANDLE, True, res[1])
    _ENDED = True


# ---------------------------------------------- busca / favoritos / histórico
def search(q):
    kind = q.get('kind')
    term = q.get('q') or xbmcgui.Dialog().input(_('Buscar canais, filmes e séries') if kind not in KINDS
                                                else _('Buscar') + ' - ' + kind_label(kind),
                                                type=xbmcgui.INPUT_ALPHANUM)
    if not term:
        _fail()
        return
    if kind in KINDS:                       # busca dentro de uma seção: lista direto os resultados
        if not _ready([kind]):
            return
        if not catalog.items(kind, search=term, limit=1):
            notify(_('Nada encontrado para "%s"') % term)
            _fail()
            return
        return search_results({'kind': kind, 'q': term, 'page': '0'})
    if not _ready(list(KINDS)):
        return
    items = []
    for kind, icon in (('live', 'ic-live.png'), ('movie', 'ic-movies.png'), ('series', 'ic-series.png')):
        n = len(catalog.items(kind, search=term, limit=500))
        if n:
            items.append(_folder('%s (%d)' % (kind_label(kind), n), icon, action='search_results',
                                 kind=kind, q=term))
    if not items:
        notify(_('Nada encontrado para "%s"') % term)
        _fail()
        return
    _end(items, 'files', _('Busca: %s') % term)


def search_results(q):
    kind = q.get('kind')
    if kind not in KINDS or not _ready([kind]):
        return
    rows, more, page = _paged(kind, search=q.get('q'), sort=catalog.sort_for(kind), page=q.get('page'))
    _listing(kind, rows, more, page, q, _('Busca: %s') % q.get('q'),
             {'action': 'search_results', 'kind': kind, 'q': q.get('q')})


def favs(_q=None):
    if not _ready(list(KINDS)):
        return
    items = []
    for kind, icon in (('live', 'ic-live.png'), ('movie', 'ic-movies.png'), ('series', 'ic-series.png')):
        n = len(store.fav_ids(kind))
        items.append(_folder('%s (%d)' % (kind_label(kind), n), icon, action='fav_list', kind=kind))
    _end(items, 'files', _('Favoritos'))


def fav_list(q):
    kind = q.get('kind')
    if kind not in KINDS or not _ready([kind]):
        return
    rows = catalog.by_ids(kind, store.fav_ids(kind))
    _favorites_end(kind, rows, q)


def _favorites_end(kind, rows, q):
    _end(_BUILDERS[kind](rows, q), _CONTENT[kind], _('Favoritos'))


def fav(q):
    on = store.fav_toggle(q.get('kind'), q.get('id'))
    notify(_('Adicionado aos favoritos') if on else _('Removido dos favoritos'))
    xbmc.executebuiltin('Container.Refresh')


def continue_list(_q=None):
    rows = store.hist_continue()
    items = []
    for r in rows:
        name = r.get('name') or ''
        li = xbmcgui.ListItem(name)
        pct = int(100 * r['pos'] / r['total']) if r.get('total') else 0
        listing.apply_video_info(li, {'title': name, 'resume': r['pos'], 'total': r.get('total'),
                                      'plot': _('Parou em %s (%d%%)') % (player.fmt_clock(r['pos']), pct)},
                                 'movie' if r['kind'] == 'movie' else 'episode')
        listing.set_art(li, {'poster': r.get('icon')}, r.get('icon'))
        li.setProperty('IsPlayable', 'true')
        kind = 'movie' if r['kind'] == 'movie' else 'episode'
        items.append((url(action='play', kind=kind, id=r['id'], ext=r.get('ext') or 'mp4', title=name,
                          sid=r.get('series_id')), li, False))
    if not items:
        notify(_('Nada para continuar assistindo.'))
    _end(items, 'videos', _('Continuar assistindo'))


# ------------------------------------------------------------------ ações
def ui(_q=None):
    xbmc.executebuiltin('RunScript(%s)' % ADDON_ID)


def settings(_q=None):
    xbmcaddon.Addon(ADDON_ID).openSettings()


def test(_q=None):
    test_connection(CORE)


def sync(_q=None):
    if not CORE.xt.configured:
        _configure()
        return
    ensure_catalog(CORE, list(KINDS), force=True)


def refresh_all(_q=None):
    if not CORE.xt.configured:
        _configure()
        return
    if ensure_catalog(CORE, list(KINDS), force=True):
        refresh_epg(CORE)


def epg_refresh(_q=None):
    if not CORE.xt.configured:
        _configure()
        return
    refresh_epg(CORE)


def clear_cache_action(_q=None):
    if xbmcgui.Dialog().yesno(ADDON_NAME, _('Limpar catálogo, EPG e descrições em cache?\n'
                                            'Favoritos e histórico são mantidos.')):
        clear_cache()
        notify(_('Cache limpo.'))


def clear_hist(_q=None):
    if xbmcgui.Dialog().yesno(ADDON_NAME, _('Limpar a lista "Continuar assistindo"?')):
        store.hist_clear()
        notify(_('Histórico limpo.'))


def fullscreen(_q=None):
    if not player.fullscreen():
        notify(_('Nenhum vídeo em reprodução.'))


def noop(_q=None):
    pass


ROUTES = {
    '': root, 'menu': menu, 'live': live, 'live_cat': live_cat, 'guide': guide,
    'movies': movies, 'movies_cat': movies_cat, 'series': series, 'series_cat': series_cat,
    'seasons': seasons, 'episodes': episodes, 'epg_channel': epg_channel, 'play': play,
    'search': search, 'search_results': search_results, 'favs': favs, 'fav_list': fav_list,
    'fav': fav, 'continue': continue_list, 'ui': ui, 'settings': settings,
    'test': test, 'sync': sync, 'refresh_all': refresh_all,
    'epg_refresh': epg_refresh, 'clear_cache': clear_cache_action, 'clear_hist': clear_hist,
    'fullscreen': fullscreen, 'noop': noop,
}


def run(argv):
    global BASE, HANDLE, CORE, ACTION, _ENDED
    BASE = argv[0]
    try:
        HANDLE = int(argv[1])
    except (IndexError, ValueError):
        HANDLE = -1
    q = dict(parse_qsl(argv[2][1:])) if len(argv) > 2 and argv[2] else {}
    ACTION = q.get('action', '')
    _ENDED = False
    cfg_reload()
    try:
        CORE = Core()
        ROUTES.get(ACTION, root)(q)
    except Cancelled:
        _fail()
    except XtreamError as e:
        busy(False)
        xbmcgui.Dialog().ok(ADDON_NAME, str(e))
        _fail()
    except Exception:
        busy(False)
        log_exc('router action=%s' % ACTION)
        notify(_('Erro inesperado — veja o log do Kodi.'))
        _fail()
