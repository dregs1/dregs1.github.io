# -*- coding: utf-8 -*-
"""Serviço em segundo plano: mantém o EPG/catálogo atualizados e grava o progresso de
reprodução (alimenta 'Continuar assistindo') identificando o item pela URL em reprodução."""
import json
import threading
import time

import xbmc
import xbmcgui

from . import store
from .common import ADDON_ID, SB, cfg_reload, log, log_exc, to_int
from .db import kv_get
from .epg import Epg
from .player import NOW_PROP
from .xtream import Xtream


class Tracker(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.cur = None
        self.pos = 0.0
        self.total = 0.0

    def onAVStarted(self):
        self.cur = None
        try:
            playing = self.getPlayingFile()
            raw = xbmcgui.Window(10000).getProperty(NOW_PROP)
            now = json.loads(raw) if raw else None
        except Exception:
            return
        # Só reivindicamos o item se ele foi iniciado POR ESTE addon.
        # Window(10000) é global: outros addons instalados
        # compartilham as mesmas chaves xtreamplayer.now/current, então sem
        # este filtro cada Tracker atenderia eventos de playback dos outros.
        if now and now.get('addon') == ADDON_ID \
                and playing.split('|')[0] == now.get('base'):
            self.cur = now
            self.pos = float(now.get('offset') or 0)
            self.total = 0.0

    def tick(self):
        if not self.cur:
            return
        try:
            if not self.isPlayingVideo():
                return
            self.pos = self.getTime()
            self.total = self.getTotalTime()
        except Exception:
            return
        self._save(False)

    def _save(self, done):
        c = self.cur
        if not c:
            return
        if self.total and self.pos / self.total > 0.92:
            done = True
        store.hist_save(c['kind'], c['id'], self.pos, self.total, done, c.get('info'))

    def onPlayBackStopped(self):
        self._save(False)
        self.cur = None
        # Encerra TODOS os proxies locais imediatamente quando o usuário
        # aperta STOP (ou o playback é interrompido). Libera sockets, threads
        # e conexões upstream que ficariam pendurados até o próximo GC.
        try:
            from .player import stop_all_proxies
            stop_all_proxies()
        except Exception:
            log_exc('stop_all_proxies on stop')

    def onPlayBackEnded(self):
        # Tenta iniciar o próximo episódio automaticamente quando um episódio
        # termina naturalmente. Se conseguir, NÃO encerra os proxies (o novo
        # episódio abre seu próprio proxy via build_playable). Caso contrário,
        # segue o comportamento original e encerra tudo.
        ended = self.cur
        self._save(True)
        self.cur = None
        # Só atuamos se o item que terminou foi iniciado POR ESTE addon.
        # Sem este filtro, ao terminar um episódio neste addon os Trackers
        # do GIF PEG TV e DANIEL TV também receberiam onPlayBackEnded e cada
        # um tentaria tocar o "próximo" episódio — resultando em três
        # playbacks sobrepostos e três notificações na tela.
        if ended and ended.get('addon') == ADDON_ID and ended.get('kind') == 'episode':
            try:
                if self._try_autoplay_next(ended):
                    return
            except Exception:
                log_exc('autoplay next episode')
        # Sem próximo episódio (ou não era episódio deste addon): encerra os proxies.
        try:
            from .player import stop_all_proxies
            stop_all_proxies()
        except Exception:
            log_exc('stop_all_proxies on end')

    def _try_autoplay_next(self, ended):
        """Localiza o próximo episódio da mesma série/temporada e o inicia.

        `ended` é o dict que estava em self.cur (com 'kind','id','info',...).
        Devolve True se um novo episódio foi despachado para reprodução; False
        se não há próximo ou deu erro (o chamador então encerra os proxies).
        """
        from . import catalog, listing
        from . import player as player_mod
        from .core import Core
        from .i18n import _
        from .common import notify

        info = ended.get('info') or {}
        series_id = info.get('series_id')
        if not series_id:
            return False
        season = info.get('season')
        num = info.get('num')

        try:
            core = Core()
            srow = catalog.get('series', str(series_id))
            if not srow:
                log('autoplay: série %s não encontrada no catálogo' % series_id)
                return False
            det = core.meta.series_detail(srow)
        except Exception:
            log_exc('autoplay: series_detail')
            return False

        seasons = det.get('seasons') or []
        if not seasons:
            return False

        # Se a temporada/episódio não vieram no ident, procura pelo id.
        if season is None or num is None:
            for s in seasons:
                for e in s.get('episodes') or []:
                    if str(ended.get('id')) in listing.episode_ids(e):
                        season = s['number']
                        num = e['num']
                        break
                if season is not None:
                    break
            if season is None or num is None:
                log('autoplay: não localizei o episódio %s na série %s'
                    % (ended.get('id'), series_id))
                return False

        # Próximo episódio: mesma temporada, num+1. Se for o último, vai para
        # o primeiro episódio da próxima temporada.
        next_ep = None
        for i, s in enumerate(seasons):
            if s['number'] == season:
                eps = s.get('episodes') or []
                next_ep = next((e for e in eps if e['num'] == num + 1), None)
                if next_ep is None and i + 1 < len(seasons):
                    nxt_eps = seasons[i + 1].get('episodes') or []
                    if nxt_eps:
                        next_ep = nxt_eps[0]
                break
        if not next_ep:
            log('autoplay: nenhum episódio após T%02dE%02d em %s' % (season, num, series_id))
            return False

        # Monta o ListItem reproduzível para o próximo episódio (sem perguntar
        # retomar — começamos do início).
        try:
            icon = srow.get('icon') or ''
            series_name = listing.display_name(srow)
            title = next_ep.get('title') or (_('Episódio %d') % next_ep['num'])
            res = player_mod.build_playable(
                core.xt, 'episode', next_ep['id'], next_ep.get('ext') or 'mp4', title,
                {'thumb': next_ep.get('thumb') or icon, 'poster': icon},
                {'title': title, 'plot': next_ep.get('plot') or '',
                 'duration': next_ep.get('duration'), 'tvshowtitle': series_name,
                 'season': next_ep['season'], 'episode': next_ep['num']},
                {'name': '%s - T%02dE%02d' % (series_name, next_ep['season'], next_ep['num']),
                 'icon': icon, 'ext': next_ep.get('ext') or 'mp4',
                 'series_id': str(series_id),
                 'season': next_ep['season'], 'num': next_ep['num']},
                resume=False, alts=next_ep.get('alts'))
        except Exception:
            log_exc('autoplay: build_playable')
            return False
        if not res:
            return False

        url, li = res
        # Inicia em uma thread separada: dá tempo ao Kodi de encerrar
        # completamente o playback anterior antes de abrir o novo.
        def _go():
            xbmc.sleep(700)
            try:
                xbmc.Player().play(url, li)
                notify(_('Próximo episódio: %s') % title, ms=3000)
            except Exception:
                log_exc('autoplay: play()')
        t = threading.Thread(target=_go)
        t.daemon = True
        t.start()
        log('autoplay: despachado próximo episódio T%02dE%02d (%s)'
            % (next_ep['season'], next_ep['num'], next_ep['id']))
        return True

    def onPlayBackError(self):
        self.cur = None
        # Em caso de erro, também limpa os proxies para não deixar processos
        # zumbis rodando em segundo plano.
        try:
            from .player import stop_all_proxies
            stop_all_proxies()
        except Exception:
            log_exc('stop_all_proxies on error')


class _Monitor(xbmc.Monitor):
    def onSettingsChanged(self):
        cfg_reload()


def _refresh_job(flag, mon):
    try:
        cfg_reload()
        xt = Xtream()
        if not xt.configured:
            return
        for kind in ('live', 'movie', 'series'):        # só renova o que o usuário já usou
            if to_int(kv_get('sync_' + kind)) and xt.needs_sync(kind):
                xt.sync(kind, force=True)
        if SB('epg_enable', True) and SB('epg_auto', True):
            if not to_int(kv_get('sync_live')):
                xt.sync('live', force=True)             # o EPG filtra pelos canais do catálogo
            Epg(xt).refresh(force=False, abort=mon.abortRequested)
    except Exception:
        log_exc('service refresh')
    finally:
        flag['on'] = False


def run():
    mon = _Monitor()
    tracker = Tracker()
    flag = {'on': False}
    last = 0.0
    was_playing = False
    log('Serviço iniciado.')
    if mon.waitForAbort(30):
        return
    while not mon.abortRequested():
        tracker.tick()
        now = time.time()
        # Monitora o estado do player para encerrar os proxies IMEDIATAMENTE
        # quando o vídeo para.
        #
        # ATENÇÃO: isPlayingVideo() só retorna False DEPOIS que onPlayBackStopped
        # dispara — e esse callback pode demorar 40+ segundos porque o Kodi
        # espera os CCurlFile::Stat (HEAD) pendurados no proxy terminarem
        # (cada um com timeout de 20s).
        #
        # Por isso usamos Player.HasVideo (condição GUI) como sinal principal:
        # ela atualiza IMEDIATAMENTE quando o player fecha (CVideoPlayer::CloseFile),
        # sem esperar os timeouts do curl. Assim detectamos o stop em ~0.3s.
        try:
            playing = xbmc.getCondVisibility('Player.HasVideo')
        except Exception:
            try:
                playing = tracker.isPlayingVideo()
            except Exception:
                playing = False
        if was_playing and not playing:
            try:
                from .player import stop_all_proxies
                stop_all_proxies()
            except Exception:
                log_exc('stop_all_proxies (monitor)')
            was_playing = False
        elif playing:
            was_playing = True
        if now - last > 900 and not flag['on'] and not playing:
            last = now
            flag['on'] = True
            t = threading.Thread(target=_refresh_job, args=(flag, mon))
            t.daemon = True
            t.start()
        # Quando está tocando, checa a cada 0.3s para detectar o stop rápido.
        # Quando não está, checa a cada 10s (rotina de refresh do catálogo/EPG).
        interval = 0.3 if playing else 10
        if mon.waitForAbort(interval):
            break
    log('Serviço encerrado.')
