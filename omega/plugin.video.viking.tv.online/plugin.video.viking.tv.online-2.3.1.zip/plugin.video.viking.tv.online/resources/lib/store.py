# -*- coding: utf-8 -*-
"""Favoritos e histórico de reprodução (continuar assistindo)."""
import json
import time

from .db import db
from .i18n import _


# ----------------------------------------------------------------- favoritos
def fav_ids(kind):
    return [r['id'] for r in db().q('SELECT id FROM fav WHERE kind=? ORDER BY ts DESC', (kind,))]


def fav_has(kind, rid):
    return db().q1('SELECT 1 FROM fav WHERE kind=? AND id=?', (kind, str(rid))) is not None


def fav_toggle(kind, rid):
    """Alterna e devolve True se ficou favorito."""
    if fav_has(kind, rid):
        db().x('DELETE FROM fav WHERE kind=? AND id=?', (kind, str(rid)))
        return False
    db().x('INSERT OR REPLACE INTO fav(kind, id, ts) VALUES (?,?,?)', (kind, str(rid), int(time.time())))
    return True


# ------------------------------------------------------------------ histórico
def hist_save(kind, rid, pos, total, done, info):
    db().x('INSERT OR REPLACE INTO hist(kind, id, ts, pos, total, done, info) VALUES (?,?,?,?,?,?,?)',
           (kind, str(rid), int(time.time()), float(pos or 0), float(total or 0), 1 if done else 0,
            json.dumps(info or {}, ensure_ascii=False)))


def resume_point(kind, rid):
    """Segundos para retomar (0 = não há ponto de retomada útil)."""
    r = db().q1('SELECT pos, total, done FROM hist WHERE kind=? AND id=?', (kind, str(rid)))
    if not r or r['done'] or r['pos'] < 30:
        return 0
    if r['total'] and r['pos'] > r['total'] * 0.95:
        return 0
    return int(r['pos'])


def hist_continue(limit=60):
    out = []
    for r in db().q('SELECT * FROM hist WHERE done=0 AND pos>=30 ORDER BY ts DESC LIMIT ?', (limit,)):
        try:
            d = json.loads(r['info'] or '{}')
        except ValueError:
            d = {}
        d.update({'kind': r['kind'], 'id': r['id'], 'pos': r['pos'], 'total': r['total'],
                  'cat_name': _('Filmes') if r['kind'] == 'movie' else _('Séries')})
        d.setdefault('name', '')
        out.append(d)
    return out


def watched_ids(kind):
    """Conjunto de IDs (como strings) marcados como assistidos (done=1)."""
    return {r['id'] for r in db().q('SELECT id FROM hist WHERE kind=? AND done=1', (kind,))}


def hist_clear():
    db().x('DELETE FROM hist')
