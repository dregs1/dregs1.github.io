# -*- coding: utf-8 -*-
"""Interface estilo IBO em WindowXML.

Home com cards (TV, Filmes, Séries), canais em 'grade' (Passando agora / A seguir / Depois),
grade de pôsteres com painel de descrição, temporadas/episódios,
busca unificada (canais + filmes + séries) e botão para voltar ao vídeo em tela cheia.
Todos os dados vêm do SQLite local; descrições são buscadas em segundo plano ao focar.
"""
import os
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

from . import catalog, listing, player, store
from .common import (ADDON_ID, ADDON_NAME, ADDON_PATH, ADDON_VERSION, MEDIA, SB, Cancelled,
                     busy, cfg_reload, fmt_dur, fmt_hm, log_exc, notify, split_year)
from .core import (Core, account_summary, ensure_catalog, kind_label, refresh_epg, test_all_servers)
from .epg import summarize
from .i18n import _
from .xtream import XtreamError

UI_LIMIT = 2000
KINDS = ('live', 'movie', 'series')
CHIP = 300          # botão "Tela cheia" (visível só com vídeo em reprodução)
SEARCH = 301        # botão de busca no cabeçalho


def _a(name, default):
    return getattr(xbmcgui, name, default)


A_PREV = _a('ACTION_PREVIOUS_MENU', 10)
A_BACK = _a('ACTION_NAV_BACK', 92)
A_CONTEXT = _a('ACTION_CONTEXT_MENU', 117)
A_INFO = _a('ACTION_SHOW_INFO', 11)
A_RCLICK = _a('ACTION_MOUSE_RIGHT_CLICK', 101)

DETAIL_KEYS = ('title', 'meta', 'genre', 'plot', 'cast', 'poster', 'fanart', 'icon', 'time',
               'next', 'later', 'tag')


WEEKDAYS = ('segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado',
            'domingo')
MONTHS = ('janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro',
          'outubro', 'novembro', 'dezembro')


def clock_strings(now=None):
    """('21:05', 'sábado, 24 de outubro') — sempre em português do Brasil."""
    t = time.localtime(now)
    return '%02d:%02d' % (t.tm_hour, t.tm_min), '%s, %d de %s' % (WEEKDAYS[t.tm_wday], t.tm_mday,
                                                                    MONTHS[t.tm_mon - 1])


def set_clock(win, now=None):
    hm, date = clock_strings(now)
    win.setProperty('clock_time', hm)
    win.setProperty('clock_date', date)


def _make(cls, xml):
    return cls(xml, ADDON_PATH, 'Default', '1080i')


def _run(win):
    try:
        win.doModal()
    finally:
        win.closing = True


# ------------------------------------------------------------------ fontes
class DBSource(object):
    """Categorias do provedor (catálogo local)."""
    def __init__(self, kind, title):
        self.kind, self.title = kind, title

    def categories(self):
        cats = catalog.categories(self.kind)
        return [{'id': '', 'name': _('Todos'), 'count': sum(c['count'] for c in cats)}] + cats

    def items(self, cid):
        return catalog.items(self.kind, cat=cid or None, sort=catalog.sort_for(self.kind), limit=UI_LIMIT)


class ListSource(object):
    """Lista pronta (busca, favoritos, histórico) agrupada pelo nome da categoria."""
    def __init__(self, title, rows):
        self.title, self.rows = title, rows

    @staticmethod
    def _cat(r):
        return r.get('cat_name') or _('Sem categoria')

    def categories(self):
        order, counts = [], {}
        for r in self.rows:
            n = self._cat(r)
            if n not in counts:
                order.append(n)
                counts[n] = 0
            counts[n] += 1
        return [{'id': '', 'name': _('Todos'), 'count': len(self.rows)}] + \
               [{'id': n, 'name': n, 'count': counts[n]} for n in order]

    def items(self, cid):
        return list(self.rows) if not cid else [r for r in self.rows if self._cat(r) == cid]


class SeasonSource(object):
    """Temporadas de uma série; 'fill' completa os episódios (TMDB) ao abrir a temporada."""
    def __init__(self, title, seasons, fill):
        self.title, self.seasons, self.fill = title, seasons, fill

    def categories(self):
        return [{'id': s['number'], 'name': s['name'], 'count': len(s['episodes'])} for s in self.seasons]

    def items(self, cid):
        s = next((x for x in self.seasons if x['number'] == cid), None)
        return self.fill(s) if s else []


# ------------------------------------------------------------ busca unificada
def prepare_catalog(core, kinds):
    """Sincroniza o que falta; se a rede falhar mas já há dados locais, segue com eles."""
    ok = ensure_catalog(core, kinds)
    return ok or all(catalog.count(k) for k in kinds)


def search_rows(term, limit=300):
    """Canais + filmes + séries que casam com o termo; a 'categoria' vira o tipo (grupos na UI)."""
    out = []
    for kind in KINDS:
        rows = catalog.items(kind, search=term, sort=catalog.sort_for(kind), limit=limit)
        for r in rows:
            r['cat_name'] = kind_label(kind)
        out.extend(rows)
    return out


def do_search(core, term=None):
    """Pede o termo e abre os resultados (canais, filmes e séries) em uma única tela."""
    if term is None:
        term = xbmcgui.Dialog().input(_('Buscar canais, filmes e séries'), type=xbmcgui.INPUT_ALPHANUM)
    term = (term or '').strip()
    if not term or not prepare_catalog(core, KINDS):
        return
    rows = search_rows(term)
    if not rows:
        notify(_('Nada encontrado para "%s"') % term)
        return
    win = _make(GridWindow, 'ibo-grid.xml')
    win.core, win.source = core, ListSource(_('Busca: %s') % term, rows)
    _run(win)
    del win


# ------------------------------------------------------------------- base
class BrowseBase(xbmcgui.WindowXML):
    """Coluna de categorias (100) + lista/grade principal (200) + painel de detalhes."""
    CATS = 100
    MAIN = 200
    TICK = 0                 # segundos entre on_tick(); 0 = desligado
    core = None
    source = None
    closing = False

    # -- ciclo de vida
    def onInit(self):
        if getattr(self, '_ready', False):      # o Kodi chama onInit de novo ao voltar do player
            return
        self._ready = True
        self.cats_ctl = self.getControl(self.CATS)
        self.main_ctl = self.getControl(self.MAIN)
        self.rows, self.lis, self.cat_rows, self._cat_items = [], [], [], []
        self.cur_cat = None
        self.setProperty('title', self.source.title)
        set_clock(self)
        self.cat_rows = self.source.categories()
        for c in self.cat_rows:
            li = xbmcgui.ListItem(c['name'])
            li.setProperty('count', str(c.get('count', '')))
            li.setProperty('active', '')
            self._cat_items.append(li)
        self.cats_ctl.addItems(self._cat_items)
        if self.cat_rows:
            self.select_cat(0, focus=False)
        self.setFocusId(self.MAIN if self.rows else self.CATS)
        t = threading.Thread(target=self._watch)
        t.daemon = True
        t.start()

    def _selected(self):
        try:
            return self.main_ctl.getSelectedPosition()
        except Exception:
            return -1

    def _watch(self):
        """Seleção mudou: detalhe imediato + completo após 0,4 s parado. Também dispara o tick."""
        mon = xbmc.Monitor()
        last, stamp, pending = -2, 0.0, False
        tick_at = clock_at = time.time()
        full_busy = [False]

        def _full(p):
            """Detalhe completo (rede) em thread própria: a rolagem não trava enquanto a descrição carrega."""
            try:
                if not self.closing:
                    self.on_select_full(p)
            except Exception:
                log_exc('on_select_full')
            finally:
                full_busy[0] = False
        while not self.closing and not mon.abortRequested():
            if time.time() - clock_at >= 20:
                clock_at = time.time()
                set_clock(self)
            pos = self._selected()
            if pos != last:
                last, stamp, pending = pos, time.time(), True
                try:
                    self.on_select(pos)
                except Exception:
                    log_exc('on_select')
            elif pending and time.time() - stamp > 0.4 and not full_busy[0]:
                pending = False
                full_busy[0] = True
                threading.Thread(target=_full, args=(pos,), daemon=True).start()
            if self.TICK and time.time() - tick_at >= self.TICK:
                tick_at = time.time()
                try:
                    self.on_tick()
                except Exception:
                    log_exc('on_tick')
            mon.waitForAbort(0.12)

    # -- categorias / itens
    def select_cat(self, pos, focus=True):
        if not (0 <= pos < len(self.cat_rows)):
            return
        self.cur_cat = self.cat_rows[pos]['id']
        for i, li in enumerate(self._cat_items):
            li.setProperty('active', '1' if i == pos else '')
        busy(True)
        try:
            self.rows = self.source.items(self.cur_cat)
            self.lis = self.build_items(self.rows)
            self.main_ctl.reset()
            self.main_ctl.addItems(self.lis)
            if self.lis:
                self.main_ctl.selectItem(0)
        finally:
            busy(False)
        self.setProperty('count', (_('%d itens') % len(self.rows)) + ('+' if len(self.rows) >= UI_LIMIT else ''))
        self.on_select(0 if self.rows else -1)
        if focus and self.rows:
            self.setFocusId(self.MAIN)

    def details(self, **kv):
        for k in DETAIL_KEYS:
            self.setProperty('d_' + k, str(kv.get(k) or ''))

    # -- ganchos das subclasses
    def build_items(self, rows):
        return []

    def on_select(self, pos):
        pass

    def on_select_full(self, pos):
        pass

    def on_tick(self):
        pass

    def activate(self, row):
        pass

    def menu_options(self, row):
        return []

    # -- eventos
    def onClick(self, cid):
        try:
            if cid == self.CATS:
                self.select_cat(self.cats_ctl.getSelectedPosition())
            elif cid == self.MAIN:
                pos = self.main_ctl.getSelectedPosition()
                if 0 <= pos < len(self.rows):
                    self.activate(self.rows[pos])
            elif cid == SEARCH:
                do_search(self.core)
            elif cid == CHIP:
                self.back_to_video()
        except Cancelled:
            busy(False)
        except Exception:
            busy(False)
            log_exc('onClick')
            notify(_('Erro inesperado — veja o log do Kodi.'))

    def onAction(self, action):
        aid = action.getId()
        try:
            fid = self.getFocusId()
        except Exception:
            fid = 0
        if aid in (A_PREV, A_BACK):
            if fid in (CHIP, SEARCH):
                self.setFocusId(self.MAIN if self.rows else self.CATS)
            elif fid == self.MAIN and self.cat_rows:
                self.setFocusId(self.CATS)
            else:
                self.close()
        elif aid in (A_CONTEXT, A_RCLICK) and fid == self.MAIN:
            self.context_menu()
        elif aid == A_INFO and player.video_playing():
            self.back_to_video()                # tecla Info = voltar ao vídeo em tela cheia

    def back_to_video(self):
        if not player.fullscreen():
            notify(_('Nenhum vídeo em reprodução.'))

    def context_menu(self):
        pos = self.main_ctl.getSelectedPosition()
        if not (0 <= pos < len(self.rows)):
            return
        opts = self.menu_options(self.rows[pos])
        idx = xbmcgui.Dialog().contextmenu([o[0] for o in opts])
        if idx >= 0:
            try:
                opts[idx][1]()
            except Cancelled:
                pass
            except Exception:
                busy(False)
                log_exc('context_menu')

    def toggle_fav(self, kind, row, li=None):
        on = store.fav_toggle(kind, row['id'])
        if li is not None:
            li.setProperty('fav', '1' if on else '')
        notify(_('Adicionado aos favoritos') if on else _('Removido dos favoritos'))

    def _selected_li(self):
        pos = self._selected()
        return self.lis[pos] if 0 <= pos < len(self.lis) else None

    def _play(self, res):
        if not res:
            return
        if res[1] is None:
            # Canal ao vivo: o f4mTester já foi lançado via RunPlugin dentro
            # de build_playable (como no addon VIKING TV original).
            return
        xbmc.Player().play(res[0], res[1])

    # -- canais (usado pela grade de canais e pelos resultados de busca)
    def play_live(self, row, progs=None):
        if player.is_current('live', row['id']):      # já está tocando: só volta à tela cheia
            player.fullscreen()
            return
        name = listing.display_name(row)
        icon = row.get('icon') or ''
        if progs is None:
            progs = self.core.epg.for_items([row], n=3).get(row['id'], [])
        self._play(player.build_playable(self.core.xt, 'live', row['id'], '', name,
                                         {'thumb': icon, 'icon': icon},
                                         {'title': name, 'plot': listing.epg_plot(progs)}))

    def show_schedule(self, row):
        busy(True)
        try:
            progs = self.core.epg.schedule(row, hours=36)
        finally:
            busy(False)
        if not progs:
            notify(_('Sem programação disponível para este canal.'))
            return
        now = time.time()
        labels = [_('Assistir ao vivo')] + [
            '%s-%s  %s%s' % (fmt_hm(s), fmt_hm(e), t, ('  (%s)' % _('passando agora')) if s <= now < e else '')
            for s, e, t, d in progs]
        while True:
            idx = xbmcgui.Dialog().select(listing.display_name(row), labels)
            if idx < 0:
                return
            if idx == 0:
                self.play_live(row)
                return
            s, e, t, d = progs[idx - 1]
            xbmcgui.Dialog().textviewer(t, '%s - %s\n\n%s' % (fmt_hm(s), fmt_hm(e),
                                                              d or _('Sem descrição para este programa.')))


# ------------------------------------------------------------ canais (grade)
class LiveWindow(BrowseBase):
    guide = False
    progs = {}
    TICK = 30                # a cada 30 s confere se algum programa terminou ("Passando agora" muda)

    def build_items(self, rows):
        now = time.time()
        self.progs = self.core.epg.for_items(rows, n=3, now=now) if SB('epg_enable', True) else {}
        self._last, self._reloaded = {}, now
        favs = set(store.fav_ids('live'))
        lis = []
        for i, r in enumerate(rows):
            li = xbmcgui.ListItem(listing.display_name(r))
            icon = r.get('icon') or ''
            li.setArt({'thumb': icon, 'icon': icon})
            li.setProperty('num', str(r.get('num') or i + 1))
            li.setProperty('fav', '1' if r['id'] in favs else '')
            progs = self.progs.get(r['id'], [])
            self._epg_props(li, progs, now)
            self._last[i] = self._key(progs, now)
            lis.append(li)
        return lis

    @staticmethod
    def _key(progs, now):
        """Identifica o que está em "Passando agora" e "A seguir" (muda quando um programa termina)."""
        sm = summarize(progs or [], now)
        return (sm['now'][0] if sm['now'] else 0, sm['next'][0] if sm['next'] else 0)

    @staticmethod
    def _epg_props(li, progs, now):
        sm = summarize(progs, now)
        cur, nxt, lat = sm['now'], sm['next'], sm['later']
        li.setProperty('now_title', cur[2] if cur else '')
        li.setProperty('now_time', '%s - %s' % (fmt_hm(cur[0]), fmt_hm(cur[1])) if cur else '')
        li.setProperty('next_title', nxt[2] if nxt else '')
        li.setProperty('next_time', fmt_hm(nxt[0]) if nxt else '')
        li.setProperty('later_title', lat[2] if lat else '')
        li.setProperty('later_time', fmt_hm(lat[0]) if lat else '')

    def _show(self, row, progs, now=None):
        now = now or time.time()
        sm = summarize(progs, now)
        cur, nxt, lat = sm['now'], sm['next'], sm['later']
        name = listing.display_name(row)
        if cur:
            meta = '%s  \u2022  %s - %s' % (name, fmt_hm(cur[0]), fmt_hm(cur[1]))
            plot = cur[3] or _('Sem descrição para este programa.')
        else:
            meta = name
            plot = _('Sem informações de programação para este canal.')
        self.details(title=cur[2] if cur else name, meta=meta, plot=plot, icon=row.get('icon'),
                     tag=_('Passando agora').upper() if cur else '',
                     next='%s  %s' % (fmt_hm(nxt[0]), nxt[2]) if nxt else '',
                     later='%s  %s' % (fmt_hm(lat[0]), lat[2]) if lat else '')

    def on_select(self, pos):
        if not (0 <= pos < len(self.rows)):
            self.details()
            return
        r = self.rows[pos]
        self._show(r, self.progs.get(r['id'], []))

    def on_select_full(self, pos):
        """Sem EPG local para o canal? Pede ao painel (get_short_epg) e atualiza a linha."""
        if not SB('epg_enable', True) or not (0 <= pos < len(self.rows)):
            return
        r = self.rows[pos]
        if self.progs.get(r['id']):
            return
        progs = self.core.epg.schedule(r, hours=12)[:3]
        if not progs:
            return
        now = time.time()
        self.progs[r['id']] = progs
        if pos < len(self.lis):
            self._epg_props(self.lis[pos], progs, now)
            self._last[pos] = self._key(progs, now)
        if self._selected() == pos:
            self._show(r, progs, now)

    # -- troca de programa quando o atual termina --------------------------------
    def _needs_reload(self, now):
        """Algum canal ficou com menos de 2 programas futuros (rolou programação)?"""
        for progs in list(self.progs.values()):
            if len(progs) >= 3 and len([p for p in progs if p[1] > now]) < 2:
                return True
        return False

    def on_tick(self, now=None):
        """Quando um programa termina, a linha passa a mostrar o seguinte em "Passando agora"."""
        rows, lis, last = self.rows, self.lis, self._last      # cópias locais: a UI pode trocar de categoria
        if not rows or not lis or not SB('epg_enable', True):
            return
        now = now or time.time()
        if now - self._reloaded >= 60 and self._needs_reload(now):
            self._reloaded = now
            self.progs.update(self.core.epg.for_items(rows, n=3, now=now))
        sel = self._selected()
        sel_changed = False
        for i, r in enumerate(rows[:len(lis)]):
            progs = self.progs.get(r['id'])
            if not progs:
                continue
            key = self._key(progs, now)
            if key == last.get(i):
                continue
            last[i] = key
            self._epg_props(lis[i], progs, now)
            sel_changed = sel_changed or i == sel
        if sel_changed and rows is self.rows and 0 <= sel < len(rows):
            self._show(rows[sel], self.progs.get(rows[sel]['id'], []), now)

    def activate(self, row):
        if self.guide:
            self.show_schedule(row)
        else:
            self.play_live(row, self.progs.get(row['id'], []))

    def menu_options(self, row):
        li = self._selected_li()
        faved = bool(li is not None and li.getProperty('fav'))
        return [
            (_('Assistir ao vivo'), lambda: self.play_live(row, self.progs.get(row['id'], []))),
            (_('Programação completa'), lambda: self.show_schedule(row)),
            (_('Remover dos favoritos') if faved else _('Adicionar aos favoritos'),
             lambda: self.toggle_fav('live', row, li)),
        ]


# ------------------------------------------------- filmes / séries (pôsteres)
class GridWindow(BrowseBase):
    """Grade de pôsteres; também mostra canais (resultados de busca/favoritos) e histórico."""

    def build_items(self, rows):
        favs = {k: set(store.fav_ids(k)) for k in KINDS}
        watched = {k: store.watched_ids(k) for k in ('movie', 'episode')}
        lis = []
        for r in rows:
            name = listing.display_name(r)
            li = xbmcgui.ListItem(name)
            icon = r.get('icon') or ''
            li.setArt({'poster': icon, 'thumb': icon, 'icon': icon})
            _t, year = split_year(name)
            li.setProperty('year', str(year or ''))
            li.setProperty('rating', '%.1f' % r['rating'] if r.get('rating') else '')
            li.setProperty('fav', '1' if r['id'] in favs.get(r['kind'], ()) else '')
            li.setProperty('is_live', '1' if r['kind'] == 'live' else '')
            if r['kind'] in ('movie', 'episode') and str(r['id']) in watched.get(r['kind'], ()):
                li.setProperty('watched', '1')
            if r.get('total'):
                li.setProperty('prog', str(int(100 * r['pos'] / r['total'])))
            lis.append(li)
        return lis

    def _show(self, row, info, loading=False):
        name = listing.display_name(row)
        bits = [str(info.get('year') or ''), fmt_dur(info.get('duration')),
                ('\u2605 %.1f' % info['rating']) if info.get('rating') else '', info.get('mpaa') or '']
        plot = info.get('plot') or (_('Carregando descrição…') if loading else _('Sem descrição disponível.'))
        cast = ', '.join(c['name'] for c in (info.get('cast') or [])[:6])
        self.details(title=name, meta='  \u2022  '.join(b for b in bits if b),
                     genre=', '.join(info.get('genres') or []), plot=plot, cast=cast,
                     poster=info.get('poster') or row.get('icon'), fanart=info.get('fanart'))

    def _show_live(self, row, progs):
        sm = summarize(progs, time.time())
        cur = sm['now']
        meta = _('Canal ao vivo')
        if cur:
            meta += '  \u2022  %s - %s' % (fmt_hm(cur[0]), fmt_hm(cur[1]))
        self.details(title=listing.display_name(row), meta=meta,
                     plot=listing.epg_plot(progs) or _('Sem informações de programação para este canal.'),
                     poster=row.get('icon'), icon=row.get('icon'))

    def on_select(self, pos):
        if not (0 <= pos < len(self.rows)):
            self.details()
            return
        r = self.rows[pos]
        if r['kind'] == 'episode':
            self.details(title=r.get('name'), meta=_('Parou em %s') % player.fmt_clock(r.get('pos') or 0),
                         plot=_('Continue de onde parou.'), poster=r.get('icon'), fanart=r.get('icon'))
        elif r['kind'] == 'live':
            self._show_live(r, self.core.epg.for_items([r], n=3).get(r['id'], []))
        else:
            info = self.core.meta.quick(r, r['kind'])
            self._show(r, info, loading=not info.get('plot'))

    def on_select_full(self, pos):
        if not (0 <= pos < len(self.rows)):
            return
        r = self.rows[pos]
        kind = r['kind']
        if kind == 'episode':
            return
        if kind == 'live':
            if SB('epg_enable', True) and not self.core.epg.for_items([r], n=1).get(r['id']):
                progs = self.core.epg.schedule(r, hours=6)[:3]
                if progs and self._selected() == pos:
                    self._show_live(r, progs)
            return
        if self.core.meta.cached(r, kind):
            return
        info = self.core.meta.movie(r) if kind == 'movie' else self.core.meta.series(r)
        if self._selected() == pos:
            self._show(r, info)

    def activate(self, row):
        kind = row['kind']
        if kind == 'live':
            self.play_live(row)
        elif kind == 'movie':
            self.play_movie(row)
        elif kind == 'series':
            self.open_series(row)
        elif kind == 'episode':
            self.play_saved(row)

    def play_movie(self, row):
        if player.is_current('movie', row['id']):
            player.fullscreen()
            return
        info = self.core.meta.quick(row, 'movie')
        name = listing.display_name(row)
        icon = row.get('icon') or ''
        ext = row.get('ext') or 'mp4'
        self._play(player.build_playable(
            self.core.xt, 'movie', row['id'], ext, name,
            {'thumb': icon, 'poster': icon, 'fanart': info.get('fanart') or ''}, info,
            {'name': name, 'icon': icon, 'ext': ext}))

    def play_saved(self, row):
        """Item de 'Continuar assistindo' (filme ou episódio) a partir do histórico."""
        kind = 'movie' if row.get('kind') == 'movie' else 'episode'
        if player.is_current(kind, row['id']):
            player.fullscreen()
            return
        name, icon, ext = row.get('name') or '', row.get('icon') or '', row.get('ext') or 'mp4'
        self._play(player.build_playable(
            self.core.xt, kind, row['id'], ext, name, {'thumb': icon, 'poster': icon}, {'title': name},
            {'name': name, 'icon': icon, 'ext': ext, 'series_id': row.get('series_id')}))

    def open_series(self, row):
        busy(True)
        try:
            det = self.core.meta.series_detail(row)
        except XtreamError as e:
            busy(False)
            notify(str(e))
            return
        finally:
            busy(False)
        if not det['seasons']:
            notify(_('Nenhum episódio disponível.'))
            return
        win = _make(EpisodesWindow, 'ibo-episodes.xml')
        win.core, win.row, win.detail = self.core, row, det
        win.source = SeasonSource(listing.display_name(row), det['seasons'],
                                  lambda s: self.core.meta.fill_episodes(det['info'], s))
        _run(win)
        del win

    def full_info(self, row):
        info = self.core.meta.movie(row) if row['kind'] == 'movie' else self.core.meta.series(row)
        lines = [info.get('tagline') or '', info.get('plot') or _('Sem descrição disponível.'), '']
        if info.get('genres'):
            lines.append('%s: %s' % (_('Gêneros'), ', '.join(info['genres'])))
        if info.get('directors'):
            lines.append('%s: %s' % (_('Direção'), ', '.join(info['directors'])))
        if info.get('cast'):
            lines.append('%s: %s' % (_('Elenco'), ', '.join(c['name'] for c in info['cast'][:12])))
        xbmcgui.Dialog().textviewer(listing.display_name(row), '\n'.join(lines))

    def menu_options(self, row):
        li = self._selected_li()
        kind = row['kind']
        faved = bool(li is not None and li.getProperty('fav'))
        fav_label = _('Remover dos favoritos') if faved else _('Adicionar aos favoritos')
        if kind == 'live':
            return [(_('Assistir ao vivo'), lambda: self.play_live(row)),
                    (_('Programação completa'), lambda: self.show_schedule(row)),
                    (fav_label, lambda: self.toggle_fav('live', row, li))]
        opts = [(_('Abrir') if kind == 'series' else _('Reproduzir'), lambda: self.activate(row))]
        if kind in ('movie', 'series'):
            opts.append((fav_label, lambda: self.toggle_fav(kind, row, li)))
            opts.append((_('Sinopse completa'), lambda: self.full_info(row)))
        return opts


# --------------------------------------------------- temporadas / episódios
class EpisodesWindow(BrowseBase):
    row = None
    detail = None

    def build_items(self, rows):
        info = self.detail['info']
        watched = store.watched_ids('episode')
        lis = []
        for e in rows:
            title = e['title'] or (_('Episódio %d') % e['num'])
            li = xbmcgui.ListItem('%02d. %s' % (e['num'], title))
            thumb = e.get('thumb') or info.get('poster') or ''
            li.setArt({'thumb': thumb, 'icon': thumb})
            li.setProperty('ep_num', 'E%02d' % e['num'])
            li.setProperty('ep_meta', '  \u2022  '.join(b for b in (fmt_dur(e.get('duration')), e.get('air') or '') if b))
            if any(i in watched for i in listing.episode_ids(e)):
                li.setProperty('watched', '1')
            lis.append(li)
        return lis

    def on_select(self, pos):
        info = self.detail['info']
        if not (0 <= pos < len(self.rows)):
            self.details(title=listing.display_name(self.row), plot=info.get('plot'),
                         poster=info.get('poster'), fanart=info.get('fanart'))
            return
        e = self.rows[pos]
        title = e['title'] or (_('Episódio %d') % e['num'])
        bits = ['T%02d E%02d' % (e['season'], e['num']), fmt_dur(e.get('duration')), e.get('air') or '',
                ('\u2605 %.1f' % e['rating']) if e.get('rating') else '']
        self.details(title=title, meta='  \u2022  '.join(b for b in bits if b),
                     genre=', '.join(info.get('genres') or []),
                     plot=e.get('plot') or info.get('plot') or _('Sem descrição disponível.'),
                     poster=e.get('thumb') or info.get('poster'),
                     fanart=info.get('fanart') or e.get('thumb'))

    def activate(self, e):
        if any(player.is_current('episode', i) for i in listing.episode_ids(e)):
            player.fullscreen()
            return
        info = self.detail['info']
        title = e['title'] or (_('Episódio %d') % e['num'])
        icon = self.row.get('icon') or ''
        series_name = listing.display_name(self.row)
        label = '%s - T%02dE%02d' % (series_name, e['season'], e['num'])
        self._play(player.build_playable(
            self.core.xt, 'episode', e['id'], e.get('ext') or 'mp4', title,
            {'thumb': e.get('thumb') or icon, 'poster': icon},
            {'title': title, 'plot': e.get('plot') or info.get('plot'), 'duration': e.get('duration'),
             'tvshowtitle': series_name, 'season': e['season'], 'episode': e['num']},
            {'name': '%s: %s' % (label, title), 'icon': icon, 'ext': e.get('ext') or 'mp4',
             'series_id': self.row['id'], 'season': e['season'], 'num': e['num']},
            alts=e.get('alts')))

    def menu_options(self, row):
        return [(_('Reproduzir'), lambda: self.activate(row))]


# ------------------------------------------------------------------- home
class HomeWindow(xbmcgui.WindowXML):
    core = None
    closing = False

    def onInit(self):
        if getattr(self, '_ready', False):
            return
        self._ready = True
        self.setProperty('version', 'v' + ADDON_VERSION)
        self.setProperty('acct_line', _('Conectando…'))
        set_clock(self)
        self._counts()
        self.setFocusId(101)
        self._bg_account()
        t = threading.Thread(target=self._clock_loop)
        t.daemon = True
        t.start()

    def _clock_loop(self):
        mon = xbmc.Monitor()
        while not self.closing and not mon.abortRequested():
            if mon.waitForAbort(20):
                break
            set_clock(self)

    def _bg_account(self):
        t = threading.Thread(target=self._load_account)
        t.daemon = True
        t.start()

    def _counts(self):
        for kind, prop, fmt in (('live', 'cnt_live', _('%d canais')), ('movie', 'cnt_movie', _('%d filmes')),
                                ('series', 'cnt_series', _('%d séries'))):
            n = catalog.count(kind)
            self.setProperty(prop, fmt % n if n else '')

    def _load_account(self):
        try:
            self.setProperty('acct_line', account_summary(self.core.xt.user_info(force=True)))
        except XtreamError as e:
            self.setProperty('acct_line', str(e))
            return
        except Exception:
            log_exc('account')
            return
        try:                                    # EPG vencido? atualiza em segundo plano
            if SB('epg_enable', True) and SB('epg_auto', True) and catalog.count('live') \
                    and self.core.epg.due():
                self.core.epg.refresh(force=False)
        except Exception:
            log_exc('epg bg')

    # -- navegação
    def onAction(self, action):
        aid = action.getId()
        if aid in (A_PREV, A_BACK):
            try:
                fid = self.getFocusId()
            except Exception:
                fid = 0
            if fid in (CHIP, SEARCH):
                self.setFocusId(101)
            else:
                self.close()
        elif aid == A_INFO and player.video_playing():
            self.back_to_video()

    def back_to_video(self):
        if not player.fullscreen():
            notify(_('Nenhum vídeo em reprodução.'))

    def onClick(self, cid):
        handler = {101: lambda: self.open_live(False), 102: lambda: self.open_vod('movie'),
                   103: lambda: self.open_vod('series'), 201: lambda: self.open_live(True),
                   202: self.open_favorites, 203: self.open_continue, 204: self.open_search,
                   205: self.refresh_menu, 206: self.open_settings,
                   207: self.open_server_select,
                   SEARCH: self.open_search, CHIP: self.back_to_video}.get(cid)
        if not handler:
            return
        try:
            handler()
        except Cancelled:
            busy(False)
        except XtreamError as e:
            busy(False)
            xbmcgui.Dialog().ok(ADDON_NAME, str(e))
        except Exception:
            busy(False)
            log_exc('home click %s' % cid)
            notify(_('Erro inesperado — veja o log do Kodi.'))

    def _prepare(self, kinds):
        ok = prepare_catalog(self.core, kinds)
        self._counts()
        return ok

    def _show(self, cls, xml, source, **attrs):
        win = _make(cls, xml)
        win.core, win.source = self.core, source
        for k, v in attrs.items():
            setattr(win, k, v)
        _run(win)
        del win

    def open_live(self, guide):
        if self._prepare(['live']):
            self._show(LiveWindow, 'ibo-live.xml',
                       DBSource('live', _('Guia de programação') if guide else _('TV ao vivo')), guide=guide)

    def open_vod(self, kind):
        if self._prepare([kind]):
            self._show(GridWindow, 'ibo-grid.xml', DBSource(kind, kind_label(kind)))

    def _open_rows(self, kind, rows, title):
        if kind == 'live':
            self._show(LiveWindow, 'ibo-live.xml', ListSource(title, rows))
        else:
            self._show(GridWindow, 'ibo-grid.xml', ListSource(title, rows))

    def open_favorites(self):
        if not self._prepare(list(KINDS)):
            return
        idx = xbmcgui.Dialog().select(_('Favoritos'), ['%s (%d)' % (kind_label(k), len(store.fav_ids(k)))
                                                       for k in KINDS])
        if idx < 0:
            return
        kind = KINDS[idx]
        rows = catalog.by_ids(kind, store.fav_ids(kind))
        if not rows:
            notify(_('Nenhum favorito aqui ainda.'))
            return
        self._open_rows(kind, rows, '%s - %s' % (_('Favoritos'), kind_label(kind)))

    def open_continue(self):
        rows = store.hist_continue()
        if not rows:
            notify(_('Nada para continuar assistindo.'))
            return
        self._show(GridWindow, 'ibo-grid.xml', ListSource(_('Continuar assistindo'), rows))

    def open_search(self):
        do_search(self.core)
        self._counts()

    def refresh_menu(self):
        idx = xbmcgui.Dialog().select(_('Atualizar'), [_('Catálogo (canais, filmes e séries)'),
                                                       _('Guia de programação (EPG)'), _('Tudo')])
        if idx in (0, 2):
            ensure_catalog(self.core, list(KINDS), force=True)
            self._counts()
        if idx in (1, 2):
            refresh_epg(self.core)

    def open_settings(self):
        xbmcaddon.Addon(ADDON_ID).openSettings()
        cfg_reload()
        self.core = Core()
        self._counts()
        self._bg_account()

    # ----------------------------------------------------- seleção de servidor
    def open_server_select(self):
        """Abre o diálogo de status dos servidores (ON verde / OFF vermelho com
        ícones) e aplica o servidor escolhido. A URL host fica oculta; só
        aparecem 'Servidor 1', 'Servidor 2', ... com o status de cada um."""
        new_idx = _server_status_dialog(self.core)
        if not new_idx:
            return
        if new_idx == self.core.xt.active_server:
            notify(_('Servidor atual: %s') % ('Servidor %d' % new_idx))
            return
        # aplica e persiste a escolha (banco local) e recria o contexto no
        # novo servidor (o Xtream detecta a troca de conta e limpa o cache)
        self.core.xt.set_active_server(new_idx)
        self.core = Core()
        self._counts()
        self._bg_account()
        notify(_('Servidor selecionado: %s') % ('Servidor %d' % new_idx))


def _server_status_dialog(core):
    """Testa todos os servidores do link de credenciais em paralelo e exibe um
    diálogo com a lista de servidores mostrando ON (verde, ícone de check) para
    os ativos e OFF (vermelho, ícone de X) para os expirados/sem conexão.
    Selecionar um servidor ativa-o. Voltar/Esc cancela.
    Devolve o índice (1-based) do servidor selecionado ou None se cancelado.
    """
    if not core.xt.cred_url:
        notify(_('Link de credenciais não configurado (CRED_URL no default.py do addon).'))
        return None
    busy(True)
    try:
        results = test_all_servers(core)
    except Exception:
        busy(False)
        log_exc('server_status_dialog')
        return None
    finally:
        try:
            busy(False)
        except Exception:
            pass
    if not results:
        notify(_('Nenhum servidor disponível no link de credenciais.'))
        return None
    on_icon = os.path.join(MEDIA, 'ibo-on.png')
    off_icon = os.path.join(MEDIA, 'ibo-off.png')
    cur = max(1, core.xt.active_server)
    items = []
    for i, (srv, ok, expired, label) in enumerate(results, 1):
        prefix = '[COLOR FF22C55E][B]ON[/B][/COLOR]  ' if ok \
            else '[COLOR FFFF3B3B][B]OFF[/B][/COLOR]  '
        suffix = '  (%s)' % _('ativo') if i == cur else ''
        name = '%sServidor %d - %s%s' % (prefix, i, label, suffix)
        li = xbmcgui.ListItem(name)
        icon = on_icon if ok else off_icon
        li.setArt({'icon': icon, 'thumb': icon})
        items.append(li)
    pre = max(0, min(cur - 1, len(items) - 1))
    idx = xbmcgui.Dialog().select(_('Status dos servidores'), items, preselect=pre,
                                  useDetails=True)
    if idx < 0:
        return None
    return idx + 1


def launch():
    cfg_reload()
    core = Core()
    if not core.xt.configured:
        # Tenta forçar uma busca fresca do link remoto fixo (CRED_URL no
        # default.py, como no addon VIKING TV original).
        try:
            core.xt.reload_credentials()
        except Exception:
            log_exc('launch reload_credentials')
        if not core.xt.configured:
            xbmcgui.Dialog().ok(ADDON_NAME,
                                _('Não foi possível carregar as credenciais do link remoto '
                                  'fixo do addon.\n\n'
                                  'Verifique sua conexão com a internet e tente novamente.\n'
                                  '(O link é configurado no default.py do addon).'))
            return
    win = _make(HomeWindow, 'ibo-home.xml')
    win.core = core
    _run(win)
    del win
