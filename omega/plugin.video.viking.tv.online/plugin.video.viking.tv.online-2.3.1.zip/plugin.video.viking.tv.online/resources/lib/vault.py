# -*- coding: utf-8 -*-
"""Cofre de dados sensíveis gravados nas pastas do Kodi (addon_data).

O addon precisa guardar em disco, como fallback offline, a última lista
de servidores/credenciais baixada do link remoto (kv ``cred_json`` no
SQLite ``xtreamplayer.db``) e o cache DNS. Antes disso ficava em TEXTO
PURO dentro de ``userdata/addon_data/`` — qualquer pessoa (ou outro
addon/script) que lesse a pasta viajia com usuário e senha.

Agora tudo passa por este cofre: os dados são cifrados com uma cifra de
fluxo (keystream SHA-256 encadeada com nonce aleatório) e só voltam a
existir em claro dentro da memória do processo. O valor gravado no
banco/carquivo é uma string opaca com prefixo ``VGs1:`` — sem usuário,
sem senha, sem link legível.

Formato gravado:  VGs1:<base64(nonce(8) + texto XOR keystream)>

dec() aceita valores antigos em texto puro (migração transparente:
na próxima gravação o dado já é regravado cifrado).
"""
import base64
import hashlib
import os

# Prefixo que marca o dado como cifrado pelo cofre.
MARKER = 'VGs1:'

# Sais fixos, embaralhados — só existem no código, nunca em disco.
_SALT_A = 'b14cK-34gL3-v1k1N9'
_SALT_B = 'dregs1.vikings.repo.2077'
_SALT_C = 'f4m.t3st3r.hlsretry.ts'


def _keystream(length, nonce):
    """Keystream determinística: SHA-256(sal + nonce + contador), encadeada."""
    out = bytearray()
    counter = 0
    while len(out) < length:
        seed = ('%s|%s|%s|%d' % (_SALT_A, nonce.hex(), _SALT_C, counter)).encode('utf-8')
        out.extend(hashlib.sha256(hashlib.sha256(seed).digest() + _SALT_B.encode('utf-8')).digest())
        counter += 1
    return bytes(out[:length])


def enc(text):
    """Texto claro -> string opaca para gravar em disco."""
    if text is None:
        text = ''
    try:
        data = str(text).encode('utf-8')
    except Exception:
        data = repr(text).encode('utf-8', 'replace')
    try:
        nonce = os.urandom(8)
        ks = _keystream(len(data), nonce)
        cipher = bytes(a ^ b for a, b in zip(data, ks))
        return MARKER + base64.b64encode(nonce + cipher).decode('ascii')
    except Exception:
        # impossível na prática; devolve vazio cifrado em vez de vazar claro
        return MARKER + ''


def dec(value):
    """String opaca (ou legado em claro) -> texto claro (só em memória)."""
    if value is None:
        return ''
    s = value if isinstance(value, str) else str(value)
    if not s.startswith(MARKER):
        # legado: valor antigo em texto puro — devolve como está;
        # quem chamou regrava cifrado na próxima atualização.
        return s
    payload = s[len(MARKER):]
    if not payload:
        return ''
    try:
        raw = base64.b64decode(payload)
        nonce, cipher = raw[:8], raw[8:]
        if len(nonce) < 8 or not cipher:
            return ''
        ks = _keystream(len(cipher), nonce)
        return bytes(a ^ b for a, b in zip(cipher, ks)).decode('utf-8', 'replace')
    except Exception:
        return ''
