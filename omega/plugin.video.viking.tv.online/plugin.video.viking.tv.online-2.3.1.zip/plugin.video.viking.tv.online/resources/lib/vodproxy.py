# -*- coding: utf-8 -*-
# vodproxy.py — VOD PROXY (Video On Demand)
# Proxy local para streams VOD com suporte a seek (Range), redirecionamento
# manual com Host/Origin/Referer dinâmicos por hop, e resolução DNS over HTTPS.
#
# PYTHON 3 ONLY — Kodi 19-22 (Matrix, Nexus, Omega, Piers).
# Sem compatibilidade com Kodi 17/18 (Python 2.7).

import http.server
import ipaddress
import json
import os
import random
import re
import socket
import socketserver
import ssl
import sys
import threading
import time
import traceback
import urllib.parse
import warnings

# Importações do Kodi (com fallback stub para uso standalone / testes).
try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:  # pragma: no cover — fora do Kodi (Termux / testes)
    import logging

    class _XbmcStub:
        """Stub mínimo de xbmc para uso standalone (Termux / testes)."""
        LOGDEBUG = logging.DEBUG
        LOGINFO = logging.INFO
        LOGWARNING = logging.WARNING
        LOGERROR = logging.ERROR
        LOGFATAL = logging.CRITICAL

        _stub_logger = logging.getLogger("vodproxy")

        @staticmethod
        def log(msg, level=logging.INFO):
            try:
                _XbmcStub._stub_logger.log(level, msg)
            except Exception:
                pass

    xbmc = _XbmcStub()
    xbmcaddon = None
    xbmcvfs = None

# --- IMPORTAÇÕES DE REDE ---
try:
    import requests
    from requests.adapters import HTTPAdapter
except ImportError:
    requests = None
    HTTPAdapter = None

# ---------------- CONFIGURAÇÕES ----------------

DEFAULT_CHUNK_SIZE = 1024 * 1024  # 1MB para VOD
CONNECTION_TIMEOUT = 30.0
CONNECT_TRY_TIMEOUT = 6.0   # timeout de conexão por tentativa (IP DoH / URL original)
STREAM_TIMEOUT = 120.0
MAX_REDIRECTS = 10

BIND_HOST = '0.0.0.0'
ACCESS_HOST = '127.0.0.1'
MAX_PORT_ATTEMPTS = 50

CONFIG = {
    'SESSION_TIMEOUT': 300,
}

warnings.filterwarnings("ignore")
try:
    import urllib3
    urllib3.disable_warnings()
except Exception:
    pass


# ---------------- LOG / HANDLE ERROR ----------------

def _log(msg, level=xbmc.LOGINFO):
    """No-op: log desativado — blindagem anti-vazamento.

    URLs de stream, tokens e hosts de origem nunca chegam ao kodi.log.
    """
    return None


def _quiet_handle_error(self, request, client_address):
    """handle_error do servidor: suprime traceback de desconexões do cliente.

    Em Python 3 ConnectionResetError/BrokenPipeError são subclasses de
    OSError (e de ConnectionError): filtramos todas de uma vez. O resto
    vira log de erro para diagnóstico.
    """
    exc = sys.exc_info()[1]
    if isinstance(exc, (OSError, ConnectionError)):
        _log("Conexão {} encerrada: {}".format(client_address[0], exc),
             xbmc.LOGDEBUG)
        return
    _log("Erro no servidor: {}".format(traceback.format_exc()),
         xbmc.LOGERROR)


# ---------------- DOH — RESOLVEDOR CENTRAL DO ADDON ----------------
# O DoH embutido do vodproxy (múltiplos servidores) foi SUBSTITUÍDO pelo
# resolvedor central do addon (resources/lib/dohresolver.py, Cloudflare):
# todas as consultas DNS deste proxy — e de todo o addon — passam por
# ele, que respeita a opção "Resolver DNS pela Cloudflare (DoH)" nas
# configurações (padrão: ATIVA) e faz fallback para o DNS do sistema.

try:  # uso normal: dentro do pacote resources/lib do addon
    from . import dohresolver as _dohresolver
except Exception:  # pragma: no cover — standalone / outros layouts
    try:
        from resources.lib import dohresolver as _dohresolver
    except Exception:
        import dohresolver as _dohresolver


def _is_ip_address(host):
    """Verifica se o host já é um endereço IP (IPv4 ou IPv6)."""
    if not host:
        return False
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def doh_resolve(hostname):
    """
    Resolve um hostname usando o resolvedor DoH central do addon
    (Cloudflare). Retorna o próprio valor se já for IP, None ou vazio.
    Com o DoH desativado ou em falha, cai no DNS do sistema; se também
    falhar, devolve o hostname original (mesma assinatura de antes).
    """
    if not hostname:
        return hostname

    # Ignora se já for IP
    if _is_ip_address(hostname):
        _log("DoH: já é IP, ignorando -> {}".format(hostname), xbmc.LOGDEBUG)
        return hostname

    ip = _dohresolver.resolve(hostname)
    if ip and _is_ip_address(ip):
        _log("DoH resolveu: {} -> {}".format(hostname, ip), xbmc.LOGINFO)
        return ip

    # Último recurso: retorna o hostname original
    _log("DoH sem resultado para {}".format(hostname), xbmc.LOGDEBUG)
    return hostname


def doh_resolve_url(url):
    """
    Resolve o hostname dentro de uma URL usando o resolvedor central
    (somente IPv4). Mantém userinfo, porta e path; URLs cujo host já é
    IP ou que não puderam ser resolvidas voltam sem alteração.
    """
    return _dohresolver.resolve_url(url)


# Instala os hooks globais de DNS do resolvedor central (idempotente):
# as sessões requests/urllib3 deste proxy resolvem hostnames via
# socket.getaddrinfo, que passa a usar o DoH central.
_dohresolver.install()

# ---------------- SESSION MANAGER ----------------

class SessionManager:
    def __init__(self):
        self._session = None
        self._lock = threading.Lock()
        self._last_used = 0

    def get_session(self):
        with self._lock:
            if (self._session is None or
                    time.time() - self._last_used > CONFIG['SESSION_TIMEOUT']):

                if self._session:
                    try:
                        self._session.close()
                    except Exception:
                        pass

                self._session = requests.Session()
                self._session.verify = False

                adapter = HTTPAdapter(pool_connections=30, pool_maxsize=30, max_retries=0)
                self._session.mount('http://', adapter)
                self._session.mount('https://', adapter)

                self._session.headers.update({
                    'Accept': '*/*',
                })

            self._last_used = time.time()
            return self._session

    def close(self):
        with self._lock:
            if self._session:
                try:
                    self._session.close()
                except Exception:
                    pass
                self._session = None
                self._last_used = 0


SESSION_MANAGER = SessionManager()


# ---------------- REGISTRO GLOBAL DE MANAGERS ATIVOS ----------------
# Permite que o addon chame stop_all_managers() para encerrar TODOS os
# proxies VOD ativos de uma vez (usado quando o player para).
_ACTIVE_MANAGERS = []
_ACTIVE_MANAGERS_LOCK = threading.Lock()


def _register_manager(mgr):
    """Chamado por VODProxyManager.start() para registrar o manager no conjunto global."""
    with _ACTIVE_MANAGERS_LOCK:
        if mgr not in _ACTIVE_MANAGERS:
            _ACTIVE_MANAGERS.append(mgr)


def _unregister_manager(mgr):
    """Chamado por VODProxyManager.stop() para remover o manager do conjunto global."""
    with _ACTIVE_MANAGERS_LOCK:
        try:
            _ACTIVE_MANAGERS.remove(mgr)
        except ValueError:
            pass


def stop_all_managers():
    """Encerra TODOS os proxies VOD ativos (servidores + sessões) imediatamente.

    Chama stop() em cada VODProxyManager registrado. Idempotente e seguro
    chamar de threads distintas.
    """
    with _ACTIVE_MANAGERS_LOCK:
        managers = list(_ACTIVE_MANAGERS)
        _ACTIVE_MANAGERS.clear()
    for mgr in managers:
        try:
            mgr.stop()
        except Exception as e:
            try:
                _log("Erro ao parar manager VOD: {}".format(e), xbmc.LOGERROR)
            except Exception:
                pass


# ---------------- STREAM MANAGER ----------------

class StreamManager:
    def __init__(self):
        self.session_manager = SESSION_MANAGER

    def is_blocked(self, url):
        if not url:
            return False
        return 'cloudflare-terms-of-service-abuse' in url.lower()

    def parse_xc(self, url):
        pattern = r'http[s]?://([^/]+)/([^/]+)/([^/]+)/([^/]+)/(\d+)\.(.+)'
        match = re.match(pattern, url)
        if match:
            return {
                'host': match.group(1),
                'type': match.group(2),
                'username': match.group(3),
                'password': match.group(4),
                'id': match.group(5),
                'ext': match.group(6),
            }
        return None

    # ==================================================================
    # generate_headers gera Host, Origin e Referer dinamicamente a partir
    # da URL de destino, e o Host é gerado SEM portas default (80/443),
    # que alguns CDNs rejeitam.
    # ==================================================================
    def generate_headers(self, url, range_header=None):
        """
        Gera headers dinamicamente baseados na URL de destino.
        - Host: hostname sem porta default (80/443 são omitidas)
        - Origin: scheme://host[:porta_nao_default]
        - Referer: scheme://host[:porta_nao_default]/

        Isso garante que CDNs que validam Host/Origin/Referer aceitem a
        conexão em cada salto de redirecionamento.
        """
        parsed = urllib.parse.urlparse(url)

        host = parsed.hostname or ''
        port = parsed.port
        scheme = parsed.scheme or 'http'

        # Host header sem portas default (80 para http, 443 para https)
        is_default_port = (
            (scheme == 'http' and port == 80) or
            (scheme == 'https' and port == 443)
        )
        if port and not is_default_port:
            host_header = '{}:{}'.format(host, port)
        else:
            host_header = host

        # Origin e Referer baseados na origem (scheme + host)
        origin = '{}://{}'.format(scheme, host_header)
        referer = origin + '/'

        headers = {
            'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20',
            'Accept': '*/*',
            'Accept-Encoding': 'identity',
            'Host': host_header,
            'Origin': origin,
            'Referer': referer,
            'Connection': 'keep-alive',  # Keep-alive para reutilizar conexão no seek
        }

        # IMPORTANTE: Repassar Range para suportar seek
        if range_header:
            headers['Range'] = range_header
            _log("Range: {}".format(range_header), xbmc.LOGDEBUG)

        return headers

    def _candidate_urls(self, url):
        """
        Lista de URLs a tentar para um hop: primeiro IP resolvido via DoH
        (força IPv4 e evita DNS/IPv6 travando), depois a URL original.
        IP só é usado em http (em https o SNI quebraria).
        """
        candidates = []
        try:
            if urllib.parse.urlparse(url).scheme == 'http':
                ip_url = doh_resolve_url(url)
                if ip_url and ip_url != url:
                    candidates.append(ip_url)
        except Exception:
            pass
        candidates.append(url)
        return candidates

    # ==================================================================
    # fetch com redirecionamento MANUAL.
    # - allow_redirects=False (desliga o redirecionamento automático da
    #   biblioteca requests, que enviaria o Host original para o CDN).
    # - A cada salto 301/302/303/307/308, chama generate_headers() de novo
    #   para reconstruir Host, Origin e Referer a partir da nova URL.
    # - Trata 303 mudando método para GET (compatível com RFC).
    # - Retorna None somente em bloqueio explícito; caso contrário retorna
    #   o Response (mesmo para 4xx/5xx) para o chamador decidir.
    # ==================================================================
    def fetch_with_dynamic_host(self, url, range_header=None, max_redirects=MAX_REDIRECTS):
        """
        Fetch com Host dinâmico, DoH, fallback de conexão e suporte a Range/Seek.
        Redirecionamentos (301/302/303/307/308) são seguidos MANUALMENTE,
        regenerando os cabeçalhos Host, Origin e Referer em cada salto.
        """
        current_url = url
        redirect_count = 0
        method = 'GET'  # 303 muda para GET

        while redirect_count <= max_redirects:
            # ---- REGENERA HEADERS A CADA HOP (Host/Origin/Referer dinâmicos) ----
            headers = self.generate_headers(current_url, range_header)
            session = self.session_manager.get_session()

            _log("Hop {}: {} (Host={}, Origin={})".format(
                redirect_count, current_url[:80], headers.get('Host'), headers.get('Origin')
            ), xbmc.LOGDEBUG)

            resp = None
            last_err = None
            for target in self._candidate_urls(current_url):
                try:
                    if method == 'GET':
                        resp = session.get(
                            target,
                            headers=headers,
                            stream=True,
                            timeout=(CONNECT_TRY_TIMEOUT, STREAM_TIMEOUT),
                            verify=False,
                            allow_redirects=False  # <-- DESATIVADO
                        )
                    else:
                        resp = session.head(
                            target,
                            headers=headers,
                            timeout=(CONNECT_TRY_TIMEOUT, STREAM_TIMEOUT),
                            verify=False,
                            allow_redirects=False  # <-- DESATIVADO
                        )
                    break
                except (requests.exceptions.ConnectTimeout,
                        requests.exceptions.ConnectionError,
                        requests.exceptions.ReadTimeout) as e:
                    last_err = e
                    _log("Falha conexão ({}): {}".format(
                        target[:60], type(e).__name__), xbmc.LOGWARNING)
                    continue

            if resp is None:
                _log("Erro fetch: {}".format(last_err), xbmc.LOGERROR)
                raise last_err if last_err else Exception("Falha de conexão")

            # ---- Verifica redirect (loop manual) ----
            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get('Location')
                if not location:
                    _log("Redirect {} sem Location, retornando".format(
                        resp.status_code), xbmc.LOGWARNING)
                    return resp

                # Resolve URL relativa/absoluta
                next_url = urllib.parse.urljoin(current_url, location)

                if self.is_blocked(next_url):
                    _log("Bloqueio detectado em redirect: {}".format(
                        next_url[:80]), xbmc.LOGWARNING)
                    resp.close()
                    return None

                _log("Redirect {} hop {}: {}... -> {}".format(
                    resp.status_code, redirect_count, current_url[:40], next_url[:80]
                ), xbmc.LOGINFO)

                # 303 muda método para GET (RFC 7231)
                if resp.status_code == 303:
                    method = 'GET'

                resp.close()
                current_url = next_url
                redirect_count += 1
                continue

            # ---- Sucesso - verifica se aceita Range ----
            if resp.status_code in (200, 206):
                accept_ranges = resp.headers.get('Accept-Ranges', 'none')
                content_length = resp.headers.get('Content-Length')

                _log("OK {}: {} | Accept-Ranges: {} | Length: {}".format(
                    resp.status_code, current_url[:60], accept_ranges, content_length
                ), xbmc.LOGINFO)

                if range_header and resp.status_code == 200:
                    _log("Servidor ignorou Range, retornou 200 completo", xbmc.LOGWARNING)

                return resp

            # ---- Status inesperado (4xx/5xx) ----
            # IMPORTANTE: retorna o Response (NÃO é None!), pois o requests.Response
            # avalia como False em bool() quando status >= 400, o que bugava o
            # chamador (que usava "if not resp").
            _log("Status inesperado: {} ({})".format(
                resp.status_code, current_url[:60]), xbmc.LOGWARNING)
            return resp

        _log("Limite de redirects atingido: {}".format(max_redirects), xbmc.LOGERROR)
        raise Exception("Limite de redirects atingido")

    # ==================================================================
    # get_direct_link usa allow_redirects=False e segue redirects
    # manualmente, regenerando headers (Host/Origin/Referer) a cada salto,
    # igual ao fetch_with_dynamic_host.
    # ==================================================================
    def get_direct_link(self, xc_info):
        """
        Tenta obter link direto via API XC. Segue redirects manualmente.
        """
        try:
            base = "http://{}".format(xc_info['host'])
            api_url = "{}/player_api.php?username={}&password={}&action=get_vod_info&vod_id={}".format(
                base, xc_info['username'], xc_info['password'], xc_info['id'])

            _log("API: {}".format(api_url[:80]), xbmc.LOGINFO)

            session = self.session_manager.get_session()

            # Gera headers dinâmicos (Host/Origin/Referer) baseados na URL da API
            api_headers = self.generate_headers(api_url)
            api_headers['Accept'] = 'application/json,*/*'

            resp = session.get(
                api_url,
                headers=api_headers,
                timeout=(10, 30),
                verify=False,
                allow_redirects=False  # <-- DESATIVADO
            )

            # ---- Loop manual de redirects para a API ----
            redirect_count = 0
            current_api_url = api_url
            while resp.status_code in (301, 302, 303, 307, 308) and redirect_count < MAX_REDIRECTS:
                location = resp.headers.get('Location')
                if not location:
                    break
                next_url = urllib.parse.urljoin(current_api_url, location)

                _log("API Redirect {} -> {}".format(
                    resp.status_code, next_url[:80]), xbmc.LOGINFO)

                # Regenera headers para a nova URL de destino
                api_headers = self.generate_headers(next_url)
                api_headers['Accept'] = 'application/json,*/*'

                resp.close()
                resp = session.get(
                    next_url,
                    headers=api_headers,
                    timeout=(10, 30),
                    verify=False,
                    allow_redirects=False  # <-- DESATIVADO
                )
                current_api_url = next_url
                redirect_count += 1

            if resp.status_code == 200:
                try:
                    data = resp.json()

                    if 'movie_data' in data:
                        movie = data['movie_data']

                        for key in ['stream_url', 'direct_source', 'video_url', 'url']:
                            if key in movie and movie[key]:
                                url = movie[key]
                                if url.startswith('http') and not self.is_blocked(url):
                                    _log("API URL ({}): {}".format(key, url[:60]), xbmc.LOGINFO)
                                    return url

                        if 'token' in movie:
                            token = movie['token']
                            stream_url = "{}/movie/{}/{}/{}.{}?token={}".format(
                                base, xc_info['username'], xc_info['password'],
                                xc_info['id'], xc_info['ext'], token)
                            _log("URL com token: {}".format(stream_url[:60]), xbmc.LOGINFO)
                            return stream_url

                except Exception as e:
                    _log("Erro parse API: {}".format(e), xbmc.LOGDEBUG)

            resp.close()

        except Exception as e:
            _log("Erro API: {}".format(e), xbmc.LOGDEBUG)

        return None

    def fetch(self, url, range_header=None):
        """
        Tenta obter stream com suporte a seek.
        """
        xc_info = self.parse_xc(url)

        # ESTRATÉGIA 1: API para URL com token
        if xc_info:
            direct_url = self.get_direct_link(xc_info)
            if direct_url:
                _log("Tentando URL da API", xbmc.LOGINFO)
                try:
                    resp = self.fetch_with_dynamic_host(direct_url, range_header)
                    # "is not None" (Response com status >= 400 avalia como False em bool()),
                    # mas um erro HTTP da URL da API NAO pode impedir o fallback para a URL
                    # original (ESTRATEGIA 2): so aceita a resposta se status < 400.
                    if resp is not None and resp.status_code < 400:
                        return resp
                    if resp is not None:
                        _log("URL da API respondeu {}; usando URL original".format(
                            resp.status_code), xbmc.LOGWARNING)
                        resp.close()
                except Exception as e:
                    _log("URL da API falhou: {}".format(e), xbmc.LOGWARNING)

        # ESTRATÉGIA 2: URL original
        _log("Tentando URL original", xbmc.LOGINFO)
        return self.fetch_with_dynamic_host(url, range_header)


STREAM_MANAGER = StreamManager()


# ---------------- PROXY HTTP ----------------

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True
    handle_error = _quiet_handle_error


class VODProxyRequestHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, format, *args):
        pass

    def do_HEAD(self):
        self._handle_request(method='HEAD')

    def do_GET(self):
        self._handle_request(method='GET')

    def _handle_request(self, method='GET'):
        try:
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            target_url = query.get('url', [None])[0]

            if not target_url:
                self.send_error(400, "Missing URL")
                return

            target_url = urllib.parse.unquote_plus(target_url)

            # IMPORTANTE: Captura o Range do cliente Kodi
            range_header = self.headers.get('Range')

            _log("========================================", xbmc.LOGINFO)
            _log("Request: {}".format(target_url[:80]), xbmc.LOGINFO)
            if range_header:
                _log("Cliente Range: {}".format(range_header), xbmc.LOGINFO)

            # Obtém stream
            try:
                resp = STREAM_MANAGER.fetch(target_url, range_header)
            except Exception as e:
                _log("Upstream falhou: {}".format(e), xbmc.LOGERROR)
                self.send_error(502, "Upstream error")
                return

            # ==================================================================
            # CORREÇÃO CRÍTICA: usar "resp is None" em vez de "not resp".
            # Motivo: requests.Response.__bool__() retorna False quando o status
            # code é >= 400 (ok = status_code < 400). Assim, uma resposta 500
            # do upstream (truthy no sentido lógico) era tratada como "falha"
            # e convertida em 403 para o Kodi, gerando os erros 403 do log.
            # ==================================================================
            if resp is None:
                _log("Falha ao obter stream (bloqueio/None)", xbmc.LOGERROR)
                self.send_error(403, "Server blocked access")
                return

            # Envia resposta com o STATUS ORIGINAL do upstream
            # (antes era sempre 403 quando status >= 400, agora reflete o real)
            self.send_response(resp.status_code)

            # Headers que NÃO devem ser repassados
            hop_by_hop = [
                'connection', 'keep-alive', 'proxy-authenticate',
                'proxy-authorization', 'te', 'trailers',
                'transfer-encoding', 'upgrade', 'content-encoding',
            ]

            # Repassa headers importantes para VOD/Seek
            content_length = None
            for k, v in resp.headers.items():
                kl = k.lower()
                if kl not in hop_by_hop:
                    # Não repassa Content-Length se temos Transfer-Encoding
                    if kl == 'content-length':
                        content_length = v
                    self.send_header(k, v)

            # IMPORTANTE: Garante Accept-Ranges para seek
            if 'Accept-Ranges' not in resp.headers:
                self.send_header('Accept-Ranges', 'bytes')

            # Se temos Content-Length e é 200, permite seek
            if resp.status_code == 200 and content_length:
                _log("Content-Length: {}".format(content_length), xbmc.LOGDEBUG)

            self.send_header('Connection', 'close')
            self.end_headers()

            if method == 'HEAD':
                resp.close()
                return

            # Streaming
            bytes_sent = 0
            try:
                for chunk in resp.iter_content(chunk_size=DEFAULT_CHUNK_SIZE):
                    if chunk:
                        self.wfile.write(chunk)
                        bytes_sent += len(chunk)
            except (ConnectionResetError, BrokenPipeError, ConnectionError, OSError):
                pass
            except Exception as e:
                _log("Erro stream: {}".format(e), xbmc.LOGERROR)
            finally:
                resp.close()
                _log("Enviado: {:.1f}MB".format(bytes_sent / 1024 / 1024), xbmc.LOGINFO)
                _log("========================================", xbmc.LOGINFO)

        except Exception as e:
            _log("Erro fatal: {}".format(e), xbmc.LOGERROR)
            try:
                self.send_error(500)
            except Exception:
                pass


class VODProxyManager:
    def __init__(self):
        self.server = None
        self.server_thread = None
        self.active_port = None
        self._is_running = False

    def start(self):
        if self._is_running:
            return True

        for attempt in range(MAX_PORT_ATTEMPTS):
            try:
                port = random.randint(30000, 60000)
                self.server = ThreadedTCPServer((BIND_HOST, port), VODProxyRequestHandler)
                self.server.timeout = 1

                self.server_thread = threading.Thread(target=self.server.serve_forever)
                self.server_thread.daemon = True
                self.server_thread.start()

                self.active_port = port
                self._is_running = True
                _register_manager(self)
                _log("Proxy VOD ativo em {}:{}".format(ACCESS_HOST, port), xbmc.LOGINFO)
                return True

            except Exception as e:
                if attempt == MAX_PORT_ATTEMPTS - 1:
                    _log("Falha: {}".format(e), xbmc.LOGERROR)
                continue

        return False

    def stop(self):
        self._is_running = False
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None

        SESSION_MANAGER.close()
        self.active_port = None
        _unregister_manager(self)


# ---------------- ENTRY POINT ----------------

def resolve_vod_stream(stream_url):
    proxy_manager = VODProxyManager()

    if not proxy_manager.start():
        return None, None

    if not stream_url:
        return None, proxy_manager

    params = {'url': stream_url}
    query_string = urllib.parse.urlencode(params, quote_via=urllib.parse.quote_plus)
    proxy_url = "http://{}:{}/?{}".format(ACCESS_HOST, proxy_manager.active_port, query_string)

    return proxy_url, proxy_manager


__all__ = ['VODProxyManager', 'resolve_vod_stream', 'SessionManager', 'stop_all_managers']
