"""
Simple HTTP Live Streaming client.

References:
    http://tools.ietf.org/html/draft-pantos-http-live-streaming-08

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.

Last updated: July 22, 2012
MODIFIED BY shani to make it work with F4mProxy

FIXED 2026-11 (channels freezing/closing after a few seconds - 406 Not Acceptable):
 1. The playlist refresh was re-using the REDIRECT (auth/token) URL instead of
    re-entering the ORIGINAL url. Load-balancer/IPTV tokens are single-use or
    short-lived, so every refresh got "406 Not Acceptable", no new segments were
    downloaded, the downloader gave up (~11s) and Kodi closed the channel when its
    buffer drained. Now every refresh re-enters through the original url (fresh
    token/redirect) and the redirect target is used ONLY to resolve relative
    segment urls.
 2. clientHeader/gproxy/gauth/nsplayer were module level globals shared by every
    instance and every addon that uses F4mProxy: any concurrent stream (or addon
    running init()) swapped the User-Agent mid-playback and the server started
    answering 406. They are now per-stream state (kept in a context passed
    explicitly through the call chain); the globals remain only as legacy
    defaults for external callers.
 3. Playlist failures retried with NO sleep (hammering the server every ~500ms)
    and gave up after ~20 failures; a single failed segment killed the whole
    cycle. Now: graduated backoff (1..5s), re-entry via the original url, segment
    retried 3x and then skipped, client-disconnect (broken pipe / closed file)
    detection, and one compact log line per failed request instead of a full
    traceback storm.
"""

#import urllib.parse as urlparse
import urllib.parse as urlparse
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
import subprocess, os, traceback, re, threading
try:
    import http.cookiejar as cookielib
except ImportError:
    import cookielib
try:
    import queue
except ImportError:
    import Queue as queue
import xml.etree.ElementTree as etree
import base64
from struct import unpack, pack
import struct
import sys
import io
import os
import time
import itertools
import xbmcaddon
import xbmc
import urllib
import traceback
import posixpath
import re
import hmac
import hashlib
import binascii
import zlib
from hashlib import sha256
import array, random, string
import requests
gproxy=None
gauth=None
nsplayer=False
callbackDRM=None
try:
    from Crypto.Cipher import AES
    USEDec=1 ## 1==crypto 2==local, local pycrypto
except:
    #print 'pycrypt not available using slow decryption'
    USEDec=3 ## 1==crypto 2==local, local pycrypto

if USEDec==1:
    #from Crypto.Cipher import AES
    print('using pycrypto')
elif USEDec==2:
    from decrypter import AESDecrypter
    AES=AESDecrypter()
else:
    from f4mUtils import python_aes

iv=None
key=None
value_unsafe = '%+&;#'
VALUE_SAFE = ''.join(chr(c) for c in range(33, 127)
    if chr(c) not in value_unsafe)

SUPPORTED_VERSION=3

cookieJar=cookielib.LWPCookieJar()
clientHeader=None

DEFAULT_UA='Mozilla/5.0 (X11; Linux i686; rv:42.0) Gecko/20100101 Firefox/42.0 Iceweasel/42.0'

# ---------------------------------------------------------------- helpers ----

def _log(msg):
    try:
        print('[F4mProxy/HLSRETRY] %s' % msg)
    except:
        pass

def _shortErr(what, url, inst):
    """compact one line error for expected http/network errors (no traceback storm)"""
    try:
        msg = str(inst)
        if len(msg) > 180:
            msg = msg[:180] + '...'
        _log('%s failed: %s: %s' % (what, inst.__class__.__name__, msg))
        _log('url: %s' % (url if isinstance(url, str) else str(url))[:200])
    except:
        pass

def _isClientGone(inst):
    """True when the error means the player (Kodi) closed the local connection"""
    try:
        if isinstance(inst, (BrokenPipeError, ConnectionResetError, ConnectionAbortedError,
                             ConnectionError)):
            return True
    except:
        pass
    try:
        r = repr(inst)
        for token in ('forcibly closed', 'Broken pipe', 'broken pipe',
                      'Connection reset', 'connection reset', 'Connection aborted',
                      'I/O operation on closed file',
                      'Remote end closed connection',
                      'ConnectionResetError', 'BrokenPipeError'):
            if token in r:
                return True
    except:
        pass
    return False

def _sleepBackoff(seconds, stopEvent=None):
    """sleep in 1s steps, abort as soon as playback stops"""
    for _ in range(0, int(seconds)):
        if stopEvent and stopEvent.isSet():
            return
        xbmc.sleep(1000)

def _newContext(clientHeader=None, proxy=None, auth=None, nsplayer=False,
                referer='', origin='', cookie='', callbackpath='', callbackparam=''):
    """per-stream state: headers, proxy, auth, cookies, session...
    nothing here is shared with other streams/addons"""
    ctx = {
        'clientHeader': list(clientHeader) if clientHeader else None,
        'proxy': proxy,
        'auth': auth,
        'nsplayer': nsplayer,
        'referer': referer,
        'origin': origin,
        'cookie': cookie,
        'callbackpath': callbackpath,
        'callbackparam': callbackparam,
        'cookieJar': cookielib.LWPCookieJar(),
        'session': None,
    }
    try:
        ctx['session'] = requests.Session()
        ctx['session'].cookies = ctx['cookieJar']
    except:
        ctx['session'] = None
    return ctx

def _legacyContext(referer='', origin='', cookie='', callbackpath='', callbackparam=''):
    """context built from the module globals - keeps old external callers working"""
    return _newContext(clientHeader=clientHeader, proxy=gproxy, auth=gauth,
                       nsplayer=nsplayer, referer=referer, origin=origin,
                       cookie=cookie, callbackpath=callbackpath, callbackparam=callbackparam)

class HLSDownloaderRetry():
    global cookieJar
    """
    A downloader for f4m manifests or AdobeHDS.
    """

    def __init__(self):
        self.init_done=False

    def init(self, out_stream, url, proxy=None,use_proxy_for_chunks=True,g_stopEvent=None, maxbitrate=0, auth='', callbackpath="", callbackparam="", referer="", origin="", cookie=""):
        global clientHeader,gproxy,gauth
        try:
            self.init_done=False
            self.init_url=url
            clientHeader=None
            self.status='init'
            self.proxy = proxy
            self.auth=auth
            self.callbackpath=callbackpath
            self.callbackparam=callbackparam
            self.referer=referer
            self.origin=origin
            self.cookie=cookie
            if self.auth ==None or self.auth =='None'  or self.auth=='':
                self.auth=None
            if self.auth:
                gauth=self.auth

            if self.proxy and len(self.proxy)==0:
                self.proxy=None
            gproxy=self.proxy
            self.use_proxy_for_chunks=use_proxy_for_chunks
            self.out_stream=out_stream
            if g_stopEvent: g_stopEvent.clear()
            self.g_stopEvent=g_stopEvent
            self.maxbitrate=maxbitrate
            self.client_header=None
            if '|' in url:
                sp = url.split('|')
                url = sp[0]
                headerstring = sp[1]
                if headerstring:
                    try:
                        self.client_header = urlparse.parse_qsl(headerstring)
                    except:
                        self.client_header = None
            # legacy globals kept in sync for external callers of getUrl()
            clientHeader=self.client_header
            # per-stream context: immune to other addons touching the globals
            self.ctx=_newContext(clientHeader=self.client_header, proxy=self.proxy,
                                 auth=self.auth, nsplayer=False,
                                 referer=self.referer, origin=self.origin,
                                 cookie=self.cookie,
                                 callbackpath=self.callbackpath,
                                 callbackparam=self.callbackparam)
            self.status='init done'
            self.url=url
            return True# disabled downloadInternal(self.url,None,self.maxbitrate,self.g_stopEvent , self.callbackpath,  self.callbackparam, self.referer, testing=True)
        except:
            traceback.print_exc()
            self.status='finished'
        return False


    def keep_sending_video(self,dest_stream, segmentToStart=None, totalSegmentToSend=0):
        try:
            self.status='download Starting'

            downloadInternal(self.url,dest_stream,self.maxbitrate,self.g_stopEvent , self.callbackpath,  self.callbackparam, self.referer, self.origin, self.cookie, ctx=self.ctx)
        except:
            traceback.print_exc()
        #print 'setting finished'
        self.status='finished'


def getUrl(url,timeout=15,returnres=False,stream =False,ctx=None):
    """get a url with the stream's OWN headers/proxy/cookies.
    ctx=None -> legacy behaviour (module globals), for external callers."""
    global cookieJar
    global clientHeader
    global nsplayer

    try:
        if ctx is not None:
            headers_list = ctx.get('clientHeader')
            proxy        = ctx.get('proxy')
            nsflag       = ctx.get('nsplayer', False)
            session      = ctx.get('session')
        else:
            headers_list = clientHeader
            proxy        = gproxy
            nsflag       = nsplayer
            session      = None

        headers = {'User-Agent': DEFAULT_UA, 'Accept': '*/*'}
        if headers_list:
            for n,v in headers_list:
                try:
                    if n and v: headers[n]=v
                except:
                    pass
        if nsflag:
            # some servers want a random "nsplayer" id as User-Agent
            try:
                headers['User-Agent']=binascii.b2a_hex(os.urandom(20))[:32].decode('ascii')
            except:
                headers['User-Agent']=binascii.b2a_hex(os.urandom(20))[:32]

        proxies={}
        if proxy:
            proxies= {"http": "http://"+proxy}

        if session is None:
            session = requests.Session()
            try:
                if ctx is not None:
                    session.cookies = ctx.get('cookieJar')
                else:
                    session.cookies = cookieJar
            except:
                pass

        req = session.get(url, headers=headers,proxies=proxies,verify=False ,timeout=timeout,stream=stream)

        req.raise_for_status()
        if returnres:
            return req
        else:
            return req.text

    except Exception as inst:
        if isinstance(inst, requests.exceptions.RequestException):
            _shortErr('request', url, inst)
        else:
            traceback.print_exc()
        raise


def getUrlold(url,timeout=20, returnres=False):
    global cookieJar
    global clientHeader
    try:
        post=None

        cookie_handler = urllib2.HTTPCookieProcessor(cookieJar)
        openner = urllib2.build_opener(cookie_handler, urllib2.HTTPBasicAuthHandler(), urllib2.HTTPHandler())

        if post:
            req = urllib2.Request(url, post)
        else:
            req = urllib2.Request(url)

        ua_header=False
        if clientHeader:
            for n,v in clientHeader:
                req.add_header(n,v)
                if n=='User-Agent':
                    ua_header=True

        if not ua_header:
            req.add_header('User-Agent','AppleCoreMedia/1.0.0.12B411 (iPhone; U; CPU OS 8_1 like Mac OS X; en_gb)')

        if gproxy:
            req.set_proxy(gproxy, 'http')
        response = openner.open(req)

        if returnres: return response
        data=response.read()

        return data

    except:
        traceback.print_exc()
        return None

def download_chunks(URL, chunk_size=4096, enc=None, ctx=None):
    #conn=urllib2.urlopen(URL)
    conn=getUrl(URL,returnres=True,stream=True,ctx=ctx)
    chunk_size=chunk_size*100
    try:
        for chunk in conn.iter_content(chunk_size=chunk_size):
            yield chunk
    finally:
        try:
            conn.close()
        except:
            pass

def download_file(URL, ctx=None):
    try:
        return b''.join(download_chunks(URL, ctx=ctx))
    except:
        raise

def validate_m3u(conn):
    ''' make sure file is an m3u, and returns the encoding to use. '''
    return 'utf8'

def gen_m3u(url, skip_comments=True, ctx=None, pretext=None, preres=None):
    global cookieJar
    if pretext is None:
        conn = getUrl(url,returnres=True,ctx=ctx )
        redirurl=None
        try:
            if conn.history:
                redirurl=conn.url
        except:
            pass
        enc = validate_m3u(conn)
        if redirurl: yield 'f4mredirect:'+redirurl
        try:
            for line in conn.iter_lines():
                line = line.rstrip(b'\r\n').decode(enc)
                if not line:
                    continue
                elif line.startswith('#EXT'):
                    yield line
                elif line.startswith('#'):
                    if skip_comments:
                        continue
                    else:
                        yield line
                else:
                    yield line
        finally:
            try:
                conn.close()
            except:
                pass
    else:
        # use the text already downloaded by the caller (no second fetch:
        # single-use auth tokens stay valid)
        if preres: yield 'f4mredirect:'+preres
        for line in pretext.splitlines():
            line = line.rstrip('\r\n')
            if not line:
                continue
            elif line.startswith('#EXT'):
                yield line
            elif line.startswith('#'):
                if skip_comments:
                    continue
                else:
                    yield line
            else:
                yield line

def parse_m3u_tag(line):
    if ':' not in line:
        return line, []
    tag, attribstr = line.split(':', 1)
    attribs = []
    last = 0
    quote = False
    for i,c in enumerate(attribstr+','):
        if c == '"':
            quote = not quote
        if quote:
            continue
        if c == ',':
            attribs.append(attribstr[last:i])
            last = i+1
    return tag, attribs

def parse_kv(attribs, known_keys=None):
    d = {}
    for item in attribs:
        k, v = item.split('=', 1)
        k=k.strip()
        v=v.strip().strip('"')
        if known_keys is not None and k not in known_keys:
            raise ValueError("unknown attribute %s"%k)
        d[k] = v
    return d

def handle_basic_m3u(url, ctx=None, pretext=None, preres=None):
    global USEDec
    global callbackDRM
    import urllib.parse as urlparse
    gauth=None
    if ctx is not None:
        gauth=ctx.get('auth')

    seq = 1
    enc = None
    nextlen = 5
    duration = 5
    targetduration=5
    aesdone=False
    redirurl=url
    vod=False
    for line in gen_m3u(url, ctx=ctx, pretext=pretext, preres=preres):
        if line.startswith('f4mredirect:'):
            redirurl=line.split('f4mredirect:')[1]
            continue
        if line.startswith('#EXT'):
            tag, attribs = parse_m3u_tag(line)
            if tag == '#EXTINF':
                duration = float(attribs[0])
            elif tag == '#EXT-X-TARGETDURATION':
                assert len(attribs) == 1, "too many attribs in EXT-X-TARGETDURATION"
                targetduration = int(attribs[0])
                pass
            elif tag == '#EXT-X-MEDIA-SEQUENCE':
                assert len(attribs) == 1, "too many attribs in EXT-X-MEDIA-SEQUENCE"
                seq = int(attribs[0])
            elif tag == '#EXT-X-KEY':
                attribs = parse_kv(attribs, ('METHOD', 'URI', 'IV'))
                assert 'METHOD' in attribs, 'expected METHOD in EXT-X-KEY'
                if attribs['METHOD'] == 'NONE':
                    assert 'URI' not in attribs, 'EXT-X-KEY: METHOD=NONE, but URI found'
                    assert 'IV' not in attribs, 'EXT-X-KEY: METHOD=NONE, but IV found'
                    enc = None
                elif attribs['METHOD'] == 'AES-128':
                    if not aesdone:
                        #aesdone=False there can be multple aes per file
                        assert 'URI' in attribs, 'EXT-X-KEY: METHOD=AES-128, but no URI found'
                        codeurl=attribs['URI'].strip('"')

                        if gauth:
                            currentaesUrl=codeurl
                            codeurl=gauth

                            if codeurl.startswith("LSHex$"):
                                try:
                                    codeurl=binascii.unhexlify(codeurl.split('LSHex$')[1])
                                except:
                                    codeurl=codeurl.split('LSHex$')[1].decode("hex")
                            if codeurl.startswith("LSDRMCallBack$"):
                                codeurlpath=codeurl.split('LSDRMCallBack$')[1]
                                codeurl='LSDRMCallBack$'+currentaesUrl

                                if codeurlpath and len(codeurlpath)>0 and callbackDRM==None:
                                    import importlib, os
                                    foldername=os.path.sep.join(codeurlpath.split(os.path.sep)[:-1])
                                    urlnew=''
                                    if foldername not in sys.path:
                                        sys.path.append(foldername)
                                    try:
                                        callbackfilename= codeurlpath.split(os.path.sep)[-1].split('.')[0]
                                        callbackDRM = importlib.import_module(callbackfilename)
                                    except:
                                        traceback.print_exc()

                        elif not codeurl.startswith('http'):
                            import urllib.parse as urlparse
                            codeurl=urlparse.urljoin(redirurl, codeurl)


                        if 'IV' in attribs:
                            assert attribs['IV'].lower().startswith('0x'), 'EXT-X-KEY: IV attribute has bad format'
                            ivstr = attribs['IV'][2:].zfill(32)
                            try:
                                iv = bytes.fromhex(ivstr)
                            except AttributeError:
                                iv = ivstr.decode('hex')
                            assert len(iv) == 16, 'EXT-X-KEY: IV attribute has bad length'
                        else:
                            iv = b'\0'*8 + struct.pack('>Q', seq)
                        enc=(codeurl,iv)
                else:
                    assert False, 'EXT-X-KEY: METHOD=%s unknown'%attribs['METHOD']
            elif tag == '#EXT-X-PROGRAM-DATE-TIME':
                assert len(attribs) == 1, "too many attribs in EXT-X-PROGRAM-DATE-TIME"
                # TODO parse attribs[0] as ISO8601 date/time
                pass
            elif tag == '#EXT-X-ALLOW-CACHE':
                # XXX deliberately ignore
                pass
            elif tag == 'EXT-X-PLAYLIST-TYPE:VOD':
                vod=True
                pass
                #EXT-X-PLAYLIST-TYPE:VOD
            elif tag == '#EXT-X-ENDLIST':
                assert not attribs
                yield None
                return
            elif tag == '#EXT-X-STREAM-INF':
                raise ValueError("don't know how to handle EXT-X-STREAM-INF in basic playlist")
            elif tag == '#EXT-X-DISCONTINUITY':
                assert not attribs
                #print "[warn] discontinuity in stream"
            elif tag == '#EXT-X-VERSION':
                assert len(attribs) == 1
                if int(attribs[0]) > SUPPORTED_VERSION:
                    print("[warn] file version %s exceeds supported version %d; some things might be broken"%(attribs[0], SUPPORTED_VERSION))
            #else:
            #    raise ValueError("tag %s not known"%tag)
        else:
            if not line.startswith('http'):
                line=urlparse.urljoin(redirurl, line)
            yield (seq, enc, duration, targetduration, line ,vod)
            seq += 1

def player_pipe(queue, control,file):
    while 1:
        block = queue.get(block=True)
        if block is None: return
        file.write(block)
        file.flush()

def send_back(data,file):
    file.write(data)
    file.flush()

def _resolve_media_url(start_url, ctx, maxbitrate=0):
    """fetch start_url (following redirects).
    - plain playlist  -> return (url, pretext, finalurl) : no second fetch needed
    - master playlist -> select variant (maxbitrate aware) -> (varianturl, None, finalurl)
    The redirect target is used ONLY to resolve relative urls, NEVER for refresh:
    refresh always re-enters start_url so the server can mint a fresh token/redirect
    (that is what fixes the 406 Not Acceptable after a few seconds).
    Raises the original request exception so callers can react to 403/401
    exactly like the old code did."""
    res=getUrl(start_url, returnres=True, ctx=ctx)
    try:
        finalurl=res.url
        text=res.text
        res.close()
    except:
        try: res.close()
        except: pass
        raise

    if 'EXT-X-STREAM-INF' not in text:
        return (start_url, text, finalurl)

    # master playlist: pick a variant
    try:
        variants = []
        variant = None
        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue
            if line.startswith('#EXT'):
                tag, attribs = parse_m3u_tag(line)
                if tag == '#EXT-X-STREAM-INF':
                    variant = attribs
            elif variant:
                variants.append((line, variant))
                variant = None
        if len(variants)==0:
            return (finalurl, None, None)
        if len(variants) == 1:
            return (urlparse.urljoin(finalurl, variants[0][0]), None, finalurl)
        # more than one variant of the stream was provided
        choice=-1
        lastbitrate=0
        for i, (vurl, vattrs) in enumerate(variants):
            for attr in vattrs:
                try:
                    key, value = attr.split('=')
                except:
                    continue
                key = key.strip()
                value = value.strip().strip('"')
                if key == 'BANDWIDTH':
                    try:
                        if int(value)<=int(maxbitrate) and int(value)>lastbitrate:
                            choice=i
                            lastbitrate=int(value)
                    except:
                        pass
                # other attributes (PROGRAM-ID/CODECS/RESOLUTION/...) are ignored
        if choice==-1: choice=0
        return (urlparse.urljoin(finalurl, variants[choice][0]), None, finalurl)
    except:
        traceback.print_exc()
        return (finalurl, None, None)

def downloadInternal(url,file,maxbitrate=0,stopEvent=None , callbackpath="",callbackparam="", referer="",origin="", cookie="",testing=False,ctx=None):
    global key
    global iv
    global USEDec
    global cookieJar
    global clientHeader
    global nsplayer
    global callbackDRM
    if stopEvent and stopEvent.isSet():
        return False
    if ctx is None:
        ctx=_legacyContext(referer=referer, origin=origin, cookie=cookie,
                           callbackpath=callbackpath, callbackparam=callbackparam)

    dumpfile = None
    #dumpfile=open('c:\\temp\\myfile.mp4',"wb")
    veryfirst=True
    # the ORIGINAL url: refreshes ALWAYS go through here again (fresh
    # redirect/token). It is never replaced by the redirect target.
    entry_url=url

    last_seq = -1
    targetduration = 5
    changed = 0

    fails=0                 # consecutive playlist failures
    maxfails=30             # give up only after this many (with backoff => ~2 min)
    no_data_since=time.time()   # last time bytes were actually sent to the player
    max_no_data=150         # give up if nothing could be sent for this long
    nsplayer=False
    #print 'inside HLS RETRY'
    try:

        while 1==1:

            if fails>maxfails:
                _log('giving up after %d consecutive playlist failures' % fails)
                break
            if stopEvent and stopEvent.isSet():
                return False
            if time.time()-no_data_since>max_no_data:
                _log('no data received for too long, giving up')
                break

            reconnect=False
            vod=False
            try:
                # ALWAYS re-enter through the original url: the server can
                # generate a fresh redirect/auth token every time. pretext/
                # preres carry the already downloaded playlist text so no
                # single-use token is wasted on a second fetch.
                media_url, pretext, preres = _resolve_media_url(entry_url, ctx, maxbitrate)
                medialist = list(handle_basic_m3u(media_url, ctx=ctx, pretext=pretext, preres=preres))
                if len(medialist)==0: raise Exception('empty m3u8')
                #print medialist
                if testing: return True
            except Exception as inst:
                fails+=1
                if testing and fails>6: return False

                if testing==False and callbackpath and len(callbackpath)>0 and ('403' in repr(inst).lower()):
                    import importlib, os
                    foldername=os.path.sep.join(callbackpath.split(os.path.sep)[:-1])
                    urlnew=''
                    if foldername not in sys.path:
                        sys.path.append(foldername)
                    try:
                        callbackfilename= callbackpath.split(os.path.sep)[-1].split('.')[0]
                        callbackmodule = importlib.import_module(callbackfilename)
                        urlnew,cjnew=callbackmodule.f4mcallback(callbackparam, referer, origin, cookie, 1, inst, ctx.get('cookieJar'), entry_url, ctx.get('clientHeader'))
                    except: traceback.print_exc()
                    if urlnew and len(urlnew)>0 and urlnew.startswith('http'):
                        entry_url=urlnew
                        try:
                            ctx['cookieJar'] = cjnew
                            if ctx.get('session') is not None:
                                ctx['session'].cookies = cjnew
                        except:
                            pass
                        cookieJar= cjnew
                        continue
                    else:
                        return

                if '403' in repr(inst).lower() or '401' in repr(inst).lower():
                    if fails in [1,4,5,10,15,19]:
                        nsplayer=True
                        ctx['nsplayer']=True
                    else:
                        nsplayer=False
                        ctx['nsplayer']=False
                    xbmc.sleep(1000)
                else:
                    # graduated backoff instead of hammering the server
                    _sleepBackoff(min(1 + fails//3, 5), stopEvent)
                if stopEvent and stopEvent.isSet():
                    return False
                continue

            # playlist ok
            fails=0
            ctx['nsplayer']=False
            nsplayer=False
            playedSomething=False
            if medialist==None: return

            addsomewait=False
            lastKeyUrl=""
            lastkey=None
            playedduration=0
            st=time.time()
            for media in medialist:

                if stopEvent and stopEvent.isSet():
                    return False
                if media is None:
                    if stopEvent:
                        #print 'set events'
                        stopEvent.set()
                    return False
                seq, encobj, duration, targetduration, media_url,vod = media

                if seq > last_seq:
                    ##print 'downloading.............',url

                    enc=None
                    if encobj:

                        codeurl,iv=encobj
                        if codeurl != lastKeyUrl:
                            if codeurl.startswith('http'):
                                key = download_file(codeurl, ctx=ctx)
                            elif codeurl.startswith('LSDRMCallBack$'):
                                key=callbackDRM.DRMCallback(codeurl.split('LSDRMCallBack$')[1],url)
                            else:
                                key = codeurl
                            codeurl=lastKeyUrl
                        else:
                            key=lastkey
                        lastkey=key
                        if not USEDec==3:
                            if isinstance(key, str):
                                try:
                                    key=key.encode('latin-1')
                                except:
                                    pass
                            enc = AES.new(key, AES.MODE_CBC, iv)
                        else:
                            ivb=array.array('B',iv)
                            keyb= array.array('B',key)
                            enc=python_aes.new(keyb, 2, ivb)

                    sent_bytes=0
                    segtries=0
                    while segtries<3:
                        if stopEvent and stopEvent.isSet():
                            return False
                        segtries+=1
                        try:
                            for chunk in download_chunks(media_url, ctx=ctx):
                                if stopEvent and stopEvent.isSet():
                                    return False
                                if enc:
                                    if not USEDec==3:
                                        chunk = enc.decrypt(chunk)
                                    else:
                                        chunkb=array.array('B',chunk)
                                        chunkb=enc.decrypt(chunkb)
                                        chunk=bytes(bytearray(chunkb))
                                try:
                                    send_back(chunk,file)
                                except Exception as werr:
                                    if _isClientGone(werr):
                                        return False
                                    raise
                                sent_bytes+=len(chunk)
                            # segment complete
                            break
                        except Exception as inst:
                            if _isClientGone(inst):
                                return False
                            _shortErr('segment', media_url, inst)
                            if sent_bytes>0:
                                # partially sent: do not retry (would duplicate
                                # ts data) -> move on to the next segment
                                break
                            if segtries<3:
                                _sleepBackoff(1, stopEvent)
                        if stopEvent and stopEvent.isSet():
                            return False

                    if sent_bytes>0:
                        playedduration+=duration
                        addsomewait=True
                        veryfirst=False
                        last_seq = seq
                        changed = 1
                        playedSomething=True
                        no_data_since=time.time()
                    else:
                        # could not download this segment at all (bad/expired
                        # url): stop this pass and refresh the playlist - the
                        # next pass re-enters the original url and gets fresh
                        # urls
                        reconnect=True
                        break

            if vod: return True
            if playedSomething == 1:
                # initial minimum reload delay
                timetowait=int(targetduration - (time.time()-st))#
                if (timetowait)>0:
                    #print 'sleeping because targetduration',timetowait
                    for t in range(0,timetowait):
                        xbmc.sleep(1000)
                        #print 'sleeep for 1sec',t
                        if stopEvent and stopEvent.isSet():
                            return False

            if not playedSomething:
                xbmc.sleep(3000+ (3000 if addsomewait else 0))

    except:

        raise

