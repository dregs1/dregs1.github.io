import sys
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import requests
import re
import os
import xbmc

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
f4m_mode = True

remote_json_url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x61\x77\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x64\x72\x65\x67\x73\x31\x2f\x64\x72\x65\x67\x73\x31\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x72\x65\x66\x73\x2f\x68\x65\x61\x64\x73\x2f\x6d\x61\x69\x6e\x2f\x78\x6d\x6c\x2f\x70\x74\x62\x6e\x2e\x6c\x69\x73\x74\x61\x2e\x6a\x73\x6f\x6e'

LIVE_GROUP_ALIASES = (
    (1, 'Germany', 'Deutschland', 'special://home/addons/plugin.video.flacon/resources/country/de.png', None),
    (2, 'Turkey', 'Türkei', 'special://home/addons/plugin.video.flacon/resources/country/tr.png', None),
    (3, 'Denmark', 'Dänemark', 'special://home/addons/plugin.video.flacon/resources/country/dk.png', None),
    (4, 'Sports International', 'Sport International', 'special://home/addons/plugin.video.flacon/resources/country/eu.png', None),
    (99999, 'Albania', 'Albanien', 'special://home/addons/plugin.video.flacon/resources/country/al.png', None),
    (99999, 'Arabia', 'Arabisch', 'special://home/addons/plugin.video.flacon/resources/country/ae.png', None),
    (99999, 'Azerbaijan', 'Azerbaijan', 'special://home/addons/plugin.video.flacon/resources/country/az.png', None),
    (99999, 'Bulgaria', 'Bulgarien', 'special://home/addons/plugin.video.flacon/resources/country/bg.png', None),
    (99999, 'France', 'Frankreich', 'special://home/addons/plugin.video.flacon/resources/country/fr.png', None),
    (99999, 'Netherlands', 'Niederlande', 'special://home/addons/plugin.video.flacon/resources/country/nl.png', None),
    (99999, 'Poland', 'Polen', 'special://home/addons/plugin.video.flacon/resources/country/pl.png', None),
    (99999, 'Romania', 'Rumänien', 'special://home/addons/plugin.video.flacon/resources/country/ro.png', None),
    (99999, 'Portugal', 'Portugal', 'special://home/addons/plugin.video.flacon/resources/country/pt.png', None),
    (99999, 'Italy', 'Italien', 'special://home/addons/plugin.video.flacon/resources/country/it.png', None),
    (99999, 'Belgium', 'Belgien', 'special://home/addons/plugin.video.flacon/resources/country/be.png', None),
    (99999, 'United Kingdom', 'England', 'special://home/addons/plugin.video.flacon/resources/country/gb.png', None),
    (99999, 'Greece', 'Griechenland', 'special://home/addons/plugin.video.flacon/resources/country/gr.png', None),
    (99999, 'Russia', 'Russland', 'special://home/addons/plugin.video.flacon/resources/country/ru.png', None),
    (99999, 'Spain', 'Spanien', 'special://home/addons/plugin.video.flacon/resources/country/es.png', None),
    (99999, 'Sweden', 'Schweden', 'special://home/addons/plugin.video.flacon/resources/country/se.png', None),
    (99999, 'Iran', 'Iran', 'special://home/addons/plugin.video.flacon/resources/country/ir.png', None),
    (99999, 'Balkans', 'Balkans', 'special://home/addons/plugin.video.flacon/resources/yu.png', None),
)

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[MEU ADDON] {msg}", level)


def clean_unused_logos():
    keep_files = set()
    for _, _, _, path, _ in LIVE_GROUP_ALIASES:
        if path:
            keep_files.add(os.path.basename(path))

    resource_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.flacon/resources/country')
    if not os.path.exists(resource_dir):
        return
    for file in os.listdir(resource_dir):
        if file.endswith('.png') and file not in keep_files:
            try:
                os.remove(os.path.join(resource_dir, file))
            except:
                pass

#clean_unused_logos()

def get_group_logo(group):
    for _, en, de, path, _ in LIVE_GROUP_ALIASES:
        if group.lower() in (en.lower(), de.lower()):
            return path
    return ''

def get_sorted_groups(all_groups):
    order = []
    seen = set()
    for _, en, de, _, _ in LIVE_GROUP_ALIASES:
        for g in all_groups:
            if g.lower() == en.lower() or g.lower() == de.lower():
                if g not in seen:
                    order.append(g)
                    seen.add(g)
    for g in all_groups:
        if g not in seen:
            order.append(g)
    return order

def load_channels():
    try:
        response = requests.get(remote_json_url, timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        xbmcgui.Dialog().notification('Fehler beim Laden', str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_groups():
    data = load_channels()
    raw_groups = set(item.get('group', 'Ungrouped') for item in data)
    groups = get_sorted_groups(raw_groups)
    xbmc.log('')
    for group in groups:
        url = build_url({'mode': 'list_channels', 'group': group})
        li = xbmcgui.ListItem(label=group)
        logo = get_group_logo(group)
        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_channels(group):
    data = load_channels()
    for c in data:
        if c.get('group') != group:
            continue
        #match = re.search(r'/play/(\d+)', c.get('url', ''))
        if 'f4mtester' in c.get('url', '').lower():
            match = re.search(r'url=(http[s]?://[^\s&]+)', c.get('url', '')) # f4mtester
        else:
            match = None
        if not c.get('url', ''):
            continue
        elif not match:
            continue
        if match:
            channel_id = match.group(1)
        else:
            channel_id = c.get('url', '')
        url = build_url({'mode': 'play', 'id': channel_id})
        li = xbmcgui.ListItem(label=c.get('name', 'Unbenannt'))
        logo = c.get('logo') or ''
        if logo:
            if 'f4mtester' in logo:
                match_logo = re.search(r'url=(http[s]?://[^\s&]+)', logo) # f4mtester
                logo = match_logo.group(1)
        li.setArt({'thumb': logo, 'icon': logo, 'fanart': logo})
        if not f4m_mode:
            li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_stream(channel_id):
    if f4m_mode and not 'plugin://' in channel_id:
        plugin_url = f"plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name=[COLORcyan]@by_black_eagle[/COLOR]&url={channel_id}"
        xbmc.executebuiltin(f'RunPlugin("{plugin_url}")')
    else:
        channel_id = channel_id + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        li = xbmcgui.ListItem(path=channel_id)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=li)


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
mode = params.get('mode')

if mode == 'list_channels':
    list_channels(params['group'])
elif mode == 'play':
    
    play_stream(params['id'])
else:
    list_groups()