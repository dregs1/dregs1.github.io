import urllib.request, urllib.parse
import hashlib
import time
from collections import OrderedDict
from urllib.parse import quote, urlencode
import json
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

import re

class StalkerPortal:
    def __init__(self, portal_url, mac):
        self.portal_url = portal_url.rstrip("/")
        self.mac = mac.strip()
        logger.debug(f"StalkerPortal initialized with Portal URL: {self.portal_url} and MAC: {self.mac}")
        # self.session = requests.Session() # Removed requests.Session
        self.token = None
        self.bearer_token = None
        self.stream_base_url = portal_url.rstrip('/')
        self.last_handshake = 0
        self.token_expiry = 3600  # 1 hour default

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass # No session to close with urllib.request

    def ensure_valid_token(self):
        """Asigură că token-ul este valid, reface handshake-ul dacă e necesar"""
        current_time = time.time()
        
        if not self.token or (current_time - self.last_handshake) > (self.token_expiry - 300):
            logger.debug("Token expirat sau lipsește, refac handshake-ul")
            self.handshake()
            return
        
        # Testează token-ul curent cu o cerere simplă
        try:
            test_url = f"{self.portal_url}/portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml"
            
            headers = self.get_headers()
            cookies = self.get_cookies()
            cookie_header = '; '.join([f'{k}={v}' for k, v in cookies.items()])
            if cookie_header:
                headers['Cookie'] = cookie_header

            req = urllib.request.Request(test_url, headers=headers)
            with urllib.request.urlopen(req, timeout=5) as response:
                # For urllib, status code is in response.getcode()
                if response.getcode() != 200:
                    logger.debug("Token invalid, refac handshake-ul")
                    self.handshake()
        except urllib.error.URLError as e:
            logger.debug(f"Eroare la testarea token-ului: {e.reason}, refac handshake-ul")
            self.handshake()
        except Exception: # Catch any other unexpected errors
            logger.debug("Eroare la testarea token-ului, refac handshake-ul")
            self.handshake()

    def get_headers(self):
        """Returnează header-urile standard"""
        headers = {
            'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'
        }
        if self.bearer_token:
            headers['Authorization'] = f'Bearer {self.bearer_token}'
        return headers

    def get_cookies(self):
        """Returnează cookie-urile standard"""
        cookies = {'mac': self.mac, 'stb_lang': 'en', 'timezone': 'Europe/Paris'}
        if self.token:
            cookies['token'] = self.token
        return cookies

    def handshake(self):
        logger.debug(f"Attempting handshake with Portal URL: {self.portal_url} and MAC: {self.mac}")
        url = f"{self.portal_url}/portal.php?type=stb&action=handshake&token=&JsHttpRequest=1-xml"
        
        try:
            data = self._make_request(url)
            self.token = data.get('js', {}).get('token')
            self.bearer_token = self.token
            self.last_handshake = time.time()
            logger.debug(f"Handshake successful, token: {self.token}")
        except Exception as e:
            logger.error(f"Handshake failed: {e}")
            raise ConnectionError("Failed to perform handshake")

    def validate_stream_url(self, url):
        """Verifică dacă URL-ul stream este valid"""
        try:
            req = urllib.request.Request(url, method='HEAD')
            with urllib.request.urlopen(req, timeout=5) as response:
                return response.getcode() == 200
        except urllib.error.URLError:
            return False
        except Exception:
            return False

    def _make_request(self, url, method='GET', data=None, timeout=10):
        headers = self.get_headers()
        cookies = self.get_cookies()
        cookie_header = '; '.join([f'{k}={v}' for k, v in cookies.items()])
        if cookie_header:
            headers['Cookie'] = cookie_header

        req = urllib.request.Request(url, headers=headers, method=method)
        if data:
            req.add_header('Content-Type', 'application/json')
            data = json.dumps(data).encode('utf-8')

        try:
            with urllib.request.urlopen(req, timeout=timeout) as response:
                response_data = response.read().decode('utf-8')
                return json.loads(response_data)
        except urllib.error.HTTPError as e:
            logger.error(f"HTTP Error {e.code} for {url}: {e.reason}")
            raise
        except urllib.error.URLError as e:
            logger.error(f"URL Error for {url}: {e.reason}")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"JSON Decode Error for {url}: {e}, response: {response_data}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error for {url}: {e}")
            raise

    def detect_portal_structure(self):
        """Detectează structura URL-urilor pentru acest portal"""
        test_patterns = [
            "/stalker_portal/c/",
            "/ch/",
            "/live/",
            "/stream/",
            "/tv/"
        ]
        
        for pattern in test_patterns:
            test_url = f"{self.portal_url}{pattern}test"
            try:
                # Use urllib.request.urlopen for HEAD request
                req = urllib.request.Request(test_url, method='HEAD')
                with urllib.request.urlopen(req, timeout=3) as response:
                    if response.getcode() != 404:
                        logger.debug(f"Detected portal structure: {pattern}")
                        return pattern
            except urllib.error.URLError: # Catch connection errors
                continue
            except Exception: # Catch any other unexpected errors
                continue
        
        return "/ch/"  # default

    def get_itv_categories(self):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            
            # The response can be a list directly, or a dict with a 'js' key
            if isinstance(data, list):
                return data
            
            return data.get('js', [])

        except Exception as e:
            logger.error(f"Failed to get ITV categories: {e}")
            return []

    def get_channels_in_category(self, category_id):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=itv&action=get_ordered_list&genre={category_id}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            return data.get('js', {}).get('data', [])
        except Exception as e:
            logger.error(f"Failed to get channels in category {category_id}: {e}")
            return []

    def get_vod_categories(self):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=vod&action=get_categories&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)

            # The response can be a list directly, or a dict with a 'js' key
            if isinstance(data, list):
                return data
            
            return data.get('js', [])
        except Exception as e:
            logger.error(f"Failed to get VOD categories: {e}")
            return []

    def get_vod_in_category(self, category_id):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=vod&action=get_ordered_list&category={category_id}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            logger.debug(f"[VOD] get_ordered_list response: {data}")
            return data.get('js', {}).get('data', [])
        except Exception as e:
            logger.error(f"Failed to get VOD in category {category_id}: {e}")
            return []

    def get_series_categories(self):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=series&action=get_categories&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)

            # The response can be a list directly, or a dict with a 'js' key
            if isinstance(data, list):
                return data
            
            return data.get('js', [])
        except Exception as e:
            logger.error(f"Failed to get Series categories: {e}")
            return []

    def get_series_in_category(self, category_id):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=series&action=get_ordered_list&category={category_id}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            return data.get('js', {}).get('data', [])
        except Exception as e:
            logger.error(f"Failed to get Series in category {category_id}: {e}")
            return []

    def get_seasons(self, movie_id):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=series&action=get_ordered_list&movie_id={movie_id}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            return data.get('js', {}).get('data', [])
        except Exception as e:
            logger.error(f"Failed to get seasons for movie {movie_id}: {e}")
            return []

    def get_episodes(self, movie_id, season_id):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=series&action=get_ordered_list&movie_id={movie_id}&season_id={season_id}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            return data.get('js', {}).get('data', [])
        except Exception as e:
            logger.error(f"Failed to get episodes for movie {movie_id} and season {season_id}: {e}")
            return []

    def get_stream_link(self, cmd):
        logger.debug(f"[STREAM] Comandă originală: {cmd}")

        stream_cmd = cmd.strip()

        # Curățarea comenzii ffmpeg
        if re.match(r'(?i)^ffmpeg\s*(.*)', stream_cmd):
            logger.debug(f"[STREAM] Înlătur prefixul 'ffmpeg': {stream_cmd}")
            stream_cmd = re.sub(r'(?i)^ffmpeg\s*', '', stream_cmd).strip()

        # Construiește URL-ul create_link cu comanda originală (care poate conține localhost)
        create_link_url = f"{self.portal_url}/portal.php?type=itv&action=create_link&cmd={quote(stream_cmd)}&JsHttpRequest=1-xml"

        try:
            logger.debug(f"[STREAM] Efectuez cerere create_link: {create_link_url}")
            data = self._make_request(create_link_url)
            
            returned_url = data.get('js', {}).get('cmd') or data.get('js', {}).get('url')

            if returned_url:
                # Uneori răspunsul tot are 'ffmpeg '
                if re.match(r'(?i)^ffmpeg\s*(.*)', returned_url):
                    returned_url = re.sub(r'(?i)^ffmpeg\s*', '', returned_url).strip()
                
                logger.debug(f"[STREAM] URL stream obținut de la portal: {returned_url}")
                return returned_url
            else:
                logger.warning(f"[STREAM] Portalul nu a returnat un URL valid în răspunsul create_link: {data}")
                return None

        except Exception as e:
            logger.error(f"[STREAM] Eroare la cererea create_link: {e}")
            return None

    def get_vod_stream_url(self, movie_id):
        self.ensure_valid_token()
        
        cmd = f"movie {movie_id}"
        url = f"{self.portal_url}/portal.php?type=vod&action=create_link&cmd={quote(cmd)}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            logger.debug(f"[VOD] create_link response: {data}")
            returned_url = data.get('js', {}).get('cmd')
            
            if returned_url:
                # The portal is returning a malformed URL with stream=.. Let's replace it with the movie_id.
                stream_url = returned_url.replace('stream=.', f'stream={movie_id}')
                
                if 'ffmpeg' in stream_url:
                    stream_url = stream_url.replace('ffmpeg ', '')

                logger.debug(f"[VOD] Fixed stream URL: {stream_url}")
                return stream_url
            
            return None
        except Exception as e:
            logger.error(f"Failed to get VOD stream link for movie {movie_id}: {e}")
            return None

    def get_series_stream_url(self, cmd, episode_num):
        self.ensure_valid_token()
        
        url = f"{self.portal_url}/portal.php?type=vod&action=create_link&cmd={quote(cmd)}&series={episode_num}&JsHttpRequest=1-xml"

        try:
            data = self._make_request(url)
            returned_url = data.get('js', {}).get('cmd')

            if not returned_url:
                logger.error(f"[SERIES] Portal did not return a playable URL. Response: {data}")
                return None

            if 'ffmpeg' in returned_url:
                stream_url = returned_url.replace('ffmpeg ', '')
            else:
                stream_url = returned_url

            # The episode_num is the episode's unique ID. URL-encode it.
            safe_episode_num = quote(str(episode_num))
            stream_url = stream_url.replace('stream=.', f'stream={safe_episode_num}')

            logger.debug(f"[SERIES] Final constructed stream URL: {stream_url}")
            return stream_url
            
        except Exception as e:
            logger.error(f"Failed to get series stream link for cmd {cmd}, episode {episode_num}: {e}")
            return None