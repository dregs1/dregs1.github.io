# -*- coding: utf-8 -*-

'''
############################################################################
#                              /T /I                                           #
#                               / |/ | .-~/                                   #
#                           T\ Y     I    |/    /  _                               #
#          /T               | \I     |    I  Y.-~/                               #
#         I l   /I        T\ |  |     l    |  T  /                                   #
#      T\ |    \ Y l  /T    | \I  l      \ `  l Y                                   #
# __  | \l     \l     \I l __l  l   \   `  _. |                                   #
# \ ~-l     `\      `\  \     \ ~\  \   `. .-~    |                                   #
#  \   ~-. "-.    `  \  ^._ ^. "-.  /     \     |                                   #
#.--~-._  ~-  `     _    ~-_.-"-." ._ /._ ." ./                                   #
# >--.    ~-.      ._  ~>-"      "\   7   7   ]                                   #
#^.___~"--._    ~-{     .-~ .    `\ Y . /    |                                   #
# <__ ~"-.    ~        /_/      \      \I  Y      : |                                   #
#    ^-.__            ~(_/   \   >._:      | l______                               #
#        ^--.,___.-~"  /_/    !  `-.~"--l_ /       ~"-.                           #
#               (_/ .  ~(   /'      "~"--,Y    -=b-. _)                       #
#                (_/ .  \  Black Eagle / l       c"~o \
#                 \ /    `.      .        .^     \_.-~"~--.     )                       #
#                  (_/ .      `     /       /       !       )/                       #
#                   / / _.    '.     .':      /           '                       #
#                   ~(_/ .    /     _    `  .-<_                                   #
#                     /_/ . ' .-~" `.  / \  \          ,z=.                   #
#                     ~( /    '  :   | K     "-.~-.______//                       #
#                       "-,.       l   I/ \_    __{--->._(==.                   #
#                        //(        \  <    ~"~"     //                           #
#                       /' /\     \    \      ,v=.    ((                           #
#                     .^. / /\      "     }__ //===-     `                           #
#                    / / ' '     "-.,__ {---(==-                               #
#                  .^ '         :    T  ~"    ll                                   #
#                 / .  .     . : | :!         \                                   #
#                (_/     /     | | j-"          ~^                               #
#                  ~-<_(_.^-~"                                               #
#                                                                           #
############################################################################
'''

#############################=IMPORTS=######################################
    #Python Specific
import os,re,sys,json,base64,shutil,socket

    #Kodi Specific
import xbmc, xbmcvfs, xbmcplugin, xbmcgui, xbmcaddon
from urllib import request, error
import json

from urllib.parse import urlparse, quote_plus
from urllib.request import Request, urlopen
from inspect import getframeinfo, stack
from datetime import datetime

    #Addon Specific


##########################=VARIABLES=#######################################
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
GET_SET = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
ICON   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + ADDON_ID,  'icon.png'))
DIALOG = xbmcgui.Dialog()
DP    = xbmcgui.DialogProgress()
COLOR1='white'
COLOR2='blue'
dns_text = GET_SET.getSetting(id='DNS')
USER_DATA = os.path.join(PROFILE_PATH, 'user.json')

def check_protocol(url):
    parsed = urlparse(dns_text)
    protocol = parsed.scheme
    if protocol=='https':
        return url.replace('http','https')
    else:
        return url

# Classy: added for better logging
# This seperates logging from kodi.log into it's own file
def log(msg, trace=0):
    '''
    General new log messages
    '''
    log_path = xbmcvfs.translatePath('special://logpath')
    filename = 'flash.zoom.log'
    log_file = os.path.join(log_path, filename)


    try:
        if not isinstance(msg, str):
            raise Exception(f'log() msg not of type str! but of type {type(msg)}')

        if trace != 0:
            caller = getframeinfo(stack()[1][0])

            _msg = f'\n     {msg}:\n    \n--> called from file {caller.filename} @ {caller.lineno}'
        else:
            _msg = f'\n    {msg}'

        if not os.path.exists(log_file):
            _file = open(log_file, 'a', encoding="utf8")
            _file.write(line.rstrip('\r\n') + '\n')
        with open(log_file, 'a', encoding="utf8") as _file:
            now = datetime.now()
            _dt = now.strftime("%Y-%m-%d %H:%M:%S")
            line = f'{_dt}: {msg}'
            _file.write(line.rstrip('\r\n') + '\n')
    except (TypeError, Exception) as e:
        xbmc.log(f'[{ADDON_NAME}] Logging Failure: {e}\n\n msg: {msg}',2)

def log2(msg):
    msg = str(msg)
    xbmc.log('%s-%s'%(ADDON_ID,msg),2)



def b64(obj):
    return base64.b64decode(obj).decode('utf-8')

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def getInfo(label):
    try: return xbmc.getInfoLabel(label)
    except: return False

def LogNotify(title, message, times=3000, icon=ICON,sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)

def ASln():
    return LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_ID), '[COLOR {0}]AdvancedSettings.xml have been written[/COLOR]'.format(COLOR2))

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
        except: r = ''
    else:
        try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
        except: r = ''
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

def regex_get_us(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + ".+?[UK: Sky Sports].+?" + end_with + ")", text)
    return r

def addDir(name, url, mode, iconimage, fanart, description):
    default_icon = "DefaultIcon.png"
    default_fanart = "DefaultFanart.jpg"

    name = str(name) if name else "Unknown"
    url = str(url) if url else ""
    iconimage = str(iconimage) if iconimage else default_icon
    fanart = str(fanart) if fanart else default_fanart
    description = str(description) if description else "No description available"

    params = {
        "url": quote_plus(url),
        "mode": str(mode),
        "name": quote_plus(name),
        "iconimage": quote_plus(iconimage),
        "description": quote_plus(description),
    }
    u = sys.argv[0] + "?" + "&".join(f"{key}={value}" for key, value in params.items())
#files songs artists albums movies tvshows episodes musicvideos videos images games
    #if mode in ['live_category', 'live_list']:
    #    xbmcplugin.setContent(int(sys.argv[1]), 'videos')
    #elif mode in ['vod_category', 'vod_list']:
    #    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    #elif mode in ['series_lists', 'series_seasons', 'episode_list']:
    #    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    #elif mode in ['search', 'search_menu']:
    #    xbmcplugin.setContent(int(sys.argv[1]), 'search')
    #else:
    #    xbmcplugin.setContent(int(sys.argv[1]), 'videos')

    # Create the ListItem
    liz = xbmcgui.ListItem(name)
    liz.setArt({"icon": iconimage, "thumb": iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("fanart_image", fanart)

    # Determine if the item is playable
    is_playable_modes = {'play_live_stream', 'play_stream_video'}
    isFolder = mode not in is_playable_modes
    if not isFolder:
        liz.setProperty("IsPlayable", "true")

    # Add the directory item
    if mode == 'addonsettings' or mode == 'gui':
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    else:
        ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)

    return ok

def OPEN_URL(url, binary=False, headers=None):
    try:
        log(f"[CM Debug @ 197 in tools]Fetching URL {url}",1)
        req = Request(url)
        if headers:
            for k,v in headers.items():
                req.add_header(k,v)
        if not headers or 'User-Agent' not in headers:
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0')
        with urlopen(req) as response:
            if binary:
                return response.read()
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        log(f"Error fetching URL {url} : {e}",1)
        return None

def get_url(url):

    # define new request headers
    header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0'}

    # catch HTTP errors
    try:
        # create a request param and add request headers
        request_params = request.Request(url=url, headers=header)

        # send the request with the parameters and obtain a response object
        response = request.urlopen(request_params).read()
        if not isinstance(response, str):
            response = response.decode('utf-8')

        # return the response
        return json.loads(response)
    except error.HTTPError as e:
        log(f"Error fetching URL {url} : {e}",1)
        return None


def s_to_json(creds):
    try:
        data = [creds]
        with open(USER_DATA, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        xbmc.log(f"Error saving credentials: {e}", xbmc.LOGERROR)

def r_from_json():
    try:
        if os.path.exists(USER_DATA):
            with open(USER_DATA, 'r') as f:
                data = json.load(f)
                return data
        else:
            return []
    except Exception as e:
        xbmc.log(f"Unexpected error reading {USER_DATA}: {e}", xbmc.LOGERROR)
        return []



def clear_cache():
    xbmc.log('CLEAR CACHE ACTIVATED')
    xbmc_cache_path = os.path.join(xbmcvfs.translatePath('special://home'), 'cache')
    confirm=xbmcgui.Dialog().yesno("Please Confirm","Please Confirm You Wish To Delete Your Kodi Application Cache")
    if confirm:
        if os.path.exists(xbmc_cache_path)==True:
            for root, dirs, files in os.walk(xbmc_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                    for f in files:
                        try:
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
        LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_NAME), '[COLOR {0}]Cache Cleared Successfully![/COLOR]'.format(COLOR2))
        xbmc.executebuiltin("Container.Refresh()")

def get_params():
    params = {}
    if len(sys.argv) > 2:
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            cleanedparams = paramstring.lstrip('?').rstrip('/')
            pairsofparams = cleanedparams.split('&')
            for pair in pairsofparams:
                if '=' in pair:
                    key, value = pair.split('=', 1)     # Split on first '='
                    params[key] = value
    return params

def getlocalip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('8.8.8.8', 0))
    s = s.getsockname()[0]
    return s

def getexternalip():
    import json
    url = urlopen("https://api.ipify.org/?format=json")
    data = json.loads(url.read().decode())
    return str(data["ip"])

def month_num_to_name(num):
    month_map = {
        '01': 'January',
        '02': 'February',
        '03': 'March',
        '04': 'April',
        '05': 'May',
        '06': 'June',
        '07': 'July',
        '08': 'August',
        '09': 'September',
        '10': 'October',
        '11': 'November',
        '12': 'December'
    }
    return month_map.get(num, '')


def num_to_day(num):
    days = {
        "0": 'Monday',
        "1": 'Tuesday',
        "2": 'Wednesday',
        "3": 'Thursday',
        "4": 'Friday',
        "5": 'Saturday',
        "6": 'Sunday'
    }
    return days.get(num, None)

def killxbmc():
    killdialog = xbmcgui.Dialog().yesno('Force Close Kodi', '[COLOR white]You are about to close Kodi', 'Would you like to continue?[/COLOR]', nolabel='[B][COLOR red] No Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Force Close Kodi[/COLOR][/B]')
    if killdialog:
        os._exit(1)
    else:
        home()

def gen_m3u(url, path):
    parse = json.loads(OPEN_URL(url))
    i=1
    DP.create(ADDON_NAME, "Please Wait")
    with open (path, 'w+', encoding="utf-8") as ftg:
        ftg.write('#EXTM3U\n')
        for items in parse['available_channels']:
            a = parse['available_channels'][items]

            if a['stream_type'] == 'live':

                b = '#EXTINF:-1 channel-id="{0}" tvg-id="{1}" tvg-name="{2}" tvg-logo="{3}" channel-id="{4}" group-title="{5}",{6}'.format(i, a['epg_channel_id'], a['epg_channel_id'], a['stream_icon'], a['name'], a['category_name'], a['name'])

                if parse['server_info']['server_protocol'] == 'https':
                    port = parse['server_info']['https_port']
                else:
                    port = parse['server_info']['port']

                dns = '{0}://{1}:{2}'.format(parse['server_info']['server_protocol'], parse['server_info']['url'], port)
                c = '{0}/{1}/{2}/{3}'.format(dns, parse['user_info']['username'], parse['user_info']['password'],a['stream_id'])
                ftg.write(b+'\n'+c+'\n')
                i +=1
                DP.update(int(100), 'Found Channel \n' + a['name'] + '\n')
                if DP.iscanceled(): break
        DP.close
        DIALOG.ok(ADDON_NAME, 'Found ' + str(i) + ' Channels')

def keypopup(heading):
    kb =xbmc.Keyboard ('', 'heading', True)
    kb.setHeading(heading)
    kb.setHiddenInput(False)
    kb.doModal()
    if (kb.isConfirmed()):
        text = kb.getText()
        return text
    else:
        return False
